// Table Column Resizing Functionality

document.addEventListener('DOMContentLoaded', function() {
    const tables = document.querySelectorAll('table');
    
    tables.forEach(table => {
        const headers = table.querySelectorAll('th');
        
        headers.forEach((header, index) => {
            // Skip last header (no resize handle needed)
            if (index === headers.length - 1) return;
            
            // Create resize handle
            const handle = document.createElement('div');
            handle.className = 'resize-handle';
            handle.style.cssText = `
                position: absolute;
                right: -2px;
                top: 0;
                height: 100%;
                width: 4px;
                cursor: col-resize;
                user-select: none;
                background: transparent;
            `;
            
            header.style.position = 'relative';
            header.appendChild(handle);
            
            // Mouse down handler
            handle.addEventListener('mousedown', initResize);
        });
    });
    
    function initResize(e) {
        e.preventDefault();
        const header = e.target.parentElement;
        const table = header.closest('table');
        const column = header.cellIndex;
        const startX = e.pageX;
        const startWidth = header.offsetWidth;
        const minWidth = 50; // Minimum column width
        
        // Store original widths to prevent other columns from shifting
        const columnWidths = Array.from(table.querySelectorAll('th')).map(th => th.offsetWidth);
        
        function doResize(e) {
            const diff = e.pageX - startX;
            const newWidth = Math.max(minWidth, startWidth + diff);
            
            // Resize all cells in this column
            const cells = table.querySelectorAll(`tr > :nth-child(${column + 1})`);
            cells.forEach(cell => {
                cell.style.width = newWidth + 'px';
                cell.style.minWidth = newWidth + 'px';
            });
        }
        
        function stopResize() {
            document.removeEventListener('mousemove', doResize);
            document.removeEventListener('mouseup', stopResize);
            document.body.style.cursor = 'default';
            table.style.userSelect = 'auto';
        }
        
        document.addEventListener('mousemove', doResize);
        document.addEventListener('mouseup', stopResize);
        document.body.style.cursor = 'col-resize';
        table.style.userSelect = 'none';
    }
});
