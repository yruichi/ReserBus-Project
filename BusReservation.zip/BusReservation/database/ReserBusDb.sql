
-- ReserBus Complete Database
-- Bus Reservation System 

-- DATABASE SETUP
CREATE DATABASE ReserBus;
GO 

USE ReserBus;
GO

-- TABLES

-- Admin Table
CREATE TABLE Admin (
    AdminID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Name NVARCHAR(100) DEFAULT 'Administrator',
    Email NVARCHAR(100),
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO

-- Fare Table (Routes & Prices)
CREATE TABLE Fare (
    FareID INT IDENTITY(1,1) PRIMARY KEY,
    Destination NVARCHAR(100) NOT NULL,
    OneWayPrice DECIMAL(10,2) NOT NULL,
    RoundTripPrice DECIMAL(10,2) NOT NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);
GO

-- Employee Table
CREATE TABLE Employee (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100),
    Contact NVARCHAR(20),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Date_Added DATETIME DEFAULT GETDATE(),
    Total_Sales DECIMAL(10,2) DEFAULT 0,
    Monthly_Sales DECIMAL(10,2) DEFAULT 0,
    Overall_One_Way INT DEFAULT 0,
    Overall_RoundTrip INT DEFAULT 0,
    IsActive BIT DEFAULT 1,
    CreatedByAdminID INT,
    CONSTRAINT FK_Employee_Admin FOREIGN KEY (CreatedByAdminID) REFERENCES Admin(AdminID)
);
GO

-- Customer Table
CREATE TABLE Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Contact NVARCHAR(20),
    Email NVARCHAR(100),
    EmployeeID INT,
    CreatedAt DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Customer_Employee FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
GO

-- Ticket Table
CREATE TABLE Ticket (
    TicketID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    EmployeeID INT NOT NULL,
    FareID INT NOT NULL,
    TicketType NVARCHAR(20) NOT NULL,
    Destination NVARCHAR(100) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT DEFAULT 1,
    TotalAmount DECIMAL(10,2) NOT NULL,
    BookedDate DATETIME DEFAULT GETDATE(),
    DepartureDate DATETIME NOT NULL,
    Status NVARCHAR(50) DEFAULT 'Booked',
    CONSTRAINT FK_Ticket_Customer FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    CONSTRAINT FK_Ticket_Employee FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    CONSTRAINT FK_Ticket_Fare FOREIGN KEY (FareID) REFERENCES Fare(FareID)
);
GO

-- Employee Ticket Availability Table (tracks available tickets per employee per route)
CREATE TABLE EmployeeTicket (
    EmployeeTicketID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    FareID INT NOT NULL,
    OneWayAvailable INT DEFAULT 0,
    RoundTripAvailable INT DEFAULT 0,
    CONSTRAINT FK_EmployeeTicket_Employee FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID) ON DELETE CASCADE,
    CONSTRAINT FK_EmployeeTicket_Fare FOREIGN KEY (FareID) REFERENCES Fare(FareID) ON DELETE CASCADE,
    CONSTRAINT UQ_Employee_Fare UNIQUE (EmployeeID, FareID)
);
GO

-- Request Type Table
CREATE TABLE RequestType (
    RequestTypeID INT IDENTITY(1,1) PRIMARY KEY,
    RequestName NVARCHAR(50) NOT NULL
);
GO

-- Customer Request Table
CREATE TABLE CustomerRequest (
    RequestID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    TicketID INT NOT NULL,
    RequestTypeID INT NOT NULL,
    Reason NVARCHAR(500),
    Status NVARCHAR(50) DEFAULT 'Pending',
    RequestDate DATETIME DEFAULT GETDATE(),
    ProcessedDate DATETIME NULL,
    ProcessedByEmployeeID INT NULL,
    CONSTRAINT FK_Request_Customer FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    CONSTRAINT FK_Request_Ticket FOREIGN KEY (TicketID) REFERENCES Ticket(TicketID),
    CONSTRAINT FK_Request_Type FOREIGN KEY (RequestTypeID) REFERENCES RequestType(RequestTypeID),
    CONSTRAINT FK_Request_Employee FOREIGN KEY (ProcessedByEmployeeID) REFERENCES Employee(EmployeeID)
);
GO

-- INDEXES

CREATE INDEX IX_Ticket_EmployeeID ON Ticket(EmployeeID);
CREATE INDEX IX_Ticket_CustomerID ON Ticket(CustomerID);
CREATE INDEX IX_Ticket_Status ON Ticket(Status);
CREATE INDEX IX_Customer_EmployeeID ON Customer(EmployeeID);
CREATE INDEX IX_CustomerRequest_Status ON CustomerRequest(Status);
GO


-- SAMPLE DATA

-- Admin
INSERT INTO Admin (Username, Password, Name, Email)
VALUES ('admin', 'admin123', 'System Administrator', 'admin@reserbus.com');
GO

-- Request Types
INSERT INTO RequestType (RequestName) VALUES ('Cancellation'), ('Refund');
GO

-- Fares (16 Routes - Default price 0, Admin will update)
INSERT INTO Fare (Destination, OneWayPrice, RoundTripPrice) VALUES 
('Baguio - Manila', 0, 0),
('Baler - Manila', 0, 0),
('Batangas - Manila', 0, 0),
('Laoag - Manila', 0, 0),
('Legazpi - Manila', 0, 0),
('Manila - Baguio', 0, 0),
('Manila - Baler', 0, 0),
('Manila - Batangas', 0, 0),
('Manila - Laoag', 0, 0),
('Manila - Legazpi', 0, 0),
('Manila - Naga', 0, 0),
('Manila - Tagaytay', 0, 0),
('Manila - Vigan', 0, 0),
('Naga - Manila', 0, 0),
('Tagaytay - Manila', 0, 0),
('Vigan - Manila', 0, 0);
GO

-- Sample Employees (Password: pass123)
INSERT INTO Employee (Name, Email, Contact, Username, Password, CreatedByAdminID) VALUES 
('John Dela Cruz', 'john.delacruz@reserbus.com', '09171234567', 'employee1', 'pass123', 1),
('Maria Santos', 'maria.santos@reserbus.com', '09181234568', 'employee2', 'pass123', 1),
('Pedro Reyes', 'pedro.reyes@reserbus.com', '09191234569', 'employee3', 'pass123', 1),
('Ana Garcia', 'ana.garcia@reserbus.com', '09201234570', 'employee4', 'pass123', 1),
('Carlos Lopez', 'carlos.lopez@reserbus.com', '09211234571', 'employee5', 'pass123', 1);
GO

-- Sample Customers
INSERT INTO Customer (Name, Contact, Email, EmployeeID) VALUES 
('Roberto Cruz', '09221111111', 'roberto.cruz@email.com', 1),
('Elena Flores', '09222222222', 'elena.flores@email.com', 1),
('Miguel Torres', '09223333333', 'miguel.torres@email.com', 1),
('Sofia Ramos', '09224444444', 'sofia.ramos@email.com', 1),
('Antonio Rivera', '09225555555', 'antonio.rivera@email.com', 2),
('Isabella Mendoza', '09226666666', 'isabella.mendoza@email.com', 2),
('Diego Fernandez', '09227777777', 'diego.fernandez@email.com', 2),
('Carmen Diaz', '09228888888', 'carmen.diaz@email.com', 2),
('Francisco Morales', '09229999999', 'francisco.morales@email.com', 3),
('Rosa Martinez', '09230000000', 'rosa.martinez@email.com', 3),
('Luis Gonzales', '09231111111', 'luis.gonzales@email.com', 3),
('Patricia Castro', '09232222222', 'patricia.castro@email.com', 4),
('Ramon Jimenez', '09233333333', 'ramon.jimenez@email.com', 4),
('Gloria Pascual', '09234444444', 'gloria.pascual@email.com', 4),
('Ricardo Villanueva', '09235555555', 'ricardo.villanueva@email.com', 5),
('Teresa Aquino', '09236666666', 'teresa.aquino@email.com', 5),
('Oscar Bautista', '09237777777', 'oscar.bautista@email.com', 5),
('Lucia Navarro', '09238888888', 'lucia.navarro@email.com', 5),
('Eduardo Santos', '09239999999', 'eduardo.santos@email.com', 1),
('Mariana Reyes', '09240000000', 'mariana.reyes@email.com', 2);
GO

-- Sample Tickets (Employee 1)
INSERT INTO Ticket (CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, DepartureDate, Status) VALUES 
(1, 1, 1, 'One-Way', 'Baguio', 450.00, 2, 900.00, DATEADD(day, 3, GETDATE()), 'Booked'),
(1, 1, 2, 'Round-Trip', 'Tagaytay', 550.00, 1, 550.00, DATEADD(day, 7, GETDATE()), 'Booked'),
(2, 1, 3, 'One-Way', 'Batangas', 250.00, 3, 750.00, DATEADD(day, 2, GETDATE()), 'Completed'),
(3, 1, 6, 'Round-Trip', 'Vigan', 1300.00, 2, 2600.00, DATEADD(day, 14, GETDATE()), 'Booked'),
(4, 1, 9, 'One-Way', 'Manila', 150.00, 4, 600.00, DATEADD(day, 1, GETDATE()), 'Booked'),
(19, 1, 5, 'Round-Trip', 'Baler', 750.00, 2, 1500.00, DATEADD(day, 10, GETDATE()), 'Booked');
GO

-- Sample Tickets (Employee 2)
INSERT INTO Ticket (CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, DepartureDate, Status) VALUES 
(5, 2, 4, 'One-Way', 'Naga', 600.00, 2, 1200.00, DATEADD(day, 5, GETDATE()), 'Booked'),
(5, 2, 7, 'Round-Trip', 'Legazpi', 1200.00, 1, 1200.00, DATEADD(day, 8, GETDATE()), 'Completed'),
(6, 2, 8, 'One-Way', 'Laoag', 750.00, 2, 1500.00, DATEADD(day, 12, GETDATE()), 'Booked'),
(7, 2, 10, 'Round-Trip', 'Subic', 650.00, 3, 1950.00, DATEADD(day, 4, GETDATE()), 'Booked'),
(8, 2, 11, 'One-Way', 'Palawan', 1200.00, 2, 2400.00, DATEADD(day, 21, GETDATE()), 'Booked'),
(20, 2, 12, 'Round-Trip', 'Iloilo', 1800.00, 2, 3600.00, DATEADD(day, 15, GETDATE()), 'Booked');
GO

-- Sample Tickets (Employee 3)
INSERT INTO Ticket (CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, DepartureDate, Status) VALUES 
(9, 3, 13, 'One-Way', 'Cebu', 1100.00, 2, 2200.00, DATEADD(day, 18, GETDATE()), 'Booked'),
(9, 3, 14, 'Round-Trip', 'Davao', 2800.00, 1, 2800.00, DATEADD(day, 25, GETDATE()), 'Booked'),
(10, 3, 15, 'One-Way', 'Boracay', 1300.00, 2, 2600.00, DATEADD(day, 30, GETDATE()), 'Completed'),
(11, 3, 16, 'Round-Trip', 'Sagada', 1000.00, 3, 3000.00, DATEADD(day, 6, GETDATE()), 'Booked');
GO

-- Sample Tickets (Employee 4)
INSERT INTO Ticket (CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, DepartureDate, Status) VALUES 
(12, 4, 1, 'Round-Trip', 'Baguio', 800.00, 2, 1600.00, DATEADD(day, 9, GETDATE()), 'Booked'),
(13, 4, 2, 'One-Way', 'Tagaytay', 300.00, 4, 1200.00, DATEADD(day, 3, GETDATE()), 'Completed'),
(14, 4, 5, 'Round-Trip', 'Baler', 750.00, 2, 1500.00, DATEADD(day, 11, GETDATE()), 'Booked');
GO

-- Sample Tickets (Employee 5)
INSERT INTO Ticket (CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, DepartureDate, Status) VALUES 
(15, 5, 6, 'One-Way', 'Vigan', 700.00, 3, 2100.00, DATEADD(day, 13, GETDATE()), 'Booked'),
(16, 5, 7, 'Round-Trip', 'Legazpi', 1200.00, 2, 2400.00, DATEADD(day, 16, GETDATE()), 'Booked'),
(17, 5, 8, 'One-Way', 'Laoag', 750.00, 2, 1500.00, DATEADD(day, 20, GETDATE()), 'Completed'),
(18, 5, 9, 'Round-Trip', 'Manila', 280.00, 5, 1400.00, DATEADD(day, 2, GETDATE()), 'Booked');
GO

-- Sample Requests
INSERT INTO CustomerRequest (CustomerID, TicketID, RequestTypeID, Reason, Status) VALUES 
(1, 1, 1, 'Schedule conflict - cannot travel on the booked date', 'Pending'),
(2, 3, 2, 'Trip cancelled due to weather conditions', 'Pending'),
(5, 7, 1, 'Emergency - need to cancel reservation', 'Pending'),
(6, 9, 2, 'Destination changed, need refund', 'Pending'),
(9, 13, 1, 'Family emergency', 'Pending'),
(10, 15, 2, 'Flight rescheduled, need bus refund', 'Approved'),
(12, 17, 1, 'Work commitment on travel date', 'Pending'),
(15, 20, 2, 'Medical reasons', 'Rejected'),
(3, 4, 1, 'Change of plans', 'Pending'),
(7, 10, 2, 'Need refund for partial booking', 'Pending');
GO

-- Update Employee Stats
UPDATE Employee SET 
    Total_Sales = (SELECT ISNULL(SUM(TotalAmount), 0) FROM Ticket WHERE Ticket.EmployeeID = Employee.EmployeeID AND Status IN ('Booked', 'Completed')),
    Overall_One_Way = (SELECT COUNT(*) FROM Ticket WHERE Ticket.EmployeeID = Employee.EmployeeID AND TicketType = 'One-Way'),
    Overall_RoundTrip = (SELECT COUNT(*) FROM Ticket WHERE Ticket.EmployeeID = Employee.EmployeeID AND TicketType = 'Round-Trip');
GO


-- COMPLETE!

PRINT 'ReserBus Database Created Successfully!';
PRINT '';
PRINT 'Login Credentials:';
PRINT '  Admin:    admin / admin123';
PRINT '  Employee: employee1-5 / pass123';
PRINT '';
PRINT 'Sample Data:';
PRINT '  5 Employees';
PRINT '  20 Customers';
PRINT '  22 Tickets';
PRINT '  16 Destinations';
PRINT '  10 Requests';

GO
