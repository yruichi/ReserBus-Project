<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reserbus | Login</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/login.css">
</head>
<body>
    <div class="stack">
        <div class="logo-frame">
            <img src="<?php echo ASSETS_URL; ?>images/ReserBusLogo.png" alt="ReserBus logo" aria-hidden="true">
        </div>
        <div class="audience">For Admin and Employees Only</div>

        <form method="post" action="<?php echo BASE_URL; ?>auth/login">
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="actions">
                <button type="submit" class="btn-primary">Log In</button>
            </div>
        </form>

        <?php 
        if (isset($_SESSION['error'])) {
            echo "<div class='error'>" . htmlspecialchars($_SESSION['error']) . "</div>";
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo "<div class='success'>" . htmlspecialchars($_SESSION['success']) . "</div>";
            unset($_SESSION['success']);
        }
        ?>
    </div>
</body>
</html>
