
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'employee') {
    header('Location: login.php');
    exit();
}
// Require employee auth
requireEmployee();

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../models/Employee.php';
require_once __DIR__ . '/../../models/Ticket.php';
require_once __DIR__ . '/../../models/Fare.php';
require_once __DIR__ . '/../../models/Customer.php';

$employeeId = $_SESSION['user_id'];
$conn = Database::getConnection();

function getTotalSales($employeeId, $conn) {
    $stmt = $conn->prepare("SELECT SUM(Price) as total_sales FROM Ticket WHERE EmployeeID = ?");
    $stmt->execute([$employeeId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total_sales'] ?? 0;
}

function getMonthlySales($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT SUM(Price) as monthly_sales FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_sales'] ?? 0;
}

function getMonthlyCustomers($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT CustomerID) as monthly_customers FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_customers'] ?? 0;
}

function getMonthlyTickets($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT SUM(Quantity) as monthly_tickets FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_tickets'] ?? 0;
}

function getPendingRequests($employeeId, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) as pending_requests FROM CustomerRequest cr JOIN Ticket t ON cr.TicketID = t.TicketID WHERE t.EmployeeID = ? AND cr.Status = 'Pending'");
    $stmt->execute([$employeeId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['pending_requests'] ?? 0;
}

function getPopularRoute($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT TOP 1 Destination, SUM(Quantity) as total_qty FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ? GROUP BY Destination ORDER BY total_qty DESC");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['Destination'] ?? 'N/A';
}

$employeeData = [
    'total_sales' => getTotalSales($employeeId, $conn),
    'monthly_sales' => getMonthlySales($employeeId, $conn),
    'monthly_customers' => getMonthlyCustomers($employeeId, $conn),
    'monthly_tickets' => getMonthlyTickets($employeeId, $conn),
    'pending_requests' => getPendingRequests($employeeId, $conn),
    'popular_route' => getPopularRoute($employeeId, $conn),
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body>
    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Employee Dashboard</h1>
                <p>Manage Your Sales and Tickets</p>
            </div>
        </div>

        <div class="welcome-banner" style="background: #26538F; color: #fff; padding: 30px; border-radius: 0; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); display: flex; justify-content: space-between; align-items: center;">
            <div class="welcome-left">
                <h2 style="margin: 0 0 8px 0; font-size: 28px; font-weight: bold;">Welcome, <?php echo htmlspecialchars($employee['Name'] ?? $_SESSION['username'] ?? 'Employee'); ?>!</h2>
                <p style="margin: 5px 0; opacity: 0.95; font-size: 15px;">Track your sales performance and manage customer bookings</p>
                <div class="welcome-datetime" style="display: flex; gap: 15px; background: #26538F; padding: 15px 20px; border-radius: 8px; margin-top: 10px;">
                    <div class="dt-values" style="display: flex; flex-direction: column; gap: 8px;">
                        <span id="bannerDate">-</span>
                        <span id="bannerTime">-</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Overview Cards -->
        <div class="overview-section">
            <div class="overview-grid">
                <div class="overview-card">
                    <div class="card-icon">💰</div>
                    <div class="card-content">
                        <h3>Total Sales</h3>
                        <p class="card-value">₱<?php echo isset($employeeData['total_sales']) ? number_format($employeeData['total_sales'], 2) : '0.00'; ?></p>
                    </div>
                </div>
                <div class="overview-card">
                    <div class="card-icon">📅</div>
                    <div class="card-content">
                        <h3>Month Sales</h3>
                        <p class="card-value">₱<?php echo isset($employeeData['monthly_sales']) ? number_format($employeeData['monthly_sales'], 2) : '0.00'; ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>
                <div class="overview-card">
                    <div class="card-icon">👥</div>
                    <div class="card-content">
                        <h3>Month Customers</h3>
                        <p class="card-value"><?php echo isset($employeeData['monthly_customers']) ? number_format($employeeData['monthly_customers']) : '0'; ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>
                <div class="overview-card">
                    <div class="card-icon">🎫</div>
                    <div class="card-content">
                        <h3>Month Tickets</h3>
                        <p class="card-value"><?php echo isset($employeeData['monthly_tickets']) ? number_format($employeeData['monthly_tickets']) : '0'; ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>
                <div class="overview-card">
                    <div class="card-icon">⏳</div>
                    <div class="card-content">
                        <h3>Pending Requests</h3>
                        <p class="card-value"><?php echo isset($employeeData['pending_requests']) ? number_format($employeeData['pending_requests']) : '0'; ?></p>
                        <p class="card-subtext">Refunds & Cancellations</p>
                    </div>
                </div>
                <div class="overview-card">
                    <div class="card-icon">🚌</div>
                    <div class="card-content">
                        <h3>Popular Route</h3>
                        <p class="card-value" style="font-size: 16px;"><?php echo isset($employeeData['popular_route']) && $employeeData['popular_route'] ? htmlspecialchars($employeeData['popular_route']) : 'N/A'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="action-buttons-section">
            <h3>Quick Actions</h3>
            <div class="action-buttons-grid">
                <button class="action-btn" onclick="window.location.href='<?php echo BASE_URL; ?>index.php?page=employee/customers#book-ticket'">
                    <span class="btn-icon">🎫</span>
                    <span class="btn-text">Book Ticket</span>
                </button>
                <button class="action-btn" onclick="document.getElementById('ticket-availability-section').scrollIntoView({ behavior: 'smooth' });">
                    <span class="btn-icon">🎟️</span>
                    <span class="btn-text">View Ticket Availability</span>
                </button>
                <button class="action-btn" onclick="window.location.href='<?php echo BASE_URL; ?>index.php?page=employee/customers'">
                    <span class="btn-icon">👥</span>
                    <span class="btn-text">View Customers</span>
                </button>
                <button class="action-btn" onclick="window.location.href='<?php echo BASE_URL; ?>index.php?page=employee/customers&action=process'">
                    <span class="btn-icon">📝</span>
                    <span class="btn-text">Process Requests</span>
                </button>
                <button class="action-btn" onclick="window.location.href='<?php echo BASE_URL; ?>index.php?page=employee/fares'">
                    <span class="btn-icon">💰</span>
                    <span class="btn-text">View Fares</span>
                </button>
            </div>
        </div>

        <div class="sections-grid" id="ticket-availability-section">
            <div class="content-card" style="max-width: 1200px; margin: 0 auto 32px auto; box-shadow: 0 4px 16px rgba(38,83,143,0.08); border-radius: 16px; background: #fff; padding: 32px 24px;">
                <div class="section-title" style="margin-top:0;">Available Tickets</div>
                <div style="margin-bottom: 18px; display: flex; justify-content: flex-end;">
                    <input type="text" id="ticketSearchInput" class="search-input" placeholder="Search destination..." style="padding: 8px 14px; border-radius: 8px; border: 1px solid #e0e0e0; min-width: 220px;">
                </div>
                <div class="table-wrapper">
                    <table class="employees-table" id="ticketAvailabilityTable">
                        <thead>
                            <tr>
                                <th>Destination</th>
                                <th>One Way Tickets</th>
                                <th>Roundtrip Tickets</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $employeeModel = new Employee();
                        $ticketAvailability = $employeeModel->getTicketAvailability($employee['EmployeeID']);
                        if (!empty($ticketAvailability)):
                            foreach ($ticketAvailability as $destination => $counts): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($destination); ?></td>
                                <td><?php echo (int)$counts['one_way']; ?> ticket<?php echo ($counts['one_way'] == 1 ? '' : 's'); ?></td>
                                <td><?php echo (int)$counts['roundtrip']; ?> ticket<?php echo ($counts['roundtrip'] == 1 ? '' : 's'); ?></td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="3" style="text-align:center;">No tickets assigned yet</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

                <!-- ?? -->
        </div>
    </div>

    <?php include __DIR__ . '/../partials/book-ticket-modal.php'; ?>
    <?php include __DIR__ . '/../partials/request-modal.php'; ?>
    <script>
        // Listen for booking success event and show a message
        document.addEventListener('bookingSuccess', function(e) {
            alert('Hey! Ticket was successfully booked.');
        });
    </script>
    
<?php
// Handle ticket availability update for employee
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'edit_tickets') {
    require_once __DIR__ . '/../../models/Employee.php';
    $employeeModel = new Employee();
    $id = $_POST['id'] ?? ($_SESSION['user_id'] ?? null);
    $tickets = $_POST['tickets'] ?? [];
    if ($id && $employeeModel->updateTickets($id, $tickets)) {
        $_SESSION['success'] = 'Ticket availability updated!';
    } else {
        $_SESSION['error'] = 'Failed to update ticket availability.';
    }
    header('Location: ' . $_SERVER['PHP_SELF'] . '?page=employee/dashboard');
    exit;
}
?>
    <script>
        function updateDateTime() {
            const now = new Date();
            // Format date
            const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', options);
            const dateEl = document.getElementById('bannerDate');
            if (dateEl) dateEl.textContent = dateStr;
            // Format time
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const timeStr = `${hours}:${minutes}:${seconds}`;
            const timeEl = document.getElementById('bannerTime');
            if (timeEl) timeEl.textContent = timeStr;
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Ticket Availability Search
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('ticketSearchInput');
            const table = document.getElementById('ticketAvailabilityTable');
            if (searchInput && table) {
                searchInput.addEventListener('keyup', function() {
                    const filter = searchInput.value.toLowerCase();
                    const rows = table.querySelectorAll('tbody tr');
                    rows.forEach(row => {
                        const destination = row.querySelector('td');
                        if (!destination) return;
                        const text = destination.textContent.toLowerCase();
                        row.style.display = text.includes(filter) ? '' : 'none';
                    });
                });
            }
        });
    </script>
</body>
</html>
