<?php
// Employee requests page - accessed through routing
require_once __DIR__ . '/../../config/config.php';

// This page handles refund and cancellation requests

$requests = []; // Placeholder for actual requests from database

$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';
$filter = isset($_GET['filter']) ? htmlspecialchars($_GET['filter']) : 'all';
$sortBy = isset($_GET['sort']) ? htmlspecialchars($_GET['sort']) : 'date';
$sortOrder = isset($_GET['order']) ? htmlspecialchars($_GET['order']) : 'desc';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refund & Cancellation Requests - Employee Portal</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
</head>
<body>
    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Refund & Cancellation Requests</h1>
                <p>Process customer refund and cancellation requests</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <div class="section">
            <!-- Controls Bar -->
            <div class="controls-bar">
                <button class="btn btn-primary" onclick="window.location.href='customers.php'">
                    👥 Back to Customers
                </button>
            </div>

            <!-- Filter and Search Bar -->
            <div class="filter-bar">
                <form method="GET" class="search-form">
                    <input 
                        type="text" 
                        name="search" 
                        placeholder="Search by customer name or request ID..." 
                        value="<?php echo $search; ?>" 
                        class="search-input"
                    >
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>

                <div class="sort-controls">
                    <label for="filterStatus">Filter:</label>
                    <select id="filterStatus" name="filter" onchange="location.href='requests.php?filter=' + this.value + '&sort=<?php echo $sortBy; ?>'">
                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Requests</option>
                        <option value="pending" <?php echo $filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        <option value="refund" <?php echo $filter === 'refund' ? 'selected' : ''; ?>>Refunds</option>
                        <option value="cancellation" <?php echo $filter === 'cancellation' ? 'selected' : ''; ?>>Cancellations</option>
                    </select>

                    <label for="sortBy">Sort By:</label>
                    <select id="sortBy" name="sort" onchange="location.href='requests.php?filter=<?php echo $filter; ?>&sort=' + this.value">
                        <option value="date" <?php echo $sortBy === 'date' ? 'selected' : ''; ?>>Date</option>
                        <option value="amount" <?php echo $sortBy === 'amount' ? 'selected' : ''; ?>>Amount</option>
                        <option value="customer" <?php echo $sortBy === 'customer' ? 'selected' : ''; ?>>Customer</option>
                    </select>
                </div>
            </div>

            <!-- Requests Table -->
            <div class="table-wrapper">
                <table class="data-table requests-table">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Customer</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="8" class="no-data">
                                <div style="padding: 40px; text-align: center;">
                                    <p style="font-size: 18px; color: #999;">No requests found</p>
                                    <p style="color: #ccc; margin-top: 10px;">Refund and cancellation requests will appear here</p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Info Section -->
            <div style="margin-top: 30px; padding: 20px; background: #f5f5f5; border-radius: 8px;">
                <h3 style="margin-top: 0;">How to Process Requests</h3>
                <ol style="margin: 10px 0;">
                    <li>Review the refund or cancellation request details</li>
                    <li>Check the customer's account and ticket information</li>
                    <li>Approve or reject based on company policy</li>
                    <li>Document your decision with comments if needed</li>
                    <li>System will notify the customer of the decision</li>
                </ol>
            </div>
        </div>
    </div>

    <style>
        .controls-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .sort-controls {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .sort-controls label {
            font-weight: 500;
        }

        .sort-controls select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
        }

        .no-data {
            text-align: center;
            padding: 0 !important;
        }

        @media (max-width: 768px) {
            .filter-bar {
                flex-direction: column;
                gap: 10px;
            }

            .sort-controls {
                width: 100%;
            }

            .sort-controls select {
                flex: 1;
            }
        }
    </style>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.employee-sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }
    </script>
</body>
</html>
