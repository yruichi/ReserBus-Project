<?php
// Employee dashboard - accessed through routing
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../models/Employee.php';
require_once __DIR__ . '/../../models/Ticket.php';
require_once __DIR__ . '/../../models/Fare.php';
require_once __DIR__ . '/../../models/Customer.php';

$employeeModel = new Employee();
$ticketModel = new Ticket();
$fareModel = new Fare();
$customerModel = new Customer();

// Get fares for dropdown
$conn = Database::getConnection();
$faresForDropdown = [];
try {
    $stmt = $conn->query("SELECT FareID, Destination, OneWayPrice, RoundTripPrice FROM Fare WHERE IsActive = 1 ORDER BY Destination");
    $faresForDropdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $faresForDropdown = [];
}

$employeeId = $_SESSION['user_id'];
$employee = $employeeModel->getById($employeeId);

// Get statistics
$totalSales = $employee['Total_Sales'] ?? 0;
$monthlySales = $employee['Monthly_Sales'] ?? 0;
$totalCustomers = count($customerModel->getAll());
$oneWayTickets = $employee['Overall_One_Way'] ?? 0;
$roundTripTickets = $employee['Overall_RoundTrip'] ?? 0;

// Get most popular ticket (destination)
$fares = $fareModel->getAll();
$popularTicket = !empty($fares) ? $fares[0]['Destination'] : 'N/A';

// Get pending refunds/cancellations count (placeholder - would need actual table)
$pendingRequests = 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body>
    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <script>
        function openBookTicketModal() {
            document.getElementById('bookTicketModal').style.display = 'flex';
        }

        function generatePaxFields() {
            const numPax = parseInt(document.getElementById('numPax').value);
            const container = document.getElementById('paxFieldsContainer');
            container.innerHTML = '';
            
            for (let i = 1; i <= numPax; i++) {
                const paxGroup = document.createElement('div');
                paxGroup.className = 'form-group';
                paxGroup.innerHTML = `
                    <label>Passenger ${i} Details</label>
                    <input type="text" name="pax_name_${i}" placeholder="Full Name *" required>
                    <input type="number" name="pax_age_${i}" placeholder="Age *" min="1" max="120" required>
                `;
                container.appendChild(paxGroup);
            }
            updateTicketPrices();
        }

        function updateTicketPrices() {
            const destination = document.getElementById('ticketDestination');
            const ticketType = document.getElementById('ticketType');
            const numPax = parseInt(document.getElementById('numPax').value) || 1;
            
            if (destination.value && ticketType.value) {
                const selectedOption = destination.options[destination.selectedIndex];
                const price = ticketType.value === 'one-way' 
                    ? parseFloat(selectedOption.getAttribute('data-oneway')) 
                    : parseFloat(selectedOption.getAttribute('data-roundtrip'));
                
                const total = price * numPax;
                
                document.getElementById('pricePerTicket').textContent = '₱' + price.toFixed(2);
                document.getElementById('totalPrice').textContent = '₱' + total.toFixed(2);
            } else {
                document.getElementById('pricePerTicket').textContent = '₱0.00';
                document.getElementById('totalPrice').textContent = '₱0.00';
            }
        }

        // Update date and time
        function updateDateTime() {
            const now = new Date();
            document.getElementById('bannerDate').textContent = now.toLocaleDateString('en-US', { 
                weekday: 'short', 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
            document.getElementById('bannerTime').textContent = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }

        // Initialize date/time and update every minute
        updateDateTime();
        setInterval(updateDateTime, 60000);

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('bookTicketModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
