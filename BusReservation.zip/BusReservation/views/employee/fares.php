<?php
// Employee fares page - accessed through routing
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../models/Fare.php';


$fareModel = new Fare();
$fares = $fareModel->getAll();

// Get ticket availability for the logged-in employee
require_once __DIR__ . '/../../models/Employee.php';
$employeeId = $_SESSION['user_id'] ?? null;
$employeeModel = new Employee();
$ticketAvailability = $employeeId ? $employeeModel->getTicketAvailability($employeeId) : [];

// AJAX endpoint for ticket availability refresh
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
    echo json_encode(['ticketAvailability' => $ticketAvailability]);
    exit;
}

// Get search/filter parameters
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$sortParam = isset($_GET['sort']) ? $_GET['sort'] : 'destination-asc';

// Parse sort parameter
$sortParts = explode('-', $sortParam);
$sortBy = $sortParts[0] ?? 'destination';
$sortOrder = $sortParts[1] ?? 'asc';

// Filter fares
$filteredFares = $fares;
if ($search !== '') {
    $filteredFares = array_filter($fares, function($fare) use ($search) {
        return stripos($fare['Destination'], $search) !== false;
    });
}

// Sort fares
usort($filteredFares, function($a, $b) use ($sortBy, $sortOrder) {
    $result = 0;
    switch ($sortBy) {
        case 'destination':
            $result = strcasecmp($a['Destination'], $b['Destination']);
            break;
        case 'oneway':
            $result = $a['OneWayPrice'] - $b['OneWayPrice'];
            break;
        case 'roundtrip':
            $result = $a['RoundTripPrice'] - $b['RoundTripPrice'];
            break;
        default:
            $result = strcasecmp($a['Destination'], $b['Destination']);
            break;
    }
    return $sortOrder === 'desc' ? -$result : $result;
});

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fares - Employee Portal</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/fares.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
</head>
<body>
    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Bus Fares</h1>
                <p>View all available routes and prices</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <div class="section">
            <!-- Search Bar -->
            <div class="filter-bar">
                <input 
                    type="text" 
                    id="searchInput"
                    placeholder="Search by destination..." 
                    class="search-input"
                    onkeyup="searchFares()"
                >

                <div class="sort-controls">
                    <label for="sortBy">Sort By:</label>
                    <select id="sortBy" onchange="location.href='?page=employee/fares&sort=' + this.value">
                        <option value="destination-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'destination-asc') ? 'selected' : ''; ?>>Destination (A–Z)</option>
                        <option value="destination-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'destination-desc') ? 'selected' : ''; ?>>Destination (Z–A)</option>
                        <option value="oneway-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'oneway-asc') ? 'selected' : ''; ?>>One-Way Price (Low → High)</option>
                        <option value="oneway-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'oneway-desc') ? 'selected' : ''; ?>>One-Way Price (High → Low)</option>
                        <option value="roundtrip-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'roundtrip-asc') ? 'selected' : ''; ?>>Round-Trip Price (Low → High)</option>
                        <option value="roundtrip-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'roundtrip-desc') ? 'selected' : ''; ?>>Round-Trip Price (High → Low)</option>
                    </select>
                </div>
            </div>

            <!-- Fares Table -->
            <div class="table-wrapper">
                <table class="data-table customers-table">
                    <thead>
                        <tr>
                            <th>Fare ID</th>
                            <th>Destination</th>
                            <th>One-Way Price</th>
                            <th>Round-Trip Price</th>
                            <th class="hide-mobile">Difference</th>
                            <th>One-Way Available</th>
                            <th>Roundtrip Available</th>
                        </tr>
                    </thead>
                    <tbody id="faresTableBody">
                        <?php if (!empty($filteredFares)): ?>
                            <?php foreach ($filteredFares as $fare): ?>
                            <tr class="fare-row">
                                <td>FARE<?php echo str_pad($fare['FareID'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><strong><?php echo htmlspecialchars($fare['Destination']); ?></strong></td>
                                <td>₱<?php echo number_format($fare['OneWayPrice'], 2); ?></td>
                                <td>₱<?php echo number_format($fare['RoundTripPrice'], 2); ?></td>
                                <td class="hide-mobile">
                                    <?php 
                                    $diff = $fare['RoundTripPrice'] - $fare['OneWayPrice'];
                                    echo $diff > 0 ? '+' : '';
                                    echo '₱' . number_format($diff, 2);
                                    ?>
                                </td>
                                <td>
                                    <?php echo isset($ticketAvailability[$fare['Destination']]['one_way']) ? (int)$ticketAvailability[$fare['Destination']]['one_way'] : 0; ?>
                                </td>
                                <td>
                                    <?php echo isset($ticketAvailability[$fare['Destination']]['roundtrip']) ? (int)$ticketAvailability[$fare['Destination']]['roundtrip'] : 0; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="no-data">No fares found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Info Message -->
            <div class="info-message">
                <p><strong>Note:</strong> This is a read-only view of available fares. To book tickets for customers, use the Book Ticket option from the Dashboard.</p>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.employee-sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        function searchFares() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('.fare-row');
            rows.forEach(row => {
                const destination = row.cells[1].textContent.toLowerCase();
                if (destination.includes(searchInput)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Listen for booking events and update ticket availability table
        document.addEventListener('bookingSuccess', function() {
            fetch('?page=employee/fares&ajax=1')
                .then(res => res.json())
                .then(data => {
                    if (data && data.ticketAvailability) {
                        // Update the table cells for each destination
                        document.querySelectorAll('.fare-row').forEach(row => {
                            const destination = row.cells[1].textContent.trim();
                            if (data.ticketAvailability[destination]) {
                                row.cells[5].textContent = data.ticketAvailability[destination].one_way;
                                row.cells[6].textContent = data.ticketAvailability[destination].roundtrip;
                            }
                        });
                    }
                });
        });
    </script>
</body>
</html>
