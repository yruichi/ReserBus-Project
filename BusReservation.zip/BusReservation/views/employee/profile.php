<?php
// Employee profile page - accessed through routing
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../models/Employee.php';
require_once __DIR__ . '/../../models/Dashboard.php';


$employeeModel = new Employee();
$employeeId = $_SESSION['user_id'];
$employee = $employeeModel->getById($employeeId);

require_once __DIR__ . '/../../config/database.php';
$conn = Database::getConnection();

function getTotalSales($employeeId, $conn) {
    $stmt = $conn->prepare("SELECT SUM(Price) as total_sales FROM Ticket WHERE EmployeeID = ?");
    $stmt->execute([$employeeId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total_sales'] ?? 0;
}

function getMonthlySales($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT SUM(Price) as monthly_sales FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_sales'] ?? 0;
}

function getMonthlyCustomers($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT CustomerID) as monthly_customers FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_customers'] ?? 0;
}

function getMonthlyTickets($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT COUNT(*) as monthly_tickets FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ?");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['monthly_tickets'] ?? 0;
}

function getPendingRequests($employeeId, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) as pending_requests FROM CustomerRequest cr JOIN Ticket t ON cr.TicketID = t.TicketID WHERE t.EmployeeID = ? AND cr.Status = 'Pending'");
    $stmt->execute([$employeeId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['pending_requests'] ?? 0;
}

function getPopularRoute($employeeId, $conn) {
    $month = date('Y-m-01');
    $stmt = $conn->prepare("SELECT TOP 1 Destination, SUM(Quantity) as total_qty FROM Ticket WHERE EmployeeID = ? AND BookedDate >= ? GROUP BY Destination ORDER BY total_qty DESC");
    $stmt->execute([$employeeId, $month]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['Destination'] ?? 'N/A';
}

$employeeData = [
    'total_sales' => getTotalSales($employeeId, $conn),
    'monthly_sales' => getMonthlySales($employeeId, $conn),
    'monthly_customers' => getMonthlyCustomers($employeeId, $conn),
    'monthly_tickets' => getMonthlyTickets($employeeId, $conn),
    'pending_requests' => getPendingRequests($employeeId, $conn),
    'popular_route' => getPopularRoute($employeeId, $conn),
];

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact = trim($_POST['contact'] ?? '');

    if (!empty($name) && !empty($email)) {
        try {
            $conn = Database::getConnection();
            
            $query = "UPDATE Employee SET Name = ?, Email = ?, Contact = ? WHERE EmployeeID = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$name, $email, $contact, $employeeId]);
            
            $_SESSION['success'] = 'Profile updated successfully!';
            header('Location: ' . BASE_URL . 'index.php?page=employee/profile');
            exit();
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error updating profile: ' . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = 'Name and email are required';
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $_SESSION['error'] = 'All password fields are required';
    } elseif ($newPassword !== $confirmPassword) {
        $_SESSION['error'] = 'New passwords do not match';
    } elseif (strlen($newPassword) < 6) {
        $_SESSION['error'] = 'New password must be at least 6 characters';
    } else {
        // Verify current password
        if (!password_verify($currentPassword, $employee['Password']) && $currentPassword !== $employee['Password']) {
            $_SESSION['error'] = 'Current password is incorrect';
        } else {
            try {
                $conn = Database::getConnection();
                // Store password as plain text (INSECURE)
                $query = "UPDATE Employee SET Password = ? WHERE EmployeeID = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$newPassword, $employeeId]);
                $_SESSION['success'] = 'Password changed successfully!';
                header('Location: ' . BASE_URL . 'index.php?page=employee/profile');
                exit();
            } catch (Exception $e) {
                $_SESSION['error'] = 'Error changing password: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Employee Portal</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
</head>
<body>
    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>My Profile</h1>
                <p>Manage your profile and account settings</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <!-- Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="profile-container">
            <!-- Profile Info Card -->
            <div class="profile-card">
                <div class="profile-header">
                    <div class="profile-avatar">
                        <span><?php echo strtoupper(substr($employee['Name'] ?? 'E', 0, 1)); ?></span>
                    </div>
                    <div class="profile-info">
                        <h2><?php echo htmlspecialchars($employee['Name']); ?></h2>
                        <p class="employee-id">EMP<?php echo str_pad($employeeId, 3, '0', STR_PAD_LEFT); ?></p>
                        <p class="employee-role">Sales Agent</p>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="profile-stats">
                    <div class="stat-item">
                        <span class="stat-label">Total Sales</span>
                        <span class="stat-value">₱<?php echo number_format($employeeData['total_sales'] ?? 0, 2); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">This Month Sales</span>
                        <span class="stat-value">₱<?php echo number_format($employeeData['monthly_sales'] ?? 0, 2); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Month Tickets</span>
                        <span class="stat-value"><?php echo $employeeData['monthly_tickets'] ?? 0; ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Month Customers</span>
                        <span class="stat-value"><?php echo $employeeData['monthly_customers'] ?? 0; ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Pending Requests</span>
                        <span class="stat-value"><?php echo $employeeData['pending_requests'] ?? 0; ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Popular Route</span>
                        <span class="stat-value"><?php echo htmlspecialchars($employeeData['popular_route'] ?? 'N/A'); ?></span>
                    </div>
                </div>
            </div>

            <!-- Edit Profile Form -->
            <div class="form-card">
                <h3>Edit Profile Information</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($employee['Name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['Email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="contact">Contact Number</label>
                        <input type="tel" id="contact" name="contact" value="<?php echo htmlspecialchars($employee['Contact']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" value="<?php echo htmlspecialchars($employee['Username']); ?>" disabled>
                        <small style="color: #999;">Username cannot be changed</small>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <a href="index.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>

            <!-- Change Password Form -->
            <div class="form-card">
                <h3>Change Password</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label for="currentPassword">Current Password</label>
                        <input type="password" id="currentPassword" name="current_password" required>
                    </div>

                    <div class="form-group">
                        <label for="newPassword">New Password</label>
                        <input type="password" id="newPassword" name="new_password" required>
                        <small style="color: #999;">At least 6 characters</small>
                    </div>

                    <div class="form-group">
                        <label for="confirmPassword">Confirm Password</label>
                        <input type="password" id="confirmPassword" name="confirm_password" required>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Change Password</button>
                        <a href="index.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        .profile-container {
            padding: 25px;
            max-width: 900px;
            margin: 0 auto;
        }

        .profile-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .profile-header {
            display: flex;
            gap: 25px;
            align-items: flex-start;
            margin-bottom: 30px;
            padding-bottom: 30px;
            border-bottom: 1px solid #e0e0e0;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: white;
            font-weight: bold;
            flex-shrink: 0;
        }

        .profile-info h2 {
            margin: 0 0 5px 0;
            font-size: 28px;
            color: #333;
        }

        .employee-id {
            margin: 0;
            font-size: 14px;
            color: #666;
            font-weight: 600;
        }

        .employee-role {
            margin: 3px 0 0 0;
            font-size: 14px;
            color: #999;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 8px;
        }

        .stat-label {
            font-size: 12px;
            color: #999;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 22px;
            font-weight: bold;
            color: #2c3e50;
        }

        .form-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .form-card h3 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #333;
            font-size: 18px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group input:disabled {
            background-color: #f5f5f5;
            cursor: not-allowed;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
            }

            .profile-container {
                padding: 15px;
            }
        }
    </style>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.employee-sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // Password validation
        document.addEventListener('DOMContentLoaded', function() {
            const newPassword = document.getElementById('newPassword');
            const confirmPassword = document.getElementById('confirmPassword');
            const form = confirmPassword.closest('form');

            function validatePassword() {
                const pwd = newPassword.value;
                const confirm = confirmPassword.value;
                let message = '';

                if (pwd && pwd.length < 6) {
                    message = 'Password must be at least 6 characters';
                    newPassword.style.borderColor = '#e74c3c';
                } else if (pwd) {
                    newPassword.style.borderColor = '#27ae60';
                }

                if (confirm && pwd !== confirm) {
                    message = 'Passwords do not match';
                    confirmPassword.style.borderColor = '#e74c3c';
                } else if (confirm && pwd === confirm) {
                    confirmPassword.style.borderColor = '#27ae60';
                }

                return message === '';
            }

            newPassword.addEventListener('input', validatePassword);
            confirmPassword.addEventListener('input', validatePassword);

            form.addEventListener('submit', function(e) {
                const pwd = newPassword.value;
                const confirm = confirmPassword.value;

                if (pwd.length < 6) {
                    e.preventDefault();
                    alert('New password must be at least 6 characters');
                    newPassword.focus();
                    return false;
                }

                if (pwd !== confirm) {
                    e.preventDefault();
                    alert('Passwords do not match');
                    confirmPassword.focus();
                    return false;
                }
            });
        });
    </script>
</body>
</html>
