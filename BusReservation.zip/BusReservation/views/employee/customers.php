<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';

$conn = Database::getConnection();

// Get fares for dropdown
$faresForDropdown = [];
try {
    $stmt = $conn->query("SELECT FareID, Destination, OneWayPrice, RoundTripPrice FROM Fare WHERE IsActive = 1 ORDER BY Destination");
    $faresForDropdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $faresForDropdown = [];
}

// Get logged-in employee ID
$employeeId = $_SESSION['user_id'] ?? null;

// Get all customers handled by this employee with ticket and request info
try {
    // Fetch all tickets for all customers handled by this employee (history)
    $query = "
        SELECT 
            t.TicketID,
            t.CustomerID AS CustomerID,
            c.Name AS Name,
            c.Contact,
            c.Email,
            t.BookedDate,
            t.DepartureDate,
            t.ReturnDate,
            t.TicketType,
            t.Destination,
            t.Price,
            t.Quantity,
            t.TotalAmount,
            cr.RequestID,
            rt.RequestTypeID,
            rt.RequestName,
            cr.Reason,
            cr.Status
        FROM Ticket t
        INNER JOIN Customer c ON t.CustomerID = c.CustomerID
        LEFT JOIN CustomerRequest cr ON cr.TicketID = t.TicketID
            AND cr.RequestID = (
                SELECT MAX(cr2.RequestID) FROM CustomerRequest cr2 WHERE cr2.TicketID = t.TicketID
            )
        LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
        WHERE t.EmployeeID = :employee_id
        ORDER BY t.TicketID DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':employee_id', $employeeId);
    $stmt->execute();
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $customers = [];
}


// Ensure $sortParam and $search are defined
$sortParam = isset($_GET['sort']) ? $_GET['sort'] : 'name-asc';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sortParts = explode('-', $sortParam);
$sortBy = $sortParts[0] ?? 'name';
$sortOrder = $sortParts[1] ?? 'asc';

// Show all tickets for all customers (history)
$filteredCustomers = $customers;

// Apply search filter 
if ($search !== '') {
    $filteredCustomers = array_filter($filteredCustomers, function($customer) use ($search) {
        return stripos($customer['Name'], $search) !== false || 
               stripos($customer['Contact'], $search) !== false ||
               stripos($customer['Email'], $search) !== false ||
               (!empty($customer['TicketID']) && stripos($customer['TicketID'], $search) !== false) ||
               (!empty($customer['Status']) && stripos($customer['Status'], $search) !== false);
    });
}

// Sort customers
usort($filteredCustomers, function($a, $b) use ($sortBy, $sortOrder) {
    $result = 0;
    switch ($sortBy) {
        case 'name':
            $result = strcasecmp($a['Name'], $b['Name']);
            break;
        case 'booked':
            $dateA = $a['BookedDate'] ? strtotime($a['BookedDate']) : 0;
            $dateB = $b['BookedDate'] ? strtotime($b['BookedDate']) : 0;
            $result = $dateB - $dateA; // Default newest first
            break;
        case 'departure':
            $dateA = $a['DepartureDate'] ? strtotime($a['DepartureDate']) : 0;
            $dateB = $b['DepartureDate'] ? strtotime($b['DepartureDate']) : 0;
            $result = $dateA - $dateB; // Default earliest first
            break;
        case 'status':
            // Sort by status priority based on sortOrder parameter
            $statusPriorities = [
                'pending' => ['Pending' => 1, 'Active' => 2, 'Cancelled' => 3, 'Refunded' => 4, 'Approved' => 5, 'Rejected' => 6],
                'active' => ['Active' => 1, 'Pending' => 2, 'Approved' => 3, 'Cancelled' => 4, 'Refunded' => 5, 'Rejected' => 6],
                'cancelled' => ['Cancelled' => 1, 'Refunded' => 2, 'Rejected' => 3, 'Pending' => 4, 'Active' => 5, 'Approved' => 6],
                'refunded' => ['Refunded' => 1, 'Cancelled' => 2, 'Rejected' => 3, 'Pending' => 4, 'Active' => 5, 'Approved' => 6],
                'rejected' => ['Rejected' => 1, 'Cancelled' => 2, 'Refunded' => 3, 'Pending' => 4, 'Active' => 5, 'Approved' => 6]
            ];
            $priority = isset($statusPriorities[$sortOrder]) ? $statusPriorities[$sortOrder] : $statusPriorities['pending'];
            $priorityA = isset($priority[$a['Status']]) ? $priority[$a['Status']] : 99;
            $priorityB = isset($priority[$b['Status']]) ? $priority[$b['Status']] : 99;
            $result = $priorityA - $priorityB;
            break;
        case 'ticket':
            $ticketA = $a['TicketID'] ? (int)$a['TicketID'] : 0;
            $ticketB = $b['TicketID'] ? (int)$b['TicketID'] : 0;
            $result = $ticketA - $ticketB;
            break;
        default:
            $result = strcasecmp($a['Name'], $b['Name']);
            break;
    }
    return $sortOrder === 'desc' ? -$result : $result;
});

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Handle request edit/add modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_request') {
    $customerId = intval($_POST['customer_id'] ?? 0);
    $ticketId = intval($_POST['ticket_id'] ?? 0);
    $requestTypeName = trim($_POST['request_type'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    $requestTypeId = 0;
    if ($customerId && $ticketId && $requestTypeName && $reason) {
        // Look up or create RequestTypeID
        $typeStmt = $conn->prepare("SELECT RequestTypeID FROM RequestType WHERE RequestName = ?");
        $typeStmt->execute([$requestTypeName]);
        $typeRow = $typeStmt->fetch(PDO::FETCH_ASSOC);
        if ($typeRow) {
            $requestTypeId = $typeRow['RequestTypeID'];
        } else {
            $insertType = $conn->prepare("INSERT INTO RequestType (RequestName) VALUES (?)");
            $insertType->execute([$requestTypeName]);
            $requestTypeId = $conn->lastInsertId();
        }
        // Insert or update CustomerRequest for this ticket (always create new for history)
        $insertRequest = $conn->prepare("INSERT INTO CustomerRequest (CustomerID, TicketID, RequestTypeID, Reason, Status) VALUES (?, ?, ?, ?, ?)");
        $insertRequest->execute([$customerId, $ticketId, $requestTypeId, $reason, 'Pending']);

        // Fetch ticket and customer info for email
        $ticketStmt = $conn->prepare("SELECT t.TicketID, t.Quantity, t.Destination, c.Email, c.Name FROM Ticket t INNER JOIN Customer c ON t.CustomerID = c.CustomerID WHERE t.TicketID = ?");
        $ticketStmt->execute([$ticketId]);
        $ticketRow = $ticketStmt->fetch(PDO::FETCH_ASSOC);
        $emailSent = false;
        if ($ticketRow && !empty($ticketRow['Email'])) {
            require_once __DIR__ . '/../../utils/send_booking_email.php';
            $to = $ticketRow['Email'];
            $quantity = $ticketRow['Quantity'] ?? 1;
            $destination = $ticketRow['Destination'] ?? '';
            $requestType = $requestTypeName;
            $requestStatus = 'Pending';
            $requestDate = date('F d, Y');
            sendCancellationRequestEmail($to, $ticketRow['Name'], $ticketId, $quantity, $destination, $requestType, $requestStatus, $requestDate);
            if ($emailSent) {
                error_log('[REQUEST EMAIL] Sent to ' . $to . ' for TicketID ' . $ticketId);
            } else {
                error_log('[REQUEST EMAIL] FAILED to send to ' . $to . ' for TicketID ' . $ticketId);
            }
        }
        $_SESSION['success'] = 'Request submitted successfully!' . ($emailSent ? ' Email sent to customer.' : '');
        // AJAX response: return updated row HTML
        if ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)) {
            // Fetch latest ticket row with updated request info
            $fetchStmt = $conn->prepare("
                SELECT 
                    t.TicketID,
                    t.CustomerID AS CustomerID,
                    c.Name AS Name,
                    c.Contact,
                    c.Email,
                    t.BookedDate,
                    t.DepartureDate,
                    t.ReturnDate,
                    t.TicketType,
                    t.Destination,
                    t.Price,
                    t.Quantity,
                    t.TotalAmount,
                    cr.RequestID,
                    rt.RequestTypeID,
                    rt.RequestName,
                    cr.Reason,
                    cr.Status
                FROM Ticket t
                INNER JOIN Customer c ON t.CustomerID = c.CustomerID
                LEFT JOIN CustomerRequest cr ON cr.TicketID = t.TicketID
                    AND cr.RequestID = (
                        SELECT MAX(cr2.RequestID) FROM CustomerRequest cr2 WHERE cr2.TicketID = t.TicketID
                    )
                LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
                WHERE t.TicketID = ?
            ");
            $fetchStmt->execute([$ticketId]);
            $row = $fetchStmt->fetch(PDO::FETCH_ASSOC);
            ob_start();
            ?>
            <tr class="customer-row" 
                data-name="<?php echo htmlspecialchars($row['Name']); ?>"
                data-customer-id="C<?php echo str_pad($row['CustomerID'], 9, '0', STR_PAD_LEFT); ?>"
                data-ticket-id="T<?php echo str_pad($row['TicketID'], 9, '0', STR_PAD_LEFT); ?>">
                <td><input type="checkbox" name="selected_customers[]" value="<?php echo $row['CustomerID']; ?>" class="customer-checkbox"></td>
                <td><?php echo isset($row['TicketID']) ? 'T' . str_pad($row['TicketID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                <td><span class="customer-id">C<?php echo str_pad($row['CustomerID'], 9, '0', STR_PAD_LEFT); ?></span></td>
                <td><strong><?php echo htmlspecialchars($row['Name']); ?></strong></td>
                <td><?php echo htmlspecialchars($row['Contact'] ?? '-'); ?></td>
                <td>
                    <?php if ($row['Email']): ?>
                        <a href="mailto:<?php echo htmlspecialchars($row['Email']); ?>" class="email-link">
                            <?php echo htmlspecialchars($row['Email']); ?>
                        </a>
                    <?php else: ?>-
                    <?php endif; ?>
                </td>
                <td><?php echo $row['BookedDate'] ? date('M d, Y', strtotime($row['BookedDate'])) : '-'; ?></td>
                <td><?php echo $row['DepartureDate'] ? date('M d, Y', strtotime($row['DepartureDate'])) : '-'; ?></td>
                <td><?php echo $row['ReturnDate'] ? date('M d, Y', strtotime($row['ReturnDate'])) : '-'; ?></td>
                <td><?php echo !empty($row['TicketType']) ? htmlspecialchars($row['TicketType']) : '-'; ?></td>
                <td><?php echo !empty($row['Destination']) ? htmlspecialchars($row['Destination']) : '-'; ?></td>
                <td><?php echo isset($row['Price']) ? '₱' . number_format($row['Price'], 2) : '-'; ?></td>
                <td><?php echo isset($row['Quantity']) ? (int)$row['Quantity'] : '-'; ?></td>
                <td><?php echo isset($row['TotalAmount']) ? '₱' . number_format($row['TotalAmount'], 2) : '-'; ?></td>
                <td><?php echo isset($row['RequestID']) && $row['RequestID'] ? 'R' . str_pad($row['RequestID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                <td class="request-type"><?php echo !empty($row['RequestName']) ? htmlspecialchars($row['RequestName']) : '-'; ?></td>
                <td class="request-reason"><?php echo !empty($row['Reason']) ? htmlspecialchars($row['Reason']) : '-'; ?></td>
                <td class="request-status">
                    <?php if (!empty($row['Status'])): ?>
                        <span class="status-badge status-<?php echo strtolower($row['Status']); ?>"
                            <?php if (strtolower($row['Status']) === 'active') echo 'style=\"background:#10b981;color:#fff;\"'; ?>>
                            <?php echo htmlspecialchars($row['Status']); ?>
                        </span>
                    <?php else: ?>-
                    <?php endif; ?>
                </td>
                <td class="action-buttons">
                    <div style="display: flex; gap: 6px; flex-wrap: nowrap; align-items: center;">
                        <button type="button" class="btn btn-sm btn-primary" style="white-space: nowrap;" onclick="openRequestModal(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>', <?php echo $row['TicketID']; ?>)">Request</button>
                        <button type="button" class="btn btn-sm btn-edit" style="white-space: nowrap;" onclick="openEditCustomerModal(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>', '<?php echo htmlspecialchars($row['Contact']); ?>', '<?php echo htmlspecialchars($row['Email']); ?>')">Edit</button>
                        <button class="btn btn-sm btn-danger" style="white-space: nowrap;" onclick="deleteCustomer(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>')">Delete</button>
                    </div>
                </td>
            </tr>
            <?php
            $rowHtml = ob_get_clean();
            if (ob_get_length()) ob_end_clean();
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'customerRowHtml' => $rowHtml, 'ticketId' => $row['TicketID']]);
            exit;
        }
        // Fallback: normal redirect
        $_SESSION['success'] = 'Request submitted!';
        header('Location: ?page=employee/customers');
        exit;
    } else {
        // If AJAX, return debug info
        if ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => 'Missing required request fields.',
                'customerId' => $customerId,
                'ticketId' => $ticketId,
                'requestTypeName' => $requestTypeName,
                'reason' => $reason,
                'post' => $_POST
            ]);
            exit;
        }
        $_SESSION['error'] = 'Missing required request fields.';
        header('Location: ?page=employee/customers');
        exit;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_customer') {
    $customerId = intval($_POST['customer_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($customerId && $name && $contact) {
        $updateStmt = $conn->prepare("UPDATE Customer SET Name = ?, Contact = ?, Email = ? WHERE CustomerID = ?");
        $updateStmt->execute([$name, $contact, $email, $customerId]);
        $_SESSION['success'] = 'Customer details updated successfully!';
    } else {
        $_SESSION['error'] = 'Please fill in all required fields.';
    }
    header('Location: ?page=employee/customers');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete' && !empty($_POST['selected_customers'])) {
    $ids = array_map('intval', $_POST['selected_customers']);
    if (!empty($ids)) {
        // Get all TicketIDs for these customers
        $in = str_repeat('?,', count($ids) - 1) . '?';
        $ticketStmt = $conn->prepare("SELECT TicketID FROM Ticket WHERE CustomerID IN ($in)");
        $ticketStmt->execute($ids);
        $ticketIds = $ticketStmt->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($ticketIds)) {
            $ticketIn = str_repeat('?,', count($ticketIds) - 1) . '?';
            // Delete all CustomerRequest rows for these TicketIDs
            $conn->prepare("DELETE FROM CustomerRequest WHERE TicketID IN ($ticketIn)")->execute($ticketIds);
            // Delete the tickets
            $conn->prepare("DELETE FROM Ticket WHERE TicketID IN ($ticketIn)")->execute($ticketIds);
        }
        // Delete the customers
        $conn->prepare("DELETE FROM Customer WHERE CustomerID IN ($in)")->execute($ids);
        $_SESSION['success'] = 'Selected customers deleted.';
    }
    header('Location: ?page=employee/customers');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_cancellation') {
    // Handle cancellation request
    $ticketId = $_POST['ticket_id'] ?? null;
    $reason = $_POST['reason'] ?? '';
    if ($ticketId && $reason) {
        // Get CustomerID from Ticket
        $ticketStmt = $conn->prepare("SELECT CustomerID FROM Ticket WHERE TicketID = ?");
        $ticketStmt->execute([$ticketId]);
        $ticket = $ticketStmt->fetch(PDO::FETCH_ASSOC);
        if (!$ticket) {
            $_SESSION['error'] = 'Ticket not found.';
            header('Location: ?page=employee/customers');
            exit;
        }
        $customerId = $ticket['CustomerID'];
        
        // Find RequestTypeID for 'Cancellation'
        $cancelTypeStmt = $conn->prepare("SELECT RequestTypeID FROM RequestType WHERE RequestName = ?");
        $cancelTypeStmt->execute(['Cancellation']);
        $cancelType = $cancelTypeStmt->fetch(PDO::FETCH_ASSOC);
        if ($cancelType) {
            $cancelTypeId = $cancelType['RequestTypeID'];
        } else {
            $insertCancelType = $conn->prepare("INSERT INTO RequestType (RequestName) VALUES (?)");
            $insertCancelType->execute(['Cancellation']);
            $cancelTypeId = $conn->lastInsertId();
        }
        // Insert cancellation request
        $insertCancelRequest = $conn->prepare("INSERT INTO CustomerRequest (CustomerID, TicketID, RequestTypeID, Reason, Status) VALUES (?, ?, ?, ?, ?)");
        $insertCancelRequest->execute([$customerId, $ticketId, $cancelTypeId, $reason, 'Pending']);
        $_SESSION['success'] = 'Cancellation request submitted!';
    } else {
        $_SESSION['error'] = 'Missing ticket or reason.';
    }
    header('Location: ?page=employee/customers');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_ticket') {
    // Start output buffering to catch any unexpected output (so JSON responses remain valid)
    if (!ob_get_length()) ob_start();

    // Catch all fatal errors and output as JSON for debugging
    set_exception_handler(function($ex) {
        error_log('[BOOKING EXCEPTION] ' . $ex->getMessage() . "\n" . $ex->getTraceAsString());
        if ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)) {
            if (ob_get_length()) ob_end_clean();
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => 'Fatal error: ' . $ex->getMessage(),
                'trace' => $ex->getTraceAsString(),
                'post' => $_POST,
                'session' => $_SESSION,
            ]);
            exit;
        }
        throw $ex;
    });
        // Helper for AJAX error response
        function ajaxError($msg, $extra = null) {
            
        // Log error server-side for debugging
            error_log('[BOOKING ERROR] ' . $msg . ($extra ? ' | Extra: ' . print_r($extra, true) : ''));
            if (
                (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
                (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
            ) {
                if (ob_get_length()) ob_end_clean();
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => $msg, 'details' => $extra, 'post' => $_POST, 'session' => $_SESSION]);
                exit;
            } else {
                // Fallback for non-AJAX: show error in session
                $_SESSION['error'] = $msg . ($extra ? ' Details: ' . print_r($extra, true) : '');
                header('Location: ?page=employee/customers');
                exit;
            }
        }
    // DEBUG: Output all POST data if requested
    if (isset($_POST['debug']) && $_POST['debug'] === '1') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error' => 'Debug info',
            'post' => $_POST,
            'session' => $_SESSION,
        ]);
        exit;
    }
    // Collect booking data
    $customerName = trim($_POST['customer_name'] ?? '');
    $customerEmail = trim($_POST['customer_email'] ?? '');
    $customerContact = trim($_POST['customer_contact'] ?? '');
    $numPax = intval($_POST['num_pax'] ?? 1);
    $destination = trim($_POST['destination'] ?? '');
    $ticketType = trim($_POST['ticket_type'] ?? '');
    $departureDate = trim($_POST['departure_date'] ?? '');
    $returnDate = isset($_POST['return_date']) ? trim($_POST['return_date']) : null;
    
    // No longer collecting passenger names
    $paxNames = [];
    $bookingDate = date('Y-m-d H:i:s');
    
    // Validate and format departure date
    $departureTimestamp = strtotime($departureDate);
    if ($departureTimestamp === false) {
        ajaxError('Invalid departure date format.');
    }
    $departureDateFormatted = date('Y-m-d H:i:s', $departureTimestamp);
    $returnDateFormatted = null;
    if ($ticketType === 'round-trip') {
        if (!$returnDate) {
            ajaxError('Return date is required for round-trip tickets.');
        }
        $returnTimestamp = strtotime($returnDate);
        if ($returnTimestamp === false) {
            ajaxError('Invalid return date format.');
        }
        if ($returnTimestamp < $departureTimestamp) {
            ajaxError('Return date cannot be before departure date for round-trip tickets.');
        }
        $returnDateFormatted = date('Y-m-d H:i:s', $returnTimestamp);
    }
    $departureTime = '8:00 AM'; // You may want to get this from form or DB

    // Basic validation
    if (!$customerName || !$customerEmail || !$customerContact || !$destination || !$ticketType || !$departureDate || $numPax < 1) {
        ajaxError('Missing required booking fields.');
    }
    if (!filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
        ajaxError('Invalid email address.');
    }
    
    // Backend validation: check available tickets for this employee/destination/type
    $ticketAvailStmt = $conn->prepare('
        SELECT et.OneWayAvailable, et.RoundTripAvailable, et.EmployeeTicketID, et.FareID, 
               f.OneWayPrice, f.RoundTripPrice, f.Destination
        FROM EmployeeTicket et
        JOIN Fare f ON et.FareID = f.FareID
        WHERE et.EmployeeID = ? AND f.Destination = ?
    ');
    $ticketAvailStmt->execute([$employeeId, $destination]);
    $ticketAvail = $ticketAvailStmt->fetch(PDO::FETCH_ASSOC);
    $availCount = 9999; // fallback: allow booking if not found
    $employeeTicketId = null;
    $fareId = null;
    $ticketPrice = 0;
    if ($ticketAvail) {
        $availCount = ($ticketType === 'one-way') ? (int)$ticketAvail['OneWayAvailable'] : (int)$ticketAvail['RoundTripAvailable'];
        $employeeTicketId = $ticketAvail['EmployeeTicketID'];
        $fareId = $ticketAvail['FareID'];
        $ticketPrice = ($ticketType === 'one-way') ? (float)$ticketAvail['OneWayPrice'] : (float)$ticketAvail['RoundTripPrice'];
        $destination = $ticketAvail['Destination'];
    } else {
        // fallback: try to get fare info directly
        $fareStmt = $conn->prepare('SELECT FareID, OneWayPrice, RoundTripPrice, Destination FROM Fare WHERE Destination = ?');
        $fareStmt->execute([$destination]);
        $fareRow = $fareStmt->fetch(PDO::FETCH_ASSOC);
        if ($fareRow) {
            $fareId = $fareRow['FareID'];
            $ticketPrice = ($ticketType === 'one-way') ? (float)$fareRow['OneWayPrice'] : (float)$fareRow['RoundTripPrice'];
            $destination = $fareRow['Destination'];
        }
    }
    // ??? what???? Always allow booking, even if ticket count is exceeded or fare info is missing
    if (!$fareId) {
        // fallback: insert with null fareId
        $fareId = null;
    }
    if ($ticketPrice <= 0) {
        $ticketPrice = floatval($_POST['price_per_ticket'] ?? 0);
    }
    if (!$destination || $destination === '-') {
        $destination = trim($_POST['destination'] ?? '');
    }

    try {
        // Use a transaction and avoid OUTPUT clauses for better compatibility with PDO/sqlsrv
        $conn->beginTransaction();
        // Insert or find customer with unique formatted CustomerID
        $customerId = null;
        $checkStmt = $conn->prepare("SELECT TOP 1 CustomerID FROM Customer WHERE Name = ? AND Contact = ? AND Email = ?");
        $checkStmt->execute([$customerName, $customerContact, $customerEmail]);
        $existingCustomer = $checkStmt->fetch(PDO::FETCH_ASSOC);
        if ($existingCustomer) {
            $customerId = $existingCustomer['CustomerID'];
        } else {
            $insertStmt = $conn->prepare("INSERT INTO Customer (Name, Contact, Email, EmployeeID) VALUES (?, ?, ?, ?)");
            $insertStmt->execute([$customerName, $customerContact, $customerEmail, $employeeId]);
            
            // Get last inserted CustomerID
            $sel = $conn->prepare("SELECT TOP 1 CustomerID FROM Customer WHERE Name = ? AND Contact = ? AND Email = ? ORDER BY CustomerID DESC");
            $sel->execute([$customerName, $customerContact, $customerEmail]);
            $res = $sel->fetch(PDO::FETCH_ASSOC);
            $customerId = $res ? $res['CustomerID'] : null;
        }
        if (!$customerId) {
            if ($conn->inTransaction()) $conn->rollBack();
            ajaxError('Failed to create or retrieve customer ID.');
        }

        // Insert ticket (let SQL Server auto-generate TicketID)
        $totalAmount = $ticketPrice * $numPax;
        if ($ticketType === 'round-trip') {
            $ticketInsertFields = "CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, BookedDate, DepartureDate, ReturnDate, Status";
            $ticketInsertValues = [$customerId, $employeeId, $fareId, $ticketType, $destination, $ticketPrice, $numPax, $totalAmount, $bookingDate, $departureDateFormatted, $returnDateFormatted, 'Active'];
        } else {
            $ticketInsertFields = "CustomerID, EmployeeID, FareID, TicketType, Destination, Price, Quantity, TotalAmount, BookedDate, DepartureDate, Status";
            $ticketInsertValues = [$customerId, $employeeId, $fareId, $ticketType, $destination, $ticketPrice, $numPax, $totalAmount, $bookingDate, $departureDateFormatted, 'Active'];
        }
        $placeholders = rtrim(str_repeat('?, ', count($ticketInsertValues)), ', ');
        $ticketStmt = $conn->prepare("INSERT INTO Ticket ($ticketInsertFields) VALUES ($placeholders)");
        $ticketStmt->execute($ticketInsertValues);
        
        // Get last inserted TicketID
        $selT = $conn->prepare("SELECT TOP 1 TicketID FROM Ticket WHERE CustomerID = ? ORDER BY TicketID DESC");
        $selT->execute([$customerId]);
        $r = $selT->fetch(PDO::FETCH_ASSOC);
        $ticketId = $r ? $r['TicketID'] : null;
        if (!$ticketId) {
            if ($conn->inTransaction()) $conn->rollBack();
            ajaxError('Failed to create ticket.');
        }

        // Decrement available tickets for employee and ensure the update actually happened
        if ($employeeTicketId) {
            if ($ticketType === 'one-way') {
                $updateTicketStmt = $conn->prepare("UPDATE EmployeeTicket SET OneWayAvailable = OneWayAvailable - ? WHERE EmployeeTicketID = ? AND OneWayAvailable >= ?");
                $updateTicketStmt->execute([$numPax, $employeeTicketId, $numPax]);
                if ($updateTicketStmt->rowCount() === 0) {
                    if ($conn->inTransaction()) $conn->rollBack();
                    ajaxError('Not enough available employee one-way tickets when updating.');
                }
            } else {
                $updateTicketStmt = $conn->prepare("UPDATE EmployeeTicket SET RoundTripAvailable = RoundTripAvailable - ? WHERE EmployeeTicketID = ? AND RoundTripAvailable >= ?");
                $updateTicketStmt->execute([$numPax, $employeeTicketId, $numPax]);
                if ($updateTicketStmt->rowCount() === 0) {
                    if ($conn->inTransaction()) $conn->rollBack();
                    ajaxError('Not enough available employee round-trip tickets when updating.');
                }
            }
        }

        // Insert or find request type
        $defaultRequestName = 'Booking';
        $requestTypeStmt = $conn->prepare("SELECT RequestTypeID FROM RequestType WHERE RequestName = ?");
        $requestTypeStmt->execute([$defaultRequestName]);
        $requestType = $requestTypeStmt->fetch(PDO::FETCH_ASSOC);
        if ($requestType) {
            $requestTypeId = $requestType['RequestTypeID'];
        } else {
            $insertRequestType = $conn->prepare("INSERT INTO RequestType (RequestName) VALUES (?)");
            $insertRequestType->execute([$defaultRequestName]);
            $selRT = $conn->prepare("SELECT TOP 1 RequestTypeID FROM RequestType WHERE RequestName = ? ORDER BY RequestTypeID DESC");
            $selRT->execute([$defaultRequestName]);
            $rr = $selRT->fetch(PDO::FETCH_ASSOC);
            $requestTypeId = $rr ? $rr['RequestTypeID'] : null;
        }
        if (!$requestTypeId) {
            if ($conn->inTransaction()) $conn->rollBack();
            ajaxError('Failed to get or create request type.');
        }

        // Insert a CustomerRequest for this ticket
        $insertCustomerRequest = $conn->prepare("INSERT INTO CustomerRequest (CustomerID, TicketID, RequestTypeID, Reason, Status) VALUES (?, ?, ?, ?, ?)");
        $insertCustomerRequest->execute([$customerId, $ticketId, $requestTypeId, 'Initial booking', 'Active']);
        $selCR = $conn->prepare("SELECT TOP 1 RequestID FROM CustomerRequest WHERE TicketID = ? ORDER BY RequestID DESC");
        $selCR->execute([$ticketId]);
        $rrr = $selCR->fetch(PDO::FETCH_ASSOC);
        $requestId = $rrr ? $rrr['RequestID'] : null;
        if (!$requestId) {
            if ($conn->inTransaction()) $conn->rollBack();
            ajaxError('Failed to create customer request.');
        }

        // Commit transaction
        if ($conn->inTransaction()) $conn->commit();

        // Update employee sales (total and monthly) after booking
        require_once __DIR__ . '/../../models/Employee.php';
        $empModel = new Employee();
        $empModel->updateSales($employeeId);

        // Send booking email
        require_once __DIR__ . '/../../utils/send_booking_email.php';
        sendBookingEmail(
            $customerEmail,
            $customerName, // <-- add this
            $ticketId,
            $numPax,
            $destination,
            ucfirst(str_replace('-', ' ', $ticketType)),
            date('F d, Y', strtotime($bookingDate)),
            date('F d, Y', strtotime($departureDate)),
            $departureTime
        );

        // Fetch the latest booking for this ticket (to ensure display is up-to-date)
        $fetchStmt = $conn->prepare("

            SELECT 
                c.CustomerID,
                t.TicketID,
                t.CustomerID AS TicketCustomerID,
                t.EmployeeID,
                t.FareID,
                t.TicketType,
                t.Destination,
                t.Price,
                t.Quantity,
                t.TotalAmount,
                t.BookedDate,
                t.DepartureDate,
                t.ReturnDate,
                c.Name AS Name,
                c.Contact,
                c.Email,
                cr.RequestID,
                rt.RequestTypeID,
                rt.RequestName,
                cr.Reason,
                cr.Status
            FROM Ticket t
            INNER JOIN Customer c ON t.CustomerID = c.CustomerID
            LEFT JOIN CustomerRequest cr ON cr.TicketID = t.TicketID
                AND cr.RequestID = (
                    SELECT MAX(cr2.RequestID) FROM CustomerRequest cr2 WHERE cr2.TicketID = t.TicketID
                )
            LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
            WHERE t.TicketID = ?
        ");
        $fetchStmt->execute([$ticketId]);
        $row = $fetchStmt->fetch(PDO::FETCH_ASSOC);

        // If AJAX, return new row HTML for table
        if (
            (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
        ) {
            ob_start();
            ?>
            <tr class="customer-row" 
                data-name="<?php echo htmlspecialchars($row['Name']); ?>"
                data-customer-id="C<?php echo str_pad($row['CustomerID'], 9, '0', STR_PAD_LEFT); ?>"
                data-ticket-id="T<?php echo str_pad($row['TicketID'], 9, '0', STR_PAD_LEFT); ?>">
                <td><input type="checkbox" name="selected_customers[]" value="<?php echo $row['CustomerID']; ?>" class="customer-checkbox"></td>
                <td><span class="customer-id">C<?php echo str_pad($row['CustomerID'], 9, '0', STR_PAD_LEFT); ?></span></td>
                <td><?php echo isset($row['TicketID']) ? 'T' . str_pad($row['TicketID'], 9, '0', STR_PAD_LEFT) : ''; ?></td>
                <td><strong><?php echo htmlspecialchars($row['Name']); ?></strong></td>
                <td><?php echo htmlspecialchars($row['Contact'] ?? '-'); ?></td>
                <td>
                    <?php if ($row['Email']): ?>
                        <a href="mailto:<?php echo htmlspecialchars($row['Email']); ?>" class="email-link">
                            <?php echo htmlspecialchars($row['Email']); ?>
                        </a>
                    <?php else: ?>-
                    <?php endif; ?>
                </td>
                <td><?php echo $row['BookedDate'] ? date('M d, Y', strtotime($row['BookedDate'])) : '-'; ?></td>
                <td><?php echo $row['DepartureDate'] ? date('M d, Y', strtotime($row['DepartureDate'])) : '-'; ?></td>
                <td><?php echo !empty($row['TicketType']) ? htmlspecialchars($row['TicketType']) : '-'; ?></td>
                <td><?php echo !empty($row['Destination']) ? htmlspecialchars($row['Destination']) : '-'; ?></td>
                <td><?php echo isset($row['Price']) ? '₱' . number_format($row['Price'], 2) : '-'; ?></td>
                <td><?php echo isset($row['Quantity']) ? (int)$row['Quantity'] : '-'; ?></td>
                <td><?php echo isset($row['TotalAmount']) ? '₱' . number_format($row['TotalAmount'], 2) : '-'; ?></td>
                <td><?php echo isset($row['RequestID']) && $row['RequestID'] ? 'R' . str_pad($row['RequestID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                <td><?php echo !empty($row['RequestName']) ? htmlspecialchars($row['RequestName']) : '-'; ?></td>
                <td><?php echo !empty($row['Reason']) ? htmlspecialchars($row['Reason']) : '-'; ?></td>
                <td><span class="status-badge status-active" style="background:#10b981;color:#fff;">Active</span></td>
                <td class="action-buttons">
                    <div style="display: flex; gap: 6px; flex-wrap: nowrap; align-items: center;">
                        <button type="button" class="btn btn-sm btn-primary" style="white-space: nowrap;" onclick="openRequestModal(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>', <?php echo $row['TicketID']; ?>)">Request</button>
                        <button type="button" class="btn btn-sm btn-edit" style="white-space: nowrap;" onclick="openEditCustomerModal(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>', '<?php echo htmlspecialchars($row['Contact']); ?>', '<?php echo htmlspecialchars($row['Email']); ?>')">Edit</button>
                        <button class="btn btn-sm btn-danger" style="white-space: nowrap;" onclick="deleteCustomer(<?php echo $row['CustomerID']; ?>, '<?php echo htmlspecialchars($row['Name']); ?>')">Delete</button>
                    </div>
                </td>
            </tr>
            <?php
            $rowHtml = ob_get_clean();
            if (ob_get_length()) ob_end_clean();
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'customerRowHtml' => $rowHtml, 'ticketId' => $row['TicketID']]);
            exit;
        }
        // Fallback: normal redirect
        $_SESSION['success'] = 'Booking successful! Confirmation email sent.';
        header('Location: ?page=employee/customers');
        exit;
    } catch (PDOException $ex) {
        
    // Log full error and SQL state for debugging
        $errorInfo = isset($ex->errorInfo) ? $ex->errorInfo : null;
        ajaxError('Booking failed: ' . $ex->getMessage(), $errorInfo);
    } catch (Exception $ex) {
        ajaxError('Booking failed: ' . $ex->getMessage());
    }
// AJAX: refresh table body
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    ob_start();
    if (!empty($filteredCustomers)) {
        foreach ($filteredCustomers as $customer) {
            ?>
            <tr class="customer-row" 
                data-name="<?php echo htmlspecialchars($customer['Name']); ?>"
                data-customer-id="C<?php echo str_pad($customer['CustomerID'], 9, '0', STR_PAD_LEFT); ?>"
                data-ticket-id="T<?php echo isset($customer['TicketID']) ? str_pad($customer['TicketID'], 9, '0', STR_PAD_LEFT) : ''; ?>">
                <td><input type="checkbox" name="selected_customers[]" value="<?php echo $customer['CustomerID']; ?>" class="customer-checkbox"></td>
                <td>
                    <span class="customer-id">C<?php echo str_pad($customer['CustomerID'], 9, '0', STR_PAD_LEFT); ?></span>
                </td>
                <td>
                    <?php echo isset($customer['TicketID']) ? 'T' . str_pad($customer['TicketID'], 9, '0', STR_PAD_LEFT) : ''; ?>
                </td>
                <td>
                    <strong><?php echo htmlspecialchars($customer['Name']); ?></strong>
                </td>
                </td>
                <td>
                    <?php echo htmlspecialchars($customer['Contact'] ?? '-'); ?>
                </td>
                <td>
                    <?php if ($customer['Email']): ?>
                        <a href="mailto:<?php echo htmlspecialchars($customer['Email']); ?>" class="email-link">
                            <?php echo htmlspecialchars($customer['Email']); ?>
                        </a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo $customer['BookedDate'] ? date('M d, Y', strtotime($customer['BookedDate'])) : '-'; ?>
                </td>
                <td>
                    <?php echo $customer['DepartureDate'] ? date('M d, Y', strtotime($customer['DepartureDate'])) : '-'; ?>
                </td>
                <td>
                    <?php echo isset($customer['RequestID']) && $customer['RequestID'] ? 'REQ' . str_pad($customer['RequestID'], 5, '0', STR_PAD_LEFT) : '-'; ?>
                </td>
                <td>
                    <?php echo !empty($customer['RequestName']) ? htmlspecialchars($customer['RequestName']) : '-'; ?>
                </td>
                <td>
                    <?php echo !empty($customer['Reason']) ? htmlspecialchars($customer['Reason']) : '-'; ?>
                </td>
                <td>
                    <?php 
                    if (!empty($customer['Status'])): 
                        $status = $customer['Status'];
                        $statusClass = strtolower($status);
                        
                        // Status color mapping
                        $statusColors = [
                            'active'    => 'background: #d1fae5; color: #065f46;',
                            'booked'    => 'background: #dbeafe; color: #1e40af;',
                            'pending'   => 'background: #fef3c7; color: #92400e;',
                            'approved'  => 'background: #d1fae5; color: #065f46;',
                            'rejected'  => 'background: #fee2e2; color: #991b1b;',
                            'cancelled' => 'background: #fecaca; color: #b91c1c;',
                            'refunded'  => 'background: #e0e7ff; color: #4338ca;',
                            'completed' => 'background: #d1fae5; color: #065f46;'
                        ];
                        $statusStyle = $statusColors[$statusClass] ?? $statusColors['active'];
                    ?>
                        <span style="<?php echo $statusStyle; ?> padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                            <?php echo htmlspecialchars($status); ?>
                        </span>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary" onclick="openRequestModal(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>', <?php echo $customer['TicketID'] ?? 'null'; ?>)">Request</button>
                    <button class="btn btn-sm btn-edit" onclick="openEditCustomerModal(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>', '<?php echo htmlspecialchars($customer['Contact']); ?>', '<?php echo htmlspecialchars($customer['Email']); ?>')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteCustomer(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>')">Delete</button>
                </td>
            </tr>
            <?php
        }
    } else {
        ?>
        <tr>
            <td colspan="13" class="no-data">No customers found</td>
        </tr>
        <?php
    }
    $tbodyHtml = ob_get_clean();
    header('Content-Type: text/html');
    echo $tbodyHtml;
    exit;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - Employee Portal</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
</head>
<body>

    <?php include __DIR__ . '/../partials/employee-sidebar.php'; ?>

    <script>
    
    // Inject available tickets for this employee
    window.employeeAvailableTickets = {};
    <?php
    
    // Query all available tickets for this employee
    $ticketAvailStmt = $conn->prepare('
        SELECT f.Destination, et.OneWayAvailable, et.RoundTripAvailable
        FROM EmployeeTicket et
        JOIN Fare f ON et.FareID = f.FareID
        WHERE et.EmployeeID = ?
    ');
    $ticketAvailStmt->execute([$employeeId]);
    $ticketAvail = $ticketAvailStmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($ticketAvail as $row) {
        $dest = addslashes($row['Destination']);
        $oneWay = (int)$row['OneWayAvailable'];
        $roundTrip = (int)$row['RoundTripAvailable'];
        echo "window.employeeAvailableTickets['$dest'] = { one_way: $oneWay, roundtrip: $roundTrip };\n";
    }
    ?>
    </script>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Customers</h1>
                <p>Manage customer records and process requests</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <!-- Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="section">
            <!-- Action Bar -->
            <div class="controls-bar">
                <button class="btn btn-primary" onclick="document.getElementById('bookTicketModal').style.display = 'flex';">🎫 Book Ticket</button>
            </div>

            <!-- Search Bar -->
            <div class="filter-bar">
                <input 
                    type="text" 
                    id="searchInput"
                    placeholder="Search by name, contact, email, ticket, or status..." 
                    class="search-input"
                    onkeyup="searchCustomers()"
                >

                <div class="sort-controls">
                    <label for="sortBy">Sort By:</label>
                    <select id="sortBy" onchange="location.href='?page=employee/customers&sort=' + this.value">
                        <option value="name-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'name-asc') ? 'selected' : ''; ?>>Customer Name (A–Z)</option>
                        <option value="name-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'name-desc') ? 'selected' : ''; ?>>Customer Name (Z–A)</option>
                        <option value="booked-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'booked-desc') ? 'selected' : ''; ?>>Booked Date (Oldest)</option>
                        <option value="booked-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'booked-asc') ? 'selected' : ''; ?>>Booked Date (Newest)</option>
                        <option value="departure-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'departure-asc') ? 'selected' : ''; ?>>Departure Date (Earliest)</option>
                        <option value="departure-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'departure-desc') ? 'selected' : ''; ?>>Departure Date (Latest)</option>
                        <option value="status-pending" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'status-pending') ? 'selected' : ''; ?>>Status (Pending)</option>
                        <option value="status-active" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'status-active') ? 'selected' : ''; ?>>Status (Active)</option>
                        <option value="status-rejected" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'status-rejected') ? 'selected' : ''; ?>>Status (Rejected)</option>
                        <option value="ticket-asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'ticket-asc') ? 'selected' : ''; ?>>Ticket ID (Ascending)</option>
                        <option value="ticket-desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] === 'ticket-desc') ? 'selected' : ''; ?>>Ticket ID (Descending)</option>
                    </select>
                </div>
            </div>

            <!-- Customers Table -->
            <?php if (!empty($_SESSION['success'])): ?>
                <div class="alert alert-success" style="margin-bottom: 16px;">
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($_SESSION['error'])): ?>
                <div class="alert alert-danger" style="margin-bottom: 16px;">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>
            <form id="bulkDeleteForm" method="POST" action="?page=employee/customers" onsubmit="return confirm('Are you sure you want to delete the selected customers? This cannot be undone.');">
                <input type="hidden" name="action" value="bulk_delete">
                <button type="submit" class="btn btn-danger" id="bulkDeleteBtn" style="margin-bottom:10px;" disabled>Delete</button>
                <button type="button" class="btn btn-warning" id="viewTicketBtn" style="background: #6e0483; color: #ffffff; border: none; margin-bottom:10px; margin-left:10px;" onclick="viewSelectedTicket()">View</button>
                <div class="table-wrapper">
                    <table class="data-table customers-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAllCustomers" onclick="toggleSelectAllCustomers(this)"></th>
                                <th>Ticket ID</th>
                                <th>Customer ID</th>
                                <th>Customer Name</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Booked Date</th>
                                <th>Departure Date</th>
                                <th>Return Date</th>
                                <th>Ticket Type</th>
                                <th>Destination</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total Amount</th>
                                <th>Request ID</th>
                                <th>Request Type</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th style="min-width: 220px; white-space: nowrap;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="customersTableBody">
                            <?php if (!empty($filteredCustomers)): ?>
                                <?php foreach ($filteredCustomers as $customer): ?>
                                <tr class="customer-row" 
                                    data-name="<?php echo htmlspecialchars($customer['Name']); ?>"
                                    data-customer-id="C<?php echo str_pad($customer['CustomerID'], 9, '0', STR_PAD_LEFT); ?>"
                                    data-ticket-id="T<?php echo isset($customer['TicketID']) ? str_pad($customer['TicketID'], 9, '0', STR_PAD_LEFT) : ''; ?>">
                                    <td><input type="checkbox" name="selected_customers[]" value="<?php echo $customer['CustomerID']; ?>" class="customer-checkbox"></td>
                                    <td><?php echo isset($customer['TicketID']) ? 'T' . str_pad($customer['TicketID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                                    <td><span class="customer-id">C<?php echo str_pad($customer['CustomerID'], 9, '0', STR_PAD_LEFT); ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($customer['Name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($customer['Contact'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($customer['Email']): ?>
                                            <a href="mailto:<?php echo htmlspecialchars($customer['Email']); ?>" class="email-link">
                                                <?php echo htmlspecialchars($customer['Email']); ?>
                                            </a>
                                        <?php else: ?>-
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $customer['BookedDate'] ? date('M d, Y', strtotime($customer['BookedDate'])) : '-'; ?></td>
                                    <td><?php echo $customer['DepartureDate'] ? date('M d, Y', strtotime($customer['DepartureDate'])) : '-'; ?></td>
                                    <td><?php echo $customer['ReturnDate'] ? date('M d, Y', strtotime($customer['ReturnDate'])) : '-'; ?></td>
                                    <td><?php echo !empty($customer['TicketType']) ? htmlspecialchars($customer['TicketType']) : '-'; ?></td>
                                    <td><?php echo !empty($customer['Destination']) ? htmlspecialchars($customer['Destination']) : '-'; ?></td>
                                    <td><?php echo isset($customer['Price']) ? '₱' . number_format($customer['Price'], 2) : '-'; ?></td>
                                    <td><?php echo isset($customer['Quantity']) ? (int)$customer['Quantity'] : '-'; ?></td>
                                    <td><?php echo isset($customer['TotalAmount']) ? '₱' . number_format($customer['TotalAmount'], 2) : '-'; ?></td>
                                    <td><?php echo isset($customer['RequestID']) && $customer['RequestID'] ? 'R' . str_pad($customer['RequestID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                                    <td><?php echo !empty($customer['RequestName']) ? htmlspecialchars($customer['RequestName']) : '-'; ?></td>
                                    <td><?php echo !empty($customer['Reason']) ? htmlspecialchars($customer['Reason']) : '-'; ?></td>
                                    <td>
                                        <?php if (!empty($customer['Status'])): ?>
                                            <?php
                                                $status = strtolower($customer['Status']);
                                                $statusStyles = [
                                                    'active' => 'background:#BBE0EF;color:#161E54;', // Changed color for Active
                                                    'booked' => 'background:#dbeafe;color:#1e40af;',
                                                    'pending' => 'background:#fef3c7;color:#92400e;',
                                                    'approved' => 'background:#d1fae5;color:#065f46;',
                                                    'rejected' => 'background:#fee2e2;color:#991b1b;',
                                                    'cancelled' => 'background:#fecaca;color:#b91c1c;',
                                                    'refunded' => 'background:#e0e7ff;color:#4338ca;',
                                                    'completed' => 'background:#d1fae5;color:#065f46;'
                                                ];
                                                $statusStyle = $statusStyles[$status] ?? $statusStyles['active'];
                                            ?>
                                            <span class="status-badge status-<?php echo $status; ?>" style="<?php echo $statusStyle; ?>">
                                                <?php echo htmlspecialchars($customer['Status']); ?>
                                            </span>
                                        <?php else: ?>-
                                        <?php endif; ?>
                                    </td>
                                    <td class="action-buttons">
                                        <div style="display: flex; gap: 6px; flex-wrap: nowrap; align-items: center;">
                                            <button type="button" class="btn btn-sm btn-primary" style="white-space: nowrap;" onclick="openRequestModal(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>', <?php echo $customer['TicketID'] ?? 'null'; ?>)">Request</button>
                                            <button type="button" class="btn btn-sm btn-edit" style="white-space: nowrap;" onclick="openEditCustomerModal(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>', '<?php echo htmlspecialchars($customer['Contact']); ?>', '<?php echo htmlspecialchars($customer['Email']); ?>')">Edit</button>
                                            <button class="btn btn-sm btn-danger" style="white-space: nowrap;" onclick="deleteCustomer(<?php echo $customer['CustomerID']; ?>, '<?php echo htmlspecialchars($customer['Name']); ?>')">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="13" class="no-data">No customers found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>

    <?php include __DIR__ . '/../partials/book-ticket-modal.php'; ?>
    <?php include __DIR__ . '/../partials/request-modal.php'; ?>
    <?php include __DIR__ . '/../partials/edit-customer-modal.php'; ?>
    <?php include __DIR__ . '/../partials/view-ticket-modal.php'; ?>


    <script>
            // View selected ticket details in modal
            function viewSelectedTicket() {
                const checkboxes = document.querySelectorAll('.customer-checkbox:checked');
                if (checkboxes.length !== 1) {
                    alert('Please select exactly one customer to view ticket details.');
                    return;
                }
                const row = checkboxes[0].closest('tr');
                const cells = row.cells;
                document.getElementById('modalTicketId').textContent = cells[1].textContent.trim();
                document.getElementById('modalCustomerId').textContent = cells[2].textContent.trim();
                document.getElementById('modalCustomerName').textContent = cells[3].textContent.trim();
                document.getElementById('modalCustomerContact').textContent = cells[4].textContent.trim();
                document.getElementById('modalCustomerEmail').textContent = cells[5].textContent.trim();
                document.getElementById('modalBookedDate').textContent = cells[6].textContent.trim();
                document.getElementById('modalDepartureDate').textContent = cells[7].textContent.trim();
                document.getElementById('modalReturnDate').textContent = cells[8].textContent.trim();
                document.getElementById('modalTicketType').textContent = cells[9].textContent.trim();
                document.getElementById('modalDestination').textContent = cells[10].textContent.trim();
                document.getElementById('modalPrice').textContent = cells[11].textContent.trim();
                document.getElementById('modalQuantity').textContent = cells[12].textContent.trim();
                document.getElementById('modalTotalAmount').textContent = cells[13].textContent.trim();
                document.getElementById('modalRequestId').textContent = cells[14].textContent.trim();
                document.getElementById('modalRequestType').textContent = cells[15].textContent.trim();
                document.getElementById('modalReason').textContent = cells[16].textContent.trim();
                document.getElementById('modalStatus').textContent = cells[17].textContent.trim();
                document.getElementById('viewTicketModal').style.display = 'flex';
            }
        function openBookTicketModal() {
            document.getElementById('bookTicketModal').style.display = 'flex';
        }
        function toggleSidebar() {
            const sidebar = document.querySelector('.employee-sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        function openRequestModal(customerId, customerName, ticketId) {
            
            // Fill modal fields for request
            var customerIdField = document.getElementById('requestCustomerID');
            var customerNameField = document.getElementById('requestCustomerName');
            var ticketIdField = document.getElementById('requestTicketIDInput');
            var ticketIdDisplay = document.getElementById('requestTicketIDText');
            var reasonField = document.getElementById('requestReason');
            var typeField = document.getElementById('requestType');
            
            // Fallback to empty string if ticketId is undefined or null
            if (typeof ticketId === 'undefined' || ticketId === null) ticketId = '';
            if (customerIdField) customerIdField.value = customerId;
            if (customerNameField) customerNameField.textContent = customerName;
            if (ticketIdField) ticketIdField.value = ticketId;
            if (ticketIdDisplay) ticketIdDisplay.textContent = ticketId ? ('T' + String(ticketId).padStart(9, '0')) : '-';
            if (reasonField) reasonField.value = '';
            if (typeField) typeField.selectedIndex = 0;
            document.getElementById('requestModal').style.display = 'flex';
        }


        // Unified edit customer modal logic (shared with admin portal)
        function openEditCustomerModal(id, name, contact, email) {
            document.getElementById('editCustomerID').value = id;
            document.getElementById('editCustomerName').value = name;
            document.getElementById('editCustomerContact').value = contact;
            document.getElementById('editCustomerEmail').value = email;
            document.getElementById('editCustomerModal').style.display = 'flex';
        }

        function openAddCustomerModal() {
            document.getElementById('addCustomerModal').style.display = 'flex';
        }

        function openRefundModal(customerId, customerName) {
            document.getElementById('refundCustomerName').textContent = customerName;
            document.getElementById('refundModal').style.display = 'flex';
            document.getElementById('refundForm').onsubmit = function(e) {
                e.preventDefault();
                alert('Refund request submitted for ' + customerName + '!\\n\\nNote: Full integration with database pending.');
                document.getElementById('refundModal').style.display = 'none';
            }
        }

        function openCancellationModal(customerId, customerName) {
            document.getElementById('cancellationCustomerName').textContent = customerName;
            document.getElementById('cancellationModal').style.display = 'flex';
            document.getElementById('cancellationForm').onsubmit = function(e) {
                e.preventDefault();
                alert('Cancellation request submitted for ' + customerName + '!\\n\\nNote: Full integration with database pending.');
                document.getElementById('cancellationModal').style.display = 'none';
            }
        }

        function deleteCustomer(customerId, customerName) {
            if (confirm('Are you sure you want to delete ' + customerName + '? This action cannot be undone.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = '<input type="hidden" name="action" value="delete_customer"><input type="hidden" name="customer_id" value="' + customerId + '">';
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        function searchCustomers() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('.customer-row');
            
            rows.forEach(row => {
                const name = row.getAttribute('data-name').toLowerCase();
                const contact = row.cells[3].textContent.toLowerCase();
                const email = row.cells[4].textContent.toLowerCase();
                const ticketId = row.cells[1].textContent.toLowerCase();
                const status = row.cells[8].textContent.toLowerCase();
                
                if (name.includes(searchInput) || 
                    contact.includes(searchInput) || 
                    email.includes(searchInput) || 
                    ticketId.includes(searchInput) || 
                    status.includes(searchInput)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    // Bulk select/deselect all customers
    function toggleSelectAllCustomers(source) {
        const checkboxes = document.querySelectorAll('.customer-checkbox');
        checkboxes.forEach(cb => cb.checked = source.checked);
        updateBulkDeleteBtn();
    }

    // Enable/disable bulk delete button based on selection
    function updateBulkDeleteBtn() {
        const checkboxes = document.querySelectorAll('.customer-checkbox');
        const anyChecked = Array.from(checkboxes).some(cb => cb.checked);
        document.getElementById('bulkDeleteBtn').disabled = !anyChecked;
    }

    // Listen for individual checkbox changes
    document.addEventListener('DOMContentLoaded', function() {
        const checkboxes = document.querySelectorAll('.customer-checkbox');
        checkboxes.forEach(cb => {
            cb.addEventListener('change', updateBulkDeleteBtn);
        });
        updateBulkDeleteBtn();
    });
    </script>
</body>
</html>
