<?php
/**
 * Employee Portal Router
 * Handles direct access to employee pages
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an employee
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: ../../index.php');
    exit();
}

require_once __DIR__ . '/../../config/config.php';

// Get the requested page
$page = basename($_SERVER['PHP_SELF']);

switch ($page) {
    case 'index.php':
        require_once __DIR__ . '/index.php';
        break;
    case 'fares.php':
        require_once __DIR__ . '/fares.php';
        break;
    case 'customers.php':
        require_once __DIR__ . '/customers.php';
        break;
    case 'requests.php':
        require_once __DIR__ . '/requests.php';
        break;
    case 'profile.php':
        require_once __DIR__ . '/profile.php';
        break;
    default:
        header('Location: index.php');
        exit();
}
?>
