<!-- Edit Customer Modal -->
<style>
    #editCustomerModal.modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(0,0,0,0.3);
        display: flex;
        justify-content: center;
        align-items: center;
    }
    #editCustomerModal.modal.show {
        display: flex !important;
    }
    #editCustomerModal .modal-content {
        margin: 0;
        position: relative;
        box-shadow: 0 2px 16px rgba(0,0,0,0.2);
    }
</style>
<div id="editCustomerModal" class="modal" style="display: none;">
    <div class="modal-content modal-max-width-500">
        <div class="modal-header">
            <h2>Edit Customer</h2>
            <button class="close-btn" onclick="document.getElementById('editCustomerModal').style.display = 'none'">×</button>
        </div>
        <div class="modal-body">
            <form id="editCustomerForm" method="POST" action="<?php echo BASE_URL; ?>admin/customers/update">
                <input type="hidden" name="action" value="edit_customer">
                <input type="hidden" id="editCustomerID" name="customer_id">
                <div class="form-group">
                    <label for="editCustomerName">Full Name *</label>
                    <input type="text" id="editCustomerName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="editCustomerContact">Contact Number *</label>
                    <input type="tel" id="editCustomerContact" name="contact" required placeholder="09xxxxxxxxx">
                </div>
                <div class="form-group">
                    <label for="editCustomerEmail">Email Address</label>
                    <input type="email" id="editCustomerEmail" name="email">
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Customer</button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('editCustomerModal').style.display = 'none'">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
