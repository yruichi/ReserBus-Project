<!-- Add/Edit Employee Modal -->
<div id="employeeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Add New Employee</h2>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form id="employeeForm" method="POST" action="<?php echo BASE_URL; ?>admin/employees/create" class="modal-form" onsubmit="return validateEmployeeForm()">
            <script>
            function validateEmployeeForm() {
                let valid = true;
                // Clear previous errors
                document.querySelectorAll('.error-msg').forEach(e => e.textContent = '');
                // Name
                const name = document.getElementById('modal-name').value.trim();
                if (!name) {
                    document.getElementById('name-error').textContent = 'Name is required.';
                    valid = false;
                }
                // Email
                const email = document.getElementById('modal-email').value.trim();
                if (!email) {
                    document.getElementById('email-error').textContent = 'Email is required.';
                    valid = false;
                } else if (!/^\S+@\S+\.\S+$/.test(email)) {
                    document.getElementById('email-error').textContent = 'Invalid email format.';
                    valid = false;
                }
                // Contact
                const contact = document.getElementById('modal-contact').value.trim();
                if (!contact) {
                    document.getElementById('contact-error').textContent = 'Contact is required.';
                    valid = false;
                }
                // Username
                const username = document.getElementById('modal-username').value.trim();
                if (!username) {
                    document.getElementById('username-error').textContent = 'Username is required.';
                    valid = false;
                }
                // Password
                const password = document.getElementById('modal-password').value;
                if (!password) {
                    document.getElementById('password-error').textContent = 'Password is required.';
                    valid = false;
                }
                return valid;
            }
            </script>
            <div class="form-field">
                <label for="modal-name">Full Name</label>
                <input type="text" id="modal-name" name="name" placeholder="Full name" required>
                <span class="error-msg" id="name-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-email">Email Address</label>
                <input type="email" id="modal-email" name="email" placeholder="example@reserbus.com" required>
                <span class="error-msg" id="email-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-contact">Contact Number</label>
                <input type="text" id="modal-contact" name="contact" placeholder="09XX-XXX-XXXX" required>
                <span class="error-msg" id="contact-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-username">Username</label>
                <input type="text" id="modal-username" name="username" placeholder="Username" required>
                <span class="error-msg" id="username-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-password">Password</label>
                <input type="password" id="modal-password" name="password" placeholder="Password" required>
                <span class="error-msg" id="password-error"></span>
            </div>
            <input type="hidden" id="modal-id" name="id" value="">
            <input type="hidden" id="modal-action" name="action" value="add">
            <script>
            // Dynamically set form action for add/edit
            function setEmployeeFormAction(isEdit) {
                const form = document.getElementById('employeeForm');
                const actionInput = document.getElementById('modal-action');
                if (isEdit) {
                    form.action = '<?php echo BASE_URL; ?>admin/employees/update';
                    actionInput.value = 'edit';
                } else {
                    form.action = '<?php echo BASE_URL; ?>admin/employees/create';
                    actionInput.value = 'add';
                }
            }
            // Hook into openAddModal/openEditModal
            window.setEmployeeFormAction = setEmployeeFormAction;
            </script>
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Save Employee</button>
                <button type="button" class="btn btn-secondary" style="flex: 1;" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>
