
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('bookTicketForm');
    if (!form) return;
    form.onsubmit = function(e) {
        e.preventDefault();
        const errorDiv = document.getElementById('bookTicketError');
        errorDiv.style.display = 'none';
        errorDiv.textContent = '';
        const formData = new FormData(form);
        formData.append('debug', '1');
        fetch(form.action, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => {
            const ct = res.headers.get('content-type') || '';
            if (ct.indexOf('application/json') !== -1) return res.json();
            return res.text().then(text => ({ success: false, error: 'Server error', details: text }));
        })
        .then(data => {
            if (data.success) {
                // Hide modal
                document.getElementById('bookTicketModal').style.display = 'none';
                // Insert new row into table
                if (data.customerRowHtml) {
                    const tbody = document.getElementById('customersTableBody');
                    if (tbody) {
                        // Insert at the top
                        const temp = document.createElement('tbody');
                        temp.innerHTML = data.customerRowHtml.trim();
                        // Find the first tr (row) in the temp tbody
                        let newRow = null;
                        for (let i = 0; i < temp.childNodes.length; i++) {
                            if (temp.childNodes[i].nodeName === 'TR') {
                                newRow = temp.childNodes[i];
                                break;
                            }
                        }
                        if (newRow) tbody.insertBefore(newRow, tbody.firstChild);
                        // Scroll table to top for visibility
                        const tableWrapper = document.querySelector('.table-wrapper');
                        if (tableWrapper) tableWrapper.scrollTop = 0;
                    }
                }
                // Show notification
                let notif = document.createElement('div');
                notif.className = 'alert alert-success';
                notif.textContent = 'Booking successful! Confirmation email sent.';
                notif.style.position = 'fixed';
                notif.style.top = '20px';
                notif.style.left = '50%';
                notif.style.transform = 'translateX(-50%)';
                notif.style.zIndex = 9999;
                notif.style.minWidth = '300px';
                notif.style.textAlign = 'center';
                document.body.appendChild(notif);
                setTimeout(() => { notif.remove(); }, 3000);
                form.reset();
            } else {
                let msg = data.error || 'Booking failed.';
                if (data.details) {
                    if (typeof data.details === 'object') {
                        msg += '\nDetails: ' + JSON.stringify(data.details);
                    } else {
                        msg += '\nDetails: ' + data.details;
                    }
                }
                errorDiv.textContent = msg;
                errorDiv.style.display = 'block';
            }
        })
        .catch(() => {
            errorDiv.textContent = 'Booking failed. Please try again.';
            errorDiv.style.display = 'block';
        });
        return false;
    };
});
