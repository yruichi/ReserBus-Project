<!-- Tickets Modal -->
<?php
// Include shared fares data
if (!isset($fares)) {
    require_once __DIR__ . '/../../config/database.php';
    $conn = Database::getConnection();
    $fares = $conn->query('SELECT * FROM Fare')->fetchAll();
}
?>
<div id="ticketsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Manage Available Tickets - <span id="tickets-employee-name"></span></h2>
            <button class="close-btn" onclick="closeTicketsModal()">&times;</button>
        </div>
        <form id="ticketsForm" method="POST" action="<?php echo BASE_URL; ?>admin/employees/update-tickets" class="modal-form" onsubmit="return confirmTicketsUpdate()">
            <div style="max-height: 400px; overflow-y: auto; margin-bottom: 20px;">
                <table class="employees-table" style="font-size: 12px;">
                    <thead>
                        <tr>
                            <th>Destination</th>
                            <th style="width: 80px;">One Way</th>
                            <th style="width: 80px;">Roundtrip</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fares as $fare): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fare['Destination']); ?></td>
                                <td>
                                    <input type="number" name="tickets[<?php echo htmlspecialchars($fare['Destination']); ?>][one_way]" 
                                           value="0" min="0" style="width: 60px; padding: 4px;">
                                </td>
                                <td>
                                    <input type="number" name="tickets[<?php echo htmlspecialchars($fare['Destination']); ?>][roundtrip]" 
                                           value="0" min="0" style="width: 60px; padding: 4px;">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <input type="hidden" id="tickets-modal-id" name="id" value="">
            <input type="hidden" name="action" value="edit_tickets">
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Update Tickets</button>
                <button type="button" class="btn btn-secondary" style="flex: 1;" onclick="closeTicketsModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>
<script>
    function openTicketsModal(id, name, availableTickets) {
        document.getElementById('tickets-modal-id').value = id;
        document.getElementById('tickets-employee-name').textContent = name;
        // Populate ticket values if availableTickets is provided
        if (availableTickets && typeof availableTickets === 'object') {
            Object.keys(availableTickets).forEach(function(dest) {
                var oneWay = availableTickets[dest]?.one_way ?? 0;
                var roundTrip = availableTickets[dest]?.roundtrip ?? 0;
                var oneWayInput = document.querySelector('input[name="tickets['+dest+'][one_way]"]');
                var roundTripInput = document.querySelector('input[name="tickets['+dest+'][roundtrip]"]');
                if (oneWayInput) oneWayInput.value = oneWay;
                if (roundTripInput) roundTripInput.value = roundTrip;
            });
        }
        document.getElementById('ticketsModal').classList.add('show');
    }
    function closeTicketsModal() {
        document.getElementById('ticketsModal').classList.remove('show');
    }
    function confirmTicketsUpdate() {
        const name = document.getElementById('tickets-employee-name').textContent;
        return confirm(`Update ticket availability for ${name}?`);
    }
    window.onclick = function(event) {
        const ticketsModal = document.getElementById('ticketsModal');
        if (event.target === ticketsModal) {
            ticketsModal.classList.remove('show');
        }
    }
</script>
