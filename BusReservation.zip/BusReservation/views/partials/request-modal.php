<!-- Request Modal -->
<div id="requestModal" class="modal" style="display:none;">
    <div class="modal-content modal-max-width-500">
        <div class="modal-header">
            <h2>Submit Cancellation / Refund Request</h2>
            <button class="close-btn" onclick="closeRequestModal()">×</button>
        </div>

        <div class="modal-body">
            <p class="modal-info-text">
                Customer: <strong id="requestCustomerName"></strong>
            </p>
            <p class="modal-info-text">
                Ticket ID: <strong id="requestTicketIDText"></strong>
            </p>

            <form id="requestForm" method="POST" action="?page=employee/customers" onsubmit="return validateRequestForm()">
                <input type="hidden" name="action" value="submit_request">
                <input type="hidden" id="requestCustomerID" name="customer_id">
                <input type="hidden" id="requestTicketIDInput" name="ticket_id">

                <div class="form-group">
                    <label for="requestType">Request Type *</label>
                    <select id="requestType" name="request_type" required>
                        <option value="">Select type</option>
                        <option value="Cancellation">Cancellation</option>
                        <option value="Refund">Refund</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="requestReason">Reason *</label>
                    <textarea
                        id="requestReason"
                        name="reason"
                        rows="4"
                        required
                        placeholder="Enter the reason for this request"
                    ></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                    <button type="button" class="btn btn-secondary" onclick="closeRequestModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Modal controls
function closeRequestModal() {
    document.getElementById('requestModal').style.display = 'none';
}

// Simple client-side validation for request modal
function validateRequestForm() {
    var type = document.getElementById('requestType').value;
    var reason = document.getElementById('requestReason').value.trim();
    if (!type) {
        alert('Please select a request type.');
        document.getElementById('requestType').focus();
        return false;
    }
    if (!reason) {
        alert('Please enter a reason for the request.');
        document.getElementById('requestReason').focus();
        return false;
    }
    return true;
}
</script>