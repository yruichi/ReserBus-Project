<!-- View Ticket Modal -->
<div id="viewTicketModal" class="modal" style="display:none; align-items:center; justify-content:center;">
    <div class="modal-content modal-max-width-500">
        <div class="modal-header">
            <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                <h2 style="margin:0;">Ticket Details</h2>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <button class="btn btn-sm btn-info" onclick="printTicketDetails()">🖨️ Print</button>
                    <button class="close-btn" onclick="closeViewTicketModal()" style="font-size: 28px; margin-left: 10px;">&times;</button>
                </div>
            </div>
        </div>
        <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
            <table class="ticket-details-table">
                <tr><th>Ticket ID</th><td id="modalTicketId"></td></tr>
                <tr><th>Customer ID</th><td id="modalCustomerId"></td></tr>
                <tr><th>Customer Name</th><td id="modalCustomerName"></td></tr>
                <tr><th>Contact</th><td id="modalCustomerContact"></td></tr>
                <tr><th>Email</th><td id="modalCustomerEmail"></td></tr>
                <tr><th>Booked Date</th><td id="modalBookedDate"></td></tr>
                <tr><th>Departure Date</th><td id="modalDepartureDate"></td></tr>
                <tr><th>Return Date</th><td id="modalReturnDate"></td></tr>
                <tr><th>Ticket Type</th><td id="modalTicketType"></td></tr>
                <tr><th>Destination</th><td id="modalDestination"></td></tr>
                <tr><th>Price</th><td id="modalPrice"></td></tr>
                <tr><th>Quantity</th><td id="modalQuantity"></td></tr>
                <tr><th>Total Amount</th><td id="modalTotalAmount"></td></tr>
                <tr><th>Request ID</th><td id="modalRequestId"></td></tr>
                <tr><th>Request Type</th><td id="modalRequestType"></td></tr>
                <tr><th>Reason</th><td id="modalReason"></td></tr>
                <tr><th>Status</th><td id="modalStatus"></td></tr>
            </table>
            <div id="ticketReferenceNote" style="margin-top:18px; font-size:15px; color:#374151; background:#f3f4f6; padding:10px 14px; border-radius:6px;">
                <strong>Note:</strong> This ticket serves as your official booking reference. Please keep a copy for your records. You may use this ticket as proof of reservation and for any related customer service requests.
            </div>
        </div>
    </div>
</div>
<script>
function closeViewTicketModal() {
    document.getElementById('viewTicketModal').style.display = 'none';
}

window.addEventListener('click', function(event) {
    var modal = document.getElementById('viewTicketModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});


function printTicketDetails() {
    var table = document.querySelector('#viewTicketModal .ticket-details-table');
    if (!table) return;
    var win = window.open('', '', 'width=700,height=600');
    win.document.write('<html><head><title>Print Ticket Details</title>');
    win.document.write('<style>\n');
        win.document.write('body{font-family:sans-serif;margin:24px;} .ticket-details-table{border-collapse:collapse;width:100%;} .ticket-details-table th,.ticket-details-table td{border:1px solid #333;padding:8px 12px;text-align:left;} .ticket-details-table th{background:#f3f4f6;} h2{text-align:center;}');
    win.document.write('</style>');
    win.document.write('</head><body>');
    win.document.write('<h2>Ticket Details</h2>');
    win.document.write(table.outerHTML);
        win.document.write('<div style="margin-top:18px; font-size:15px; color:#374151; background:#f3f4f6; padding:10px 14px; border-radius:6px;"'
            + '><strong>Note:</strong> This ticket serves as your official booking reference. Please keep a copy for your records. You may use this ticket as proof of reservation and for any related customer service requests.</div>');
    win.document.write('</body></html>');
    win.document.close();
    win.focus();
        // Wait for content to render before printing
        setTimeout(function(){
            win.print();
            win.close();
        }, 400);
}
</script>
