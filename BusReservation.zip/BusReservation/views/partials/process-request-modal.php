<?php
require_once __DIR__ . '/../../utils/send_booking_email.php';
// sendBookingEmail($to, $ticketId, $passengerNames, $destination, $ticketType, $bookingDate, $departureDate, $departureTime);
?>
<!-- Process Request Modal -->
<div id="processRequestModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Process Customer Request</h2>
            <button class="close-btn" onclick="closeProcessModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <p><strong>Customer:</strong> <span id="process-customer-name"></span></p>
                <p><strong>Request Type:</strong> <span id="process-request-type" style="color: #dc2626; font-weight: 600;"></span></p>
                <p><strong>Reason:</strong> <span id="process-reason"></span></p>
                <p><strong>Ticket ID:</strong> <span id="process-ticket-id"></span></p>
            </div>
            
            <p style="margin-bottom: 15px; color: #374151;">Select an action to process this request:</p>
            
            <form id="processRequestForm" method="POST" action="<?php echo BASE_URL; ?>index.php?page=admin/customers">
                <input type="hidden" name="action" value="process_request">
                <input type="hidden" name="request_id" id="process-request-id">
                <input type="hidden" name="ticket_id" id="process-ticket-id-input">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px;">
                    <button type="submit" name="status" value="Approved" class="btn" style="background: #10b981; color: white; padding: 12px; font-size: 14px; border: none; border-radius: 6px; cursor: pointer;">
                        ✓ Approve Request
                    </button>
                    <button type="submit" name="status" value="Rejected" class="btn" style="background: #ef4444; color: white; padding: 12px; font-size: 14px; border: none; border-radius: 6px; cursor: pointer;">
                        ✕ Reject Request
                    </button>
                </div>
                
                <div class="form-field">
                </div>
            </form>
            
            <button type="button" class="btn btn-secondary" onclick="closeProcessModal()" style="width: 100%; margin-top: 10px;">Cancel</button>
        </div>
    </div>
</div>
