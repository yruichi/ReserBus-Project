<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = isset($_GET['page']) ? $_GET['page'] : '';
?>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600&display=swap" rel="stylesheet">
<style>
    .employee-sidebar, .employee-sidebar * {
        font-family: 'Poppins', Arial, sans-serif !important;
    }
</style>
<aside class="employee-sidebar">
    <div class="logo-section">
        <img src="<?php echo ASSETS_URL; ?>images/ReserBusLogo.png" alt="ReserBus Logo">
        <p class="employee-badge" style="color: #000; text-transform: none; font-size: 1.0rem; font-weight: 500;">EMPLOYEE PORTAL</p>
    </div>
    <div class="menu-label">Menu</div>
    <div class="nav-menu">
        <a href="<?php echo BASE_URL; ?>index.php?page=employee/dashboard" class="nav-item <?php echo ($current_page == 'employee/dashboard' || $current_page == '') ? 'active' : ''; ?>">
            <span class="nav-icon">📊</span>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>index.php?page=employee/fares" class="nav-item <?php echo $current_page == 'employee/fares' ? 'active' : ''; ?>">
            <span class="nav-icon">💰</span>
            <span>Fares</span>
        </a>
        <a href="<?php echo BASE_URL; ?>index.php?page=employee/customers" class="nav-item <?php echo $current_page == 'employee/customers' ? 'active' : ''; ?>">
            <span class="nav-icon">👥</span>
            <span>Customers</span>
        </a>
        <a href="<?php echo BASE_URL; ?>index.php?page=employee/profile" class="nav-item <?php echo $current_page == 'employee/profile' ? 'active' : ''; ?>">
            <span class="nav-icon">⚙️</span>
            <span>Profile</span>
        </a>
    </div>

    <div class="logout-section">
        <a href="<?php echo BASE_URL; ?>index.php?page=auth/logout" class="logout-btn" onclick="return confirm('Are you sure you want to log out?');">
            <span class="nav-icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
</aside>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.employee-sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

document.querySelectorAll('.employee-sidebar .nav-link').forEach(link => {
    link.addEventListener('click', function() {
        if (window.innerWidth <= 768) {
            toggleSidebar();
        }
    });
});
</script>
