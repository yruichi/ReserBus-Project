<!-- View Customer Modal -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Customer Details</h2>
            <button class="close-btn" onclick="closeViewModal()">&times;</button>
        </div>
        <div style="display: flex; flex-direction: column; gap: 15px;">
            <div style="display: grid; grid-template-columns: 150px 1fr; gap: 10px; padding: 10px; background: #f9fafb; border-radius: 6px;">
                <strong>Customer ID:</strong><span id="view-customer-id"></span>
                <strong>Ticket ID:</strong><span id="view-ticket-id"></span>
                <strong>Name:</strong><span id="view-name"></span>
                <strong>Contact:</strong><span id="view-contact"></span>
                <strong>Email:</strong><span id="view-email"></span>
                <strong>Booked Date:</strong><span id="view-booked"></span>
                <strong>Departure Date:</strong><span id="view-departure"></span>
                <strong>Passengers:</strong><span id="view-passengers"></span>
                <strong>Request ID:</strong><span id="view-request-id"></span>
                <strong>Request Type:</strong><span id="view-request"></span>
                <strong>Reason:</strong><span id="view-reason"></span>
                <strong>Status:</strong><span id="view-status"></span>
            </div>
            <button class="btn btn-secondary" onclick="closeViewModal()" style="align-self: flex-end;">Close</button>
        </div>
    </div>
</div>
