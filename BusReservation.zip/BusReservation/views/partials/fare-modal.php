<!-- Edit Fare Modal -->
<div id="fareModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Add New Fare</h2>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form id="fareForm" method="POST" action="<?php echo BASE_URL; ?>admin/fares/create" class="modal-form" onsubmit="return validateAndConfirm()">
            <div class="form-field">
                <label for="modal-destination">Destination</label>
                <input type="text" id="modal-destination" name="destination" placeholder="e.g., Baguio" required>
                <span class="error-msg" id="destination-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-one-way">One Way Price (₱)</label>
                <input type="number" id="modal-one-way" name="one_way" placeholder="0.00" step="0.01" min="0" required>
                <span class="error-msg" id="one-way-error"></span>
            </div>
            <div class="form-field">
                <label for="modal-roundtrip">Round-Trip Price (₱)</label>
                <input type="number" id="modal-roundtrip" name="roundtrip" placeholder="0.00" step="0.01" min="0" required>
                <span class="error-msg" id="roundtrip-error"></span>
            </div>
            <input type="hidden" id="modal-id" name="id" value="">
            <div class="button-flex-container">
                <button type="submit" class="btn btn-primary button-flex-1">Save Fare</button>
                <button type="button" class="btn btn-secondary button-flex-1" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('modalTitle').textContent = 'Add New Fare';
        document.getElementById('fareForm').reset();
        document.getElementById('fareForm').action = '<?php echo BASE_URL; ?>admin/fares/create';
        clearErrors();
        document.getElementById('modal-id').value = '';
        document.getElementById('fareModal').classList.add('show');
    }

    function openEditModal(id, destination, oneWay, roundtrip) {
        document.getElementById('modalTitle').textContent = 'Edit Fare';
        document.getElementById('fareForm').action = '<?php echo BASE_URL; ?>admin/fares/update/' + id;
        document.getElementById('modal-destination').value = destination;
        document.getElementById('modal-one-way').value = oneWay;
        document.getElementById('modal-roundtrip').value = roundtrip;
        document.getElementById('modal-id').value = id;
        clearErrors();
        document.getElementById('fareModal').classList.add('show');
    }

    function closeModal() {
        document.getElementById('fareModal').classList.remove('show');
        clearErrors();
    }

    window.onclick = function(event) {
        const modal = document.getElementById('fareModal');
        if (event.target === modal) {
            modal.classList.remove('show');
            clearErrors();
        }
    }

    function clearErrors() {
        document.querySelectorAll('.error-msg').forEach(el => el.textContent = '');
    }

    function validateForm() {
        clearErrors();
        let isValid = true;

        const destination = document.getElementById('modal-destination').value.trim();
        const oneWay = document.getElementById('modal-one-way').value;
        const roundtrip = document.getElementById('modal-roundtrip').value;

        if (!destination) {
            document.getElementById('destination-error').textContent = 'Destination is required';
            isValid = false;
        }

        if (!oneWay || oneWay <= 0) {
            document.getElementById('one-way-error').textContent = 'One way price must be greater than 0';
            isValid = false;
        }

        if (!roundtrip || roundtrip <= 0) {
            document.getElementById('roundtrip-error').textContent = 'Round-trip price must be greater than 0';
            isValid = false;
        }

        if (oneWay && roundtrip && parseFloat(roundtrip) <= parseFloat(oneWay)) {
            document.getElementById('roundtrip-error').textContent = 'Round-trip price should be higher than one way price';
            isValid = false;
        }

        return isValid;
    }

    function validateAndConfirm() {
        if (!validateForm()) {
            return false;
        }
        
        const destination = document.getElementById('modal-destination').value.trim();
        const isEdit = document.getElementById('modal-id').value !== '';
        const message = isEdit 
            ? `Are you sure you want to update the fare for ${destination}?`
            : `Are you sure you want to add a new fare for ${destination}?`;

        return confirm(message);
    }
</script>
