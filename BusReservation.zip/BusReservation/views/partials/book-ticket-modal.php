<!-- Book Ticket Modal -->
<?php
// Fetch destinations from database
require_once __DIR__ . '/../../config/database.php';
$conn = Database::getConnection();
$fares = [];
if ($conn) {
    $stmt = $conn->query("SELECT FareID, Destination, OneWayPrice, RoundTripPrice FROM Fare WHERE IsActive = 1 ORDER BY Destination");
    $fares = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<div id="bookTicketModal" class="modal" style="display: none;">
    <div class="modal-content modal-max-width-600">
        <div class="modal-header">
            <h2>Book Ticket</h2>
            <button class="close-btn" onclick="document.getElementById('bookTicketModal').style.display = 'none'">×</button>
        </div>
        <div class="modal-body modal-body-scrollable">
            <form id="bookTicketForm" method="POST" action="?page=employee/customers" onsubmit="return validateBookTicketForm()">
                                <div id="bookTicketError" style="color: red; font-weight: bold; margin-bottom: 10px;"></div>
                <input type="hidden" name="action" value="book_ticket">
                
                <div class="form-group">
                    <label for="customerName">Customer Name *</label>
                    <input type="text" id="customerName" name="customer_name" required>
                </div>

                <div class="form-group">
                    <label for="customerEmail">Email Address *</label>
                    <input type="email" id="customerEmail" name="customer_email" required>
                </div>

                <div class="form-group">
                    <label for="customerContact">Contact Number *</label>
                    <input type="tel" id="customerContact" name="customer_contact" required placeholder="09xxxxxxxxx">
                </div>


                <div class="form-group">
                    <label for="numPax">Quantity *</label>
                    <input type="number" id="numPax" name="num_pax" min="1" max="10" value="1" required onchange="updateTicketPrices()">
                    <span id="ticketLimitError" style="color: #e74c3c; font-size: 13px;"></span>
                </div>

                <div class="form-group">
                    <label for="ticketDestination">Destination *</label>
                    <select id="ticketDestination" name="destination" required onchange="updateTicketPrices()">
                        <option value="">Select destination</option>
                        <?php foreach ($fares as $fare): ?>
                        <option value="<?php echo htmlspecialchars($fare['Destination']); ?>" 
                                data-fareid="<?php echo $fare['FareID']; ?>"
                                data-oneway="<?php echo $fare['OneWayPrice']; ?>" 
                                data-roundtrip="<?php echo $fare['RoundTripPrice']; ?>">
                            <?php echo htmlspecialchars($fare['Destination']); ?> (₱<?php echo number_format($fare['OneWayPrice'], 2); ?> / ₱<?php echo number_format($fare['RoundTripPrice'], 2); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="ticketType">Ticket Type *</label>
                    <select id="ticketType" name="ticket_type" required onchange="updateTicketPrices()">
                        <option value="">Select type</option>
                        <option value="one-way">One-Way</option>
                        <option value="round-trip">Round-Trip</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="departureDate">Departure Date *</label>
                    <input type="date" id="departureDate" name="departure_date" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group" id="returnDateGroup" style="display:none;">
                    <label for="returnDate">Return Date *</label>
                    <input type="date" id="returnDate" name="return_date" min="<?php echo date('Y-m-d'); ?>">
                </div>

                <div class="form-group">
                    <label for="pricePerTicketInput">Price per Ticket *</label>
                    <input type="text" id="pricePerTicketInput" name="price_per_ticket" readonly required value="0.00" style="width: 100px; text-align: right;">
                </div>

                <div class="form-group">
                    <label for="totalPriceInput">Total Price *</label>
                    <input type="text" id="totalPriceInput" name="total_price" readonly required value="0.00" style="width: 100px; text-align: right;">
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Book Ticket</button>

                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('bookTicketModal').style.display = 'none'">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function openBookTicketModal() {
        document.getElementById('bookTicketModal').style.display = 'flex';
    }

    function updateTicketPrices() {
        const ticketType = document.getElementById('ticketType');
        const destination = document.getElementById('ticketDestination');
        const ticketTypeValue = ticketType.value;
        // Show/hide return date field
        const returnDateGroup = document.getElementById('returnDateGroup');
        const returnDateInput = document.getElementById('returnDate');
        if (ticketTypeValue === 'round-trip') {
            returnDateGroup.style.display = '';
            returnDateInput.required = true;
            // Set min return date to departure date if selected
            const depDate = document.getElementById('departureDate').value;
            if (depDate) {
                returnDateInput.min = depDate;
            } else {
                returnDateInput.min = returnDateInput.getAttribute('min');
            }
        } else {
            returnDateGroup.style.display = 'none';
            returnDateInput.required = false;
            returnDateInput.value = '';
        }
        const numPax = parseInt(document.getElementById('numPax').value) || 1;
        const errorSpan = document.getElementById('ticketLimitError');
        errorSpan.textContent = '';

        let price = 0;
        let total = 0;
        if (destination.value && ticketType.value) {
            const selectedOption = destination.options[destination.selectedIndex];
            price = ticketType.value === 'one-way' 
                ? parseFloat(selectedOption.getAttribute('data-oneway')) 
                : parseFloat(selectedOption.getAttribute('data-roundtrip'));
            total = price * numPax;
            document.getElementById('pricePerTicketInput').value = price.toFixed(2);
            document.getElementById('totalPriceInput').value = total.toFixed(2);

            // Validation: check available tickets for this employee
            if (window.employeeAvailableTickets) {
                const avail = window.employeeAvailableTickets[destination.value];
                if (avail) {
                    const availCount = ticketType.value === 'one-way' ? (avail.one_way || 0) : (avail.roundtrip || 0);
                    if (numPax > availCount) {
                        errorSpan.textContent = `You can only book up to ${availCount} ${ticketType.value.replace('-', ' ')} ticket(s) for this destination.`;
                    }
                }
            }
        } else {
            document.getElementById('pricePerTicketInput').value = '0.00';
            document.getElementById('totalPriceInput').value = '0.00';
        }
    }

    // Ensure return date field is correct on first load
    document.addEventListener('DOMContentLoaded', function() {
        updateTicketPrices();
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('bookTicketModal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
    function validateBookTicketForm() {
            const ticketTypeValue = document.getElementById('ticketType').value;
            const returnDate = document.getElementById('returnDate').value;
        const errorDiv = document.getElementById('bookTicketError');
        errorDiv.textContent = '';
        errorDiv.style.display = 'none';

        // Required fields
        const name = document.getElementById('customerName').value.trim();
        const email = document.getElementById('customerEmail').value.trim();
        const contact = document.getElementById('customerContact').value.trim();
        const numPax = parseInt(document.getElementById('numPax').value) || 1;
        const destination = document.getElementById('ticketDestination').value;
        const ticketType = document.getElementById('ticketType').value;
        const departureDate = document.getElementById('departureDate').value;

        if (!name) {
            errorDiv.textContent = 'Customer name is required.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!email) {
            errorDiv.textContent = 'Email address is required.';
            errorDiv.style.display = 'block';
            return false;
        } else if (!/^\S+@\S+\.\S+$/.test(email)) {
            errorDiv.textContent = 'Invalid email format.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!contact) {
            errorDiv.textContent = 'Contact number is required.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!numPax || numPax < 1 || numPax > 10) {
            errorDiv.textContent = 'Number of passengers must be between 1 and 10.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!destination) {
            errorDiv.textContent = 'Destination is required.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!ticketType) {
            errorDiv.textContent = 'Ticket type is required.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (!departureDate) {
            errorDiv.textContent = 'Departure date is required.';
            errorDiv.style.display = 'block';
            return false;
        }
        if (ticketTypeValue === 'round-trip') {
            if (!returnDate) {
                errorDiv.textContent = 'Return date is required for round-trip.';
                errorDiv.style.display = 'block';
                return false;
            }
            if (returnDate < departureDate) {
                errorDiv.textContent = 'Return date cannot be before departure date.';
                errorDiv.style.display = 'block';
                return false;
            }
        }
    // Update return date min when departure date changes
    document.getElementById('departureDate').addEventListener('change', function() {
        const depDate = this.value;
        const returnDateInput = document.getElementById('returnDate');
        if (depDate) {
            returnDateInput.min = depDate;
        } else {
            returnDateInput.min = returnDateInput.getAttribute('min');
        }
    });

    // Show/hide return date on load (in case of form repop)
    document.getElementById('ticketType').addEventListener('change', updateTicketPrices);

        // Check available tickets for employee
        let availCount = 0;
        if (window.employeeAvailableTickets && window.employeeAvailableTickets[destination]) {
            const avail = window.employeeAvailableTickets[destination];
            availCount = ticketType === 'one-way' ? (avail.one_way || 0) : (avail.roundtrip || 0);
        }
        if (numPax > availCount) {
            errorDiv.textContent = `Cannot book ${numPax} tickets. Only ${availCount} ${ticketType.replace('-', ' ')} ticket(s) available for this destination.`;
            errorDiv.style.display = 'block';
            document.getElementById('numPax').focus();
            return false;
        }

        return true;
    }
</script>

