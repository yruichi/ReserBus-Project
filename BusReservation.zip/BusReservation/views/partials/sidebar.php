
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>


<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600&display=swap" rel="stylesheet">
<style>
    .employee-sidebar, .employee-sidebar * {
        font-family: 'Poppins', Arial, sans-serif !important;
    }
</style>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<aside class="employee-sidebar">
    <div class="logo-section">
        <img src="<?php echo ASSETS_URL; ?>images/ReserBusLogo.png" alt="ReserBus Logo">
        <p class="admin-badge" style="color: #000; text-transform: none; font-size: 1.0rem; font-weight: 500;">ADMIN PORTAL</p>
    </div>
    <div class="menu-label">Menu</div>
    <div class="nav-menu">
        <a href="<?php echo BASE_URL; ?>admin/dashboard" class="nav-item <?php echo (strpos($_SERVER['REQUEST_URI'], 'dashboard') !== false) ? 'active' : ''; ?>">
            <span class="nav-icon">📊</span>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/fares" class="nav-item <?php echo (strpos($_SERVER['REQUEST_URI'], 'fares') !== false) ? 'active' : ''; ?>">
            <span class="nav-icon">💰</span>
            <span>Fares</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/employees" class="nav-item <?php echo (strpos($_SERVER['REQUEST_URI'], 'employees') !== false) ? 'active' : ''; ?>">
            <span class="nav-icon">👥</span>
            <span>Employees</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/customers" class="nav-item <?php echo (strpos($_SERVER['REQUEST_URI'], 'customers') !== false) ? 'active' : ''; ?>">
            <span class="nav-icon">👤</span>
            <span>Customers</span>
        </a>
    </div>

    <div class="logout-section">
        <a href="<?php echo BASE_URL; ?>auth/logout" class="logout-btn" onclick="return confirm('Are you sure you want to log out?');">
            <span class="nav-icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
</aside>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.employee-sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}
</script>
