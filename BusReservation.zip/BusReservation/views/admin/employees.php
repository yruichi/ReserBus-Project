<?php
ob_start(); // Start output buffering to prevent any stray output

require_once __DIR__ . '/../../models/Employee.php';
$employeeModel = new Employee();

// Always fetch the latest employees from the database
$employees = $employeeModel->getAll();

// Get ticket availability for all employees
$employeeTickets = [];
if (!empty($employees)) {
    foreach ($employees as $emp) {
        $employeeTickets[$emp['EmployeeID']] = $employeeModel->getTicketAvailability($emp['EmployeeID']);
    }
}

// Handle edit_tickets action
ob_end_flush(); // Send buffered content
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees Management - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body>
    <?php include __DIR__ . '/../partials/sidebar.php'; ?>


    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Manage Employees</h1>
                <p>View and manage employee accounts and performance</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success" style="background:#d1fae5;color:#065f46;padding:10px 16px;margin-bottom:16px;border-radius:4px;font-weight:600;">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error" style="background:#fee2e2;color:#991b1b;padding:10px 16px;margin-bottom:16px;border-radius:4px;font-weight:600;">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="content-card">

            <?php 
            if (isset($_SESSION['success'])) {
                echo "<div class='success-message' style='background:#d1fae5;color:#065f46;padding:10px 16px;margin-bottom:16px;border-radius:4px;font-weight:600;'>" . htmlspecialchars($_SESSION['success']) . "</div>";
                unset($_SESSION['success']);
            }
            if (isset($_SESSION['error'])) {
                echo "<div class='error-message' style='background:#fee2e2;color:#991b1b;padding:10px 16px;margin-bottom:16px;border-radius:4px;font-weight:600;'>" . htmlspecialchars($_SESSION['error']) . "</div>";
                unset($_SESSION['error']);
            }
            ?>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div class="section-title" style="margin: 0; flex: 1; padding-bottom: 10px;">Employees</div>
                <div style="display:flex; gap:8px;">
                    <button class="btn btn-primary" onclick="openAddModal()">+ Add Employee</button>
                    <button id="bulkDeleteBtn" class="btn btn-danger" onclick="bulkDelete()" disabled>Delete</button>
                </div>
            </div>

            <!-- Hidden form for bulk delete -->
            <form id="bulkDeleteForm" method="POST" action="<?php echo BASE_URL; ?>admin/employees/bulk-delete" style="display:none;">
            </form>

            <div class="search-filter-bar">
                <input type="text" class="search-input" id="searchInput" placeholder="Search by name or username..." onkeyup="filterTable()">
                <div class="sort-controls">
                    <label for="sortSelect">Sort By:</label>
                    <select id="sortSelect" onchange="sortTable()">
                        <option value="">Select...</option>
                        <option value="name-asc">Name (A–Z)</option>
                        <option value="name-desc">Name (Z–A)</option>
                        <option value="date-newest">Date Added (Newest)</option>
                        <option value="date-oldest">Date Added (Oldest)</option>
                        <option value="sales-high">Total Sales (High → Low)</option>
                        <option value="sales-low">Total Sales (Low → High)</option>
                    </select>
                </div>
            </div>

        <div class="table-wrapper" style="max-height: 500px; overflow-y: auto;">
            <table class="employees-table">
                    <thead>
                        <tr>
                            <th style="width:32px;">
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                            </th>
                            <th>Employee ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Date Added</th>
                            <th>Total Sales</th>
                            <th>Monthly Sales</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="employeesTableBody">
                        <?php if (!empty($employees)): ?>
                            <?php foreach ($employees as $employee): ?>
                                <tr class="employee-row" data-name="<?php echo htmlspecialchars($employee['Name']); ?>" data-username="<?php echo htmlspecialchars($employee['Username']); ?>">
                                    <td>
                                        <input type="checkbox" class="row-select" value="<?php echo $employee['EmployeeID']; ?>" onchange="updateBulkDeleteState()">
                                    </td>
                                <td>E<?php echo str_pad($employee['EmployeeID'], 10, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($employee['Name']); ?></td>
                                <td><?php echo htmlspecialchars($employee['Email']); ?></td>
                                <td><?php echo htmlspecialchars($employee['Contact']); ?></td>
                                <td><?php echo htmlspecialchars($employee['Username']); ?></td>
                                <td>
                                    <span class="password-hidden" id="pwd-<?php echo $employee['EmployeeID']; ?>">••••••••</span>
                                    <span class="password-shown" id="pwd-show-<?php echo $employee['EmployeeID']; ?>" style="display:none;"><?php echo htmlspecialchars($employee['Password']); ?></span>
                                    <button type="button" class="btn btn-sm" onclick="togglePassword(<?php echo $employee['EmployeeID']; ?>)" style="margin-left: 5px; padding: 2px 8px; font-size: 11px;">Show</button>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($employee['Date_Added'])); ?></td>
                                <td>₱<?php echo number_format($employee['Total_Sales'] ?? 0, 2); ?></td>
                                <td>₱<?php echo number_format($employee['Monthly_Sales'] ?? 0, 2); ?></td>
                                <td class="actions">
                                    <button class="btn btn-edit" onclick='openEditModal(<?php echo $employee["EmployeeID"]; ?>, "<?php echo htmlspecialchars($employee["Name"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($employee["Email"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($employee["Contact"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($employee["Username"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($employee["Password"], ENT_QUOTES); ?>")'>Edit</button>
                                    <button class="btn btn-edit" style="background: #8b5cf6;" onclick='openTicketsModal(<?php echo $employee["EmployeeID"]; ?>, "<?php echo htmlspecialchars($employee["Name"], ENT_QUOTES); ?>", <?php echo json_encode($employeeTickets[$employee["EmployeeID"]] ?? []); ?>)'>Tickets</button>
                                    <form method="POST" action="<?php echo BASE_URL; ?>admin/employees/delete/<?php echo $employee['EmployeeID']; ?>" style="display: inline;">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this employee?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="13" style="text-align: center; padding: 20px;">No employees found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <?php include __DIR__ . '/../partials/employee-modal.php'; ?>
    <?php include __DIR__ . '/../partials/tickets-modal.php'; ?>

    <script>

        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Add New Employee';
            document.getElementById('employeeForm').reset();
            clearErrors();
            document.getElementById('modal-id').value = '';
            setEmployeeFormAction(false);
            document.getElementById('employeeModal').classList.add('show');
        }

        function openEditModal(id, name, email, contact, username, password) {
            document.getElementById('modalTitle').textContent = 'Edit Employee';
            document.getElementById('modal-name').value = name;
            document.getElementById('modal-email').value = email;
            document.getElementById('modal-contact').value = contact;
            document.getElementById('modal-username').value = username;
            document.getElementById('modal-password').value = password || '';
            document.getElementById('modal-id').value = id;
            setEmployeeFormAction(true);
            clearErrors();
            document.getElementById('employeeModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('employeeModal').classList.remove('show');
            clearErrors();
        }

        window.onclick = function(event) {
            const modal = document.getElementById('employeeModal');
            if (event.target === modal) {
                modal.classList.remove('show');
                clearErrors();
            }
        }

        function clearErrors() {
            document.querySelectorAll('.error-msg').forEach(el => el.textContent = '');
        }

        function validateForm() {
            clearErrors();
            let isValid = true;

            const email = document.getElementById('modal-email').value.trim();
            const contact = document.getElementById('modal-contact').value.trim();
            const username = document.getElementById('modal-username').value.trim();
            const password = document.getElementById('modal-password').value.trim();
            const isAdd = document.getElementById('modal-action').value === 'add';

            if (isAdd) {
                const employeeId = document.getElementById('modal-employee-id').value.trim();
                const employeeName = document.getElementById('modal-employee-name').value.trim();

                if (!employeeId) {
                    document.getElementById('employee-id-error').textContent = 'Employee ID is required';
                    isValid = false;
                }

                if (!employeeName) {
                    document.getElementById('employee-name-error').textContent = 'Employee name is required';
                    isValid = false;
                }
            }

            if (!email) {
                document.getElementById('email-error').textContent = 'Email is required';
                isValid = false;
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                document.getElementById('email-error').textContent = 'Invalid email format';
                isValid = false;
            }

            if (!contact) {
                document.getElementById('contact-error').textContent = 'Contact number is required';
                isValid = false;
            } else if (!/^09\d{2}-?\d{3}-?\d{4}$/.test(contact)) {
                document.getElementById('contact-error').textContent = 'Invalid contact format (09XX-XXX-XXXX)';
                isValid = false;
            }

            if (!username) {
                document.getElementById('username-error').textContent = 'Username is required';
                isValid = false;
            }

            if (!password) {
                document.getElementById('password-error').textContent = 'Password is required';
                isValid = false;
            }

            if (password && password.length < 6) {
                document.getElementById('password-error').textContent = 'Password must be at least 6 characters';
                isValid = false;
            }

            return isValid;
        }

        function validateAndConfirm() {
            if (!validateForm()) {
                return false;
            }

            const action = document.getElementById('modal-action').value;
            const username = document.getElementById('modal-username').value.trim();
            const message = action === 'edit'
                ? `Are you sure you want to update the username and password for ${username}?`
                : `Are you sure you want to add a new employee?`;

            return confirm(message);
        }

        function filterTable() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('.employee-row');

            rows.forEach(row => {
                const name = row.getAttribute('data-name').toLowerCase();
                const username = row.getAttribute('data-username').toLowerCase();
                const matches = name.includes(searchInput) || username.includes(searchInput);
                row.style.display = matches ? '' : 'none';
            });
        }

        function sortTable() {
            const sortValue = document.getElementById('sortSelect').value;
            if (!sortValue) return;

            const tbody = document.getElementById('employeesTableBody');
            const rows = Array.from(tbody.querySelectorAll('.employee-row'));

            rows.sort((a, b) => {
                switch(sortValue) {
                    case 'name-asc':
                        return a.getAttribute('data-name').localeCompare(b.getAttribute('data-name'));
                    case 'name-desc':
                        return b.getAttribute('data-name').localeCompare(a.getAttribute('data-name'));
                    case 'date-newest':
                        const dateA = new Date(a.querySelector('td:nth-child(8)').textContent);
                        const dateB = new Date(b.querySelector('td:nth-child(8)').textContent);
                        return dateB - dateA;
                    case 'date-oldest':
                        const dateA2 = new Date(a.querySelector('td:nth-child(8)').textContent);
                        const dateB2 = new Date(b.querySelector('td:nth-child(8)').textContent);
                        return dateA2 - dateB2;
                    case 'sales-high':
                        const salesA = parseFloat(a.querySelector('td:nth-child(9)').textContent.replace(/[₱,]/g, ''));
                        const salesB = parseFloat(b.querySelector('td:nth-child(9)').textContent.replace(/[₱,]/g, ''));
                        return salesB - salesA;
                    case 'sales-low':
                        const salesA2 = parseFloat(a.querySelector('td:nth-child(9)').textContent.replace(/[₱,]/g, ''));
                        const salesB2 = parseFloat(b.querySelector('td:nth-child(9)').textContent.replace(/[₱,]/g, ''));
                        return salesA2 - salesB2;
                    default:
                        return 0;
                }
            });

            rows.forEach(row => tbody.appendChild(row));
        }

        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.row-select');
            checkboxes.forEach(cb => { cb.checked = source.checked; });
            updateBulkDeleteState();
        }

        function updateBulkDeleteState() {
            const anySelected = document.querySelectorAll('.row-select:checked').length > 0;
            const btn = document.getElementById('bulkDeleteBtn');
            if (btn) btn.disabled = !anySelected;
        }

        function togglePassword(empId) {
            const hidden = document.getElementById('pwd-' + empId);
            const shown = document.getElementById('pwd-show-' + empId);
            const btn = event.target;
            
            if (hidden.style.display !== 'none') {
                hidden.style.display = 'none';
                shown.style.display = 'inline';
                btn.textContent = 'Hide';
            } else {
                hidden.style.display = 'inline';
                shown.style.display = 'none';
                btn.textContent = 'Show';
            }
        }

        function bulkDelete() {
            const selected = Array.from(document.querySelectorAll('.row-select:checked')).map(cb => cb.value);
            if (selected.length === 0) {
                alert('Please select employees to delete.');
                return;
            }
            if (!confirm(`Are you sure you want to delete ${selected.length} selected employee(s)?`)) {
                return;
            }
            const form = document.getElementById('bulkDeleteForm');
            // Clear previous inputs
            while (form.lastChild && form.lastChild.name === 'selected_ids[]') {
                form.removeChild(form.lastChild);
            }
            // Append selected ids
            selected.forEach(id => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'selected_ids[]';
                input.value = id;
                form.appendChild(input);
            });
            form.submit();
        }
    </script>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }
    </script>
</body>
</html>
