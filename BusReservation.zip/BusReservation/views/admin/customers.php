<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body>
    <?php include __DIR__ . '/../partials/sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Manage Customers</h1>
                <p>View all customer bookings and manage refund/cancellation requests</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <div class="content-card">
            <?php 
            if (isset($_SESSION['success'])) {
                echo "<div class='success-message'>" . htmlspecialchars($_SESSION['success']) . "</div>";
                unset($_SESSION['success']);
            }
        if (isset($_SESSION['error'])) {
            echo "<div class='error-message'>" . htmlspecialchars($_SESSION['error']) . "</div>";
            unset($_SESSION['error']);
        }
        ?>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div class="section-title" style="margin: 0; flex: 1;">Customers</div>
            <div style="display:flex; gap:8px;">
                <button id="bulkDeleteBtn" class="btn btn-danger" onclick="bulkDelete()" disabled>Delete</button>
            </div>
        </div>

        <!-- Hidden form for bulk delete -->
        <form id="bulkDeleteForm" method="POST" action="<?php echo BASE_URL; ?>admin/customers/bulk-delete" style="display:none;">
        </form>

        <div class="search-filter-bar">
            <input type="text" class="search-input" id="searchInput" placeholder="Search by name, fare ID, or customer ID..." onkeyup="filterTable()">
            <div class="sort-controls">
                <label for="sortSelect">Sort By:</label>
                <select id="sortSelect" onchange="sortTable()">
                    <option value="name-asc">Customer Name (A–Z)</option>
                    <option value="name-desc">Customer Name (Z–A)</option>
                    <option value="booked-newest">Booked Date (Newest)</option>
                    <option value="booked-oldest">Booked Date (Oldest)</option>
                    <option value="departure-earliest">Departure Date (Earliest)</option>
                    <option value="departure-latest">Departure Date (Latest)</option>
                    <option value="status-pending">Status (Pending)</option>
                    <option value="status-active">Status (Active)</option>
                    <option value="status-cancelled">Status (Cancelled)</option>
                    <option value="status-refunded">Status (Refunded)</option>
                    <option value="status-rejected">Status (Rejected)</option>
                    <option value="ticket-asc">Ticket ID (Ascending)</option>
                    <option value="ticket-desc">Ticket ID (Descending)</option>
                </select>
            </div>
        </div>

        <div class="table-wrapper" style="max-height: 500px; overflow-y: auto;">
            <table class="employees-table">
                <thead>
                    <tr>
                        <th style="width:32px;"><input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)"></th>
                        <th>Ticket ID</th>
                        <th>Customer ID</th>
                        <th>Customer Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Handled By</th>
                        <th>Booked Date</th>
                        <th>Departure Date</th>
                        <th>Return Date</th>
                        <th>Ticket Type</th>
                        <th>Destination</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Request ID</th>
                        <th>Request Type</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="customersTableBody">
                    <?php if (!empty($customers)): ?>
                        <?php foreach ($customers as $customer): ?>
                        <tr class="customer-row"
                            data-name="<?php echo htmlspecialchars($customer['Name']); ?>"
                            data-customer-id="CUST<?php echo str_pad($customer['CustomerID'], 3, '0', STR_PAD_LEFT); ?>"
                            data-status="<?php echo htmlspecialchars($customer['RequestStatus'] ?? $customer['TicketStatus'] ?? 'Active'); ?>">
                            <td><input type="checkbox" class="row-select" value="<?php echo $customer['CustomerID']; ?>" onchange="updateBulkDeleteState()"></td>
                            <td><?php echo $customer['TicketID'] ? 'T' . str_pad($customer['TicketID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                            <td><?php echo 'C' . str_pad($customer['CustomerID'], 9, '0', STR_PAD_LEFT); ?></td>
                            <td><strong><?php echo htmlspecialchars($customer['Name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($customer['Contact'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($customer['Email'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($customer['EmployeeName'] ?? '-'); ?></td>
                            <td><?php echo $customer['BookedDate'] ? date('M d, Y', strtotime($customer['BookedDate'])) : '-'; ?></td>
                            <td><?php echo $customer['DepartureDate'] ? date('M d, Y', strtotime($customer['DepartureDate'])) : '-'; ?></td>
                            <td><?php echo $customer['ReturnDate'] ? date('M d, Y', strtotime($customer['ReturnDate'])) : '-'; ?></td>
                            <td><?php echo !empty($customer['TicketType']) ? htmlspecialchars($customer['TicketType']) : '-'; ?></td>
                            <td><?php echo !empty($customer['Destination']) ? htmlspecialchars($customer['Destination']) : '-'; ?></td>
                            <td><?php echo isset($customer['Price']) ? '₱' . number_format($customer['Price'], 2) : '-'; ?></td>
                            <td><?php echo isset($customer['Quantity']) ? (int)$customer['Quantity'] : '-'; ?></td>
                            <td><?php echo isset($customer['TotalAmount']) ? '₱' . number_format($customer['TotalAmount'], 2) : '-'; ?></td>
                            <td><?php echo isset($customer['RequestID']) && $customer['RequestID'] ? 'R' . str_pad($customer['RequestID'], 9, '0', STR_PAD_LEFT) : '-'; ?></td>
                            <td><?php echo !empty($customer['RequestName']) ? htmlspecialchars($customer['RequestName']) : '-'; ?></td>
                            <td><?php echo !empty($customer['Reason']) ? htmlspecialchars($customer['Reason']) : '-'; ?></td>
                            <td><?php $status = $customer['RequestStatus'] ?? $customer['TicketStatus'] ?? 'Active';
                                $statusClass = strtolower($status);
                                $statusColors = [
                                    'active' => 'background: #d1fae5; color: #065f46;',
                                    'booked' => 'background: #dbeafe; color: #1e40af;',
                                    'pending' => 'background: #fef3c7; color: #92400e;',
                                    'approved' => 'background: #d1fae5; color: #065f46;',
                                    'rejected' => 'background: #fee2e2; color: #991b1b;',
                                    'cancelled' => 'background: #fecaca; color: #b91c1c;',
                                    'refunded' => 'background: #e0e7ff; color: #4338ca;',
                                    'completed' => 'background: #d1fae5; color: #065f46;'
                                ];
                                $statusStyle = $statusColors[$statusClass] ?? $statusColors['active']; ?>
                                <span style="<?php echo $statusStyle; ?> padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                    <?php echo htmlspecialchars($status); ?>
                                </span>
                            </td>
                            <td class="actions">
                                <?php if ($customer['RequestID'] && ($customer['RequestStatus'] === 'Pending')): ?>
                                <button class="btn btn-edit" style="background: #10b981;" onclick='processRequest(<?php echo $customer["RequestID"]; ?>, "<?php echo htmlspecialchars($customer["Name"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($customer["RequestName"] ?? "", ENT_QUOTES); ?>", "<?php echo htmlspecialchars($customer["Reason"] ?? "", ENT_QUOTES); ?>", "<?php echo $customer["TicketID"]; ?>")'>Process</button>
                                <?php endif; ?>
                                <button class="btn btn-edit" onclick='openEditModal("CUST<?php echo str_pad($customer["CustomerID"], 3, "0", STR_PAD_LEFT); ?>", "<?php echo htmlspecialchars($customer["Name"], ENT_QUOTES); ?>", "<?php echo htmlspecialchars($customer["Contact"] ?? '', ENT_QUOTES); ?>", "<?php echo htmlspecialchars($customer["Email"] ?? '', ENT_QUOTES); ?>", <?php echo $customer["CustomerID"]; ?>)'>Edit</button>
                                <button class="btn btn-edit" style="background: #8b5cf6;" onclick='viewSelectedTicket(this)'>View</button>
                                <form method="POST" action="<?php echo BASE_URL; ?>admin/customers/delete/<?php echo $customer['CustomerID']; ?>" style="display: inline;">
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this customer?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="20" style="text-align: center; padding: 20px;">No customers found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>

    <?php include __DIR__ . '/../partials/view-ticket-modal.php'; ?>
    <?php include __DIR__ . '/../partials/edit-customer-modal.php'; ?>

    <!-- Hidden form for status updates -->
    <form id="statusForm" method="POST" action="" style="display: none;">
        <input type="hidden" name="id" id="status-id">
        <input type="hidden" name="status" id="status-value">
        <input type="hidden" name="action" value="update_status">
    </form>

    <?php include __DIR__ . '/../partials/process-request-modal.php'; ?>

    <script>
        function processRequest(requestId, customerName, requestType, reason, ticketId) {
            document.getElementById('process-request-id').value = requestId;
            document.getElementById('process-customer-name').textContent = customerName;
            document.getElementById('process-request-type').textContent = requestType || 'N/A';
            document.getElementById('process-reason').textContent = reason || 'No reason provided';
            
            // Show ticket ID as Txxxxxxxxx (10 chars, as in table)
            let ticketIdStr = ticketId ? String(ticketId) : '';
            if (ticketIdStr.length < 10 && ticketIdStr.length > 0 && ticketIdStr[0] !== 'T') {
                ticketIdStr = 'T' + ticketIdStr.padStart(9, '0');
            }
            document.getElementById('process-ticket-id').textContent = ticketIdStr;
            document.getElementById('process-ticket-id-input').value = ticketId;
            document.getElementById('processRequestModal').classList.add('show');
        }

        function closeProcessModal() {
            document.getElementById('processRequestModal').classList.remove('show');
        }

        function updateStatus(id, status) {
            const action = status === 'Approved' ? 'approve' : 'disapprove';
            if (confirm(`Are you sure you want to ${action} this request?`)) {
                document.getElementById('status-id').value = id;
                document.getElementById('status-value').value = status;
                document.getElementById('statusForm').submit();
            }
        }


        function openViewTicketModal(ticketId, customerName, contact, email, booked, departure, passengers, requestType, reason, status) {
            let formattedTicketId = '-';
            if (ticketId && ticketId !== '-' && ticketId !== '') {
                let num = ticketId.replace(/[^0-9]/g, '');
                if (num.length > 0) {
                    formattedTicketId = 'TKT' + num.padStart(3, '0');
                }
            }
            document.getElementById('modalTicketId').textContent = formattedTicketId;
            document.getElementById('modalCustomerName').textContent = customerName;
            document.getElementById('modalCustomerContact').textContent = contact;
            document.getElementById('modalCustomerEmail').textContent = email;
            document.getElementById('modalBookedDate').textContent = booked;
            document.getElementById('modalDepartureDate').textContent = departure;
            let passengersText = '-';
            if (Array.isArray(passengers)) {
                passengersText = passengers.length > 0 ? passengers.join(', ') : '-';
            } else if (typeof passengers === 'string' && passengers.trim() !== '') {
                passengersText = passengers;
            }
            document.getElementById('modalPassengers').textContent = passengersText;
            document.getElementById('modalRequestType').textContent = requestType || '-';
            document.getElementById('modalReason').textContent = reason || '-';
            document.getElementById('modalStatus').textContent = status;
            document.getElementById('viewTicketModal').style.display = 'flex';
        }

        function openEditModal(custId, name, contact, email, id) {
            document.getElementById('editCustomerID').value = id;
            document.getElementById('editCustomerName').value = name;
            document.getElementById('editCustomerContact').value = contact;
            document.getElementById('editCustomerEmail').value = email;
            document.getElementById('editCustomerModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editCustomerModal').style.display = 'none';
        }

        window.onclick = function(event) {
            const viewModal = document.getElementById('viewModal');
            const editModal = document.getElementById('editCustomerModal');
            const processModal = document.getElementById('processRequestModal');
            if (event.target === viewModal) {
                viewModal.classList.remove('show');
            }
            if (event.target === editModal) {
                editModal.style.display = 'none';
            }
            if (event.target === processModal) {
                processModal.classList.remove('show');
            }
        }

        function sortTable() {
            const sortValue = document.getElementById('sortSelect').value;
            const table = document.querySelector('.employees-table tbody');
            const rows = Array.from(table.querySelectorAll('.customer-row'));
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortValue) {
                    case 'name-asc':
                        aVal = a.cells[3].textContent.toLowerCase();
                        bVal = b.cells[3].textContent.toLowerCase();
                        return aVal.localeCompare(bVal);
                    case 'name-desc':
                        aVal = a.cells[3].textContent.toLowerCase();
                        bVal = b.cells[3].textContent.toLowerCase();
                        return bVal.localeCompare(aVal);
                    case 'booked-newest':
                    case 'booked-oldest':
                    case 'departure-earliest':
                    case 'departure-latest':
                        // For dates, you'll need to implement proper date parsing
                        return 0; // Placeholder
                    case 'status-pending':
                    case 'status-active':
                    case 'status-cancelled':
                    case 'status-refunded':
                    case 'status-rejected':
                        const statusFilter = sortValue.split('-')[1];
                        const aStatus = a.cells[11].textContent.trim().toLowerCase();
                        const bStatus = b.cells[11].textContent.trim().toLowerCase();
                        if (aStatus.includes(statusFilter)) return -1;
                        if (bStatus.includes(statusFilter)) return 1;
                        return 0;
                    case 'ticket-asc':
                        aVal = a.cells[2].textContent;
                        bVal = b.cells[2].textContent;
                        return aVal.localeCompare(bVal);
                    case 'ticket-desc':
                        aVal = a.cells[2].textContent;
                        bVal = b.cells[2].textContent;
                        return bVal.localeCompare(aVal);
                    default:
                        return 0;
                }
            });
            
            rows.forEach(row => table.appendChild(row));
        }

        function filterTable() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('.customer-row');

            rows.forEach(row => {
                // Search all relevant columns in the table row
                let text = '';
                for (let i = 1; i < row.cells.length - 1; i++) { 
                    text += (row.cells[i].textContent + ' ').toLowerCase();
                }
                row.style.display = text.includes(searchInput) ? '' : 'none';
            });
        }

        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.row-select');
            checkboxes.forEach(cb => { cb.checked = source.checked; });
            updateBulkDeleteState();
        }

        function updateBulkDeleteState() {
            const anySelected = document.querySelectorAll('.row-select:checked').length > 0;
            const btn = document.getElementById('bulkDeleteBtn');
            if (btn) btn.disabled = !anySelected;
        }

        function bulkDelete() {
            const selected = Array.from(document.querySelectorAll('.row-select:checked')).map(cb => cb.value);
            if (selected.length === 0) {
                alert('Please select customers to delete.');
                return;
            }
            if (!confirm(`Are you sure you want to delete ${selected.length} selected customer(s)?`)) {
                return;
            }
            const form = document.getElementById('bulkDeleteForm');
            // Clear previous inputs
            while (form.lastChild && form.lastChild.name === 'selected_ids[]') {
                form.removeChild(form.lastChild);
            }
            // Append selected ids
            selected.forEach(id => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'selected_ids[]';
                input.value = id;
                form.appendChild(input);
            });
            form.submit();
        }

        function viewSelectedTicket(btn) {
              // Find the row for this button
              var row = btn.closest('tr');
              if (!row) return;
              var cells = row.cells;
              // Map table columns to modal fields 
              document.getElementById('modalTicketId').textContent = cells[1].textContent.trim();
              document.getElementById('modalCustomerId').textContent = cells[2].textContent.trim();
              document.getElementById('modalCustomerName').textContent = cells[3].textContent.trim();
              document.getElementById('modalCustomerContact').textContent = cells[4].textContent.trim();
              document.getElementById('modalCustomerEmail').textContent = cells[5].textContent.trim();
              document.getElementById('modalBookedDate').textContent = cells[7].textContent.trim(); 
              document.getElementById('modalDepartureDate').textContent = cells[8].textContent.trim();
              document.getElementById('modalReturnDate').textContent = cells[9].textContent.trim();
              document.getElementById('modalTicketType').textContent = cells[10].textContent.trim();
              document.getElementById('modalDestination').textContent = cells[11].textContent.trim();
              document.getElementById('modalPrice').textContent = cells[12].textContent.trim();
              document.getElementById('modalQuantity').textContent = cells[13].textContent.trim();
              document.getElementById('modalTotalAmount').textContent = cells[14].textContent.trim();
              document.getElementById('modalRequestId').textContent = cells[15].textContent.trim();
              document.getElementById('modalRequestType').textContent = cells[16].textContent.trim();
              document.getElementById('modalReason').textContent = cells[17].textContent.trim();
              document.getElementById('modalStatus').textContent = cells[18].textContent.trim();
              document.getElementById('viewTicketModal').style.display = 'flex';
        }
    </script>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }
    </script>
</body>
</html>
