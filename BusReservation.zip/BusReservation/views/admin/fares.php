<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Fares - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/fares.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body>
    <?php include __DIR__ . '/../partials/sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Manage Fares</h1>
                <p>View and update bus ticket prices for all destinations</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <div class="content-card">
            <?php 
            if (isset($_SESSION['success'])) {
                echo "<div class='success-message'>" . htmlspecialchars($_SESSION['success']) . "</div>";
                unset($_SESSION['success']);
            }
        if (isset($_SESSION['error'])) {
            echo "<div class='error-message'>" . htmlspecialchars($_SESSION['error']) . "</div>";
            unset($_SESSION['error']);
        }
        ?>

        
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div class="section-title" style="margin: 0; flex: 1;">Current Fares</div>
            </div>

            <div class="search-filter-bar">
                <input type="text" class="search-input" id="searchInput" placeholder="Search by destination..." onkeyup="filterTable()">
                <select class="filter-select" id="filterSelect" onchange="filterTable()">
                    <option value="">All Destinations</option>
                    <option value="Manila">Manila</option>
                    <option value="Baguio">Baguio</option>
                    <option value="Tagaytay">Tagaytay</option>
                    <option value="Naga">Naga</option>
                    <option value="Baler">Baler</option>
                    <option value="Batangas">Batangas</option>
                    <option value="Vigan">Vigan</option>
                    <option value="Legazpi">Legazpi</option>
                    <option value="Laoag">Laoag</option>
                </select>
            </div>
            <div class="table-wrapper">
                <table class="fares-table">
                    <thead>
                        <tr>
                            <th>Fare ID</th>
                            <th>Destination</th>
                            <th>One-Way Price</th>
                            <th>Round-Trip Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="faresTableBody">
                        <?php if (!empty($fares)): ?>
                            <?php foreach ($fares as $fare): ?>
                                <tr class="fare-row" data-destination="<?php echo htmlspecialchars($fare['Destination']); ?>">
                                    <td><strong>FARE<?php echo str_pad($fare['FareID'], 3, '0', STR_PAD_LEFT); ?></strong></td>
                                    <td><?php echo htmlspecialchars($fare['Destination']); ?></td>
                                    <td>₱<?php echo number_format($fare['OneWayPrice'], 2); ?></td>
                                    <td>₱<?php echo number_format($fare['RoundTripPrice'], 2); ?></td>
                                    <td class="actions">
                                        <button class="btn btn-edit" onclick='openEditModal(<?php echo $fare["FareID"]; ?>, "<?php echo htmlspecialchars($fare["Destination"], ENT_QUOTES); ?>", <?php echo $fare["OneWayPrice"]; ?>, <?php echo $fare["RoundTripPrice"]; ?>)'>Edit</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 20px;">No fares found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
            </table>
        </div>
        </div>
    </div>

    <?php include __DIR__ . '/../partials/fare-modal.php'; ?>

    <script>
        function filterTable() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const filterSelect = document.getElementById('filterSelect').value.toLowerCase();
            const rows = document.querySelectorAll('.fare-row');

            rows.forEach(row => {
                const destination = row.getAttribute('data-destination').toLowerCase();
                const matchesSearch = destination.includes(searchInput);
                const matchesFilter = !filterSelect || destination.includes(filterSelect);

                row.style.display = (matchesSearch && matchesFilter) ? '' : 'none';
            });
        }

        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.row-select');
            checkboxes.forEach(cb => { cb.checked = source.checked; });
            updateBulkDeleteState();
        }

        function updateBulkDeleteState() {
            const anySelected = document.querySelectorAll('.row-select:checked').length > 0;
            const btn = document.getElementById('bulkDeleteBtn');
            if (btn) btn.disabled = !anySelected;
        }

        function bulkDelete() {
            const selected = Array.from(document.querySelectorAll('.row-select:checked')).map(cb => cb.value);
            if (selected.length === 0) {
                alert('Please select fares to delete.');
                return;
            }
            if (!confirm(`Are you sure you want to delete ${selected.length} selected fare(s)?`)) {
                return;
            }
            const form = document.getElementById('bulkDeleteForm');
            // Clear previous inputs
            while (form.lastChild && form.lastChild.name === 'selected_ids[]') {
                form.removeChild(form.lastChild);
            }
            // Append selected ids
            selected.forEach(id => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'selected_ids[]';
                input.value = id;
                form.appendChild(input);
            });
            form.submit();
        }
    </script>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }
    </script>
</body>
</html>
