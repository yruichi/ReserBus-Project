<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ReserBus</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/common.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/sidebar.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employee-dashboard.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/employees.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/modals.css">
    <script src="<?php echo ASSETS_URL; ?>js/table-resize.js"></script>
</head>
<body class="admin-dashboard">

    <?php include __DIR__ . '/../partials/sidebar.php'; ?>

    <?php
    require_once __DIR__ . '/../../config/database.php';
    $conn = Database::getConnection();

    // Use similar logic as employee dashboard for these cards
    // Exclude tickets with approved cancellation/refund

    function getTotalSales($conn) {
        $stmt = $conn->prepare("
            SELECT
                SUM(CASE WHEN t.TotalAmount IS NOT NULL THEN t.TotalAmount ELSE t.Quantity * t.Price END)
                - ISNULL((
                    SELECT SUM(CASE WHEN t2.TotalAmount IS NOT NULL THEN t2.TotalAmount ELSE t2.Quantity * t2.Price END)
                    FROM Ticket t2
                    INNER JOIN CustomerRequest cr2 ON cr2.TicketID = t2.TicketID
                    WHERE cr2.Status = 'Approved'
                ), 0) as total_sales
            FROM Ticket t
        ");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_sales'] ?? 0;
    }

    function getMonthlySales($conn) {
        $month = date('Y-m-01');
        $stmt = $conn->prepare("
            SELECT
                SUM(CASE WHEN t.TotalAmount IS NOT NULL THEN t.TotalAmount ELSE t.Quantity * t.Price END)
                - ISNULL((
                    SELECT SUM(CASE WHEN t2.TotalAmount IS NOT NULL THEN t2.TotalAmount ELSE t2.Quantity * t2.Price END)
                    FROM Ticket t2
                    INNER JOIN CustomerRequest cr2 ON cr2.TicketID = t2.TicketID
                    WHERE cr2.Status = 'Approved' AND t2.BookedDate >= ?
                ), 0) as monthly_sales
            FROM Ticket t
            WHERE t.BookedDate >= ?
        ");
        $stmt->execute([$month, $month]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['monthly_sales'] ?? 0;
    }

    function getMonthlyTickets($conn) {
        $month = date('Y-m-01');
        $stmt = $conn->prepare("
            SELECT COUNT(*) as monthly_tickets FROM Ticket t
            WHERE BookedDate >= ?
            AND NOT EXISTS (
                SELECT 1 FROM CustomerRequest cr
                WHERE cr.TicketID = t.TicketID AND cr.Status = 'Approved'
            )
        ");
        $stmt->execute([$month]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['monthly_tickets'] ?? 0;
    }

    function getPopularRoute($conn) {
        $month = date('Y-m-01');
        $stmt = $conn->prepare("
            SELECT TOP 1 Destination, SUM(Quantity) as total_qty FROM Ticket t
            WHERE BookedDate >= ?
            AND NOT EXISTS (
                SELECT 1 FROM CustomerRequest cr
                WHERE cr.TicketID = t.TicketID AND cr.Status = 'Approved'
            )
            GROUP BY Destination
            ORDER BY total_qty DESC
        ");
        $stmt->execute([$month]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['Destination'] ?? 'N/A';
    }

    $dashboardStats = [
        'total_sales' => getTotalSales($conn),
        'monthly_sales' => getMonthlySales($conn),
        'monthly_tickets' => getMonthlyTickets($conn),
        'popular_route' => getPopularRoute($conn),
    ];
    ?>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <h1>Admin Dashboard</h1>
                <p>Manage and Monitor ReserBus System</p>
            </div>
            <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        </div>

        <div class="welcome-banner" style="background: #26538F; color: #fff; padding: 30px; border-radius: 0; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); display: flex; justify-content: space-between; align-items: center;">
            <div class="welcome-left">
                <h2 style="margin: 0 0 8px 0; font-size: 28px; font-weight: bold;">Welcome, Admin!</h2>
                <p style="margin: 5px 0; opacity: 0.95; font-size: 15px;">System Online - Track all operations and performance</p>
                <div class="welcome-datetime" style="display: flex; gap: 15px; background: #26538F; padding: 15px 20px; border-radius: 8px; margin-top: 10px;">
                    <div class="dt-values" style="display: flex; flex-direction: column; gap: 8px;">
                        <span id="bannerDate">-</span>
                        <span id="bannerTime">-</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Overview Cards -->
        <div class="overview-section">
            <div class="overview-grid">
                <div class="overview-card">
                    <div class="card-icon">💰</div>
                    <div class="card-content">
                        <h3>Total Sales</h3>
                        <p class="card-value">₱<?php echo number_format($dashboardStats['total_sales'] ?? 0, 2); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">📅</div>
                    <div class="card-content">
                        <h3>Month Sales</h3>
                        <p class="card-value">₱<?php echo number_format($dashboardStats['monthly_sales'] ?? 0, 2); ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">⏳</div>
                    <div class="card-content">
                        <h3>Pending Requests</h3>
                        <p class="card-value"><?php echo number_format($metrics['pending_requests'] ?? 0); ?></p>
                        <p class="card-subtext">Refunds & Cancellations</p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">✅</div>
                    <div class="card-content">
                        <h3>Approved Requests</h3>
                        <p class="card-value"><?php echo number_format($metrics['approved_requests'] ?? 0); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">🚌</div>
                    <div class="card-content">
                        <h3>Most Popular Route</h3>
                        <p class="card-value"><?php echo htmlspecialchars($dashboardStats['popular_route'] ?? 'N/A'); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">👔</div>
                    <div class="card-content">
                        <h3>Active Employees</h3>
                        <p class="card-value"><?php echo number_format($metrics['active_employees'] ?? 0); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">🎫</div>
                    <div class="card-content">
                        <h3>Month Tickets</h3>
                        <p class="card-value"><?php echo number_format($dashboardStats['monthly_tickets'] ?? 0); ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>

                <div class="overview-card">
                    <div class="card-icon">👥</div>
                    <div class="card-content">
                        <h3>Month Customers</h3>
                        <p class="card-value"><?php echo number_format($metrics['monthly_customers'] ?? 0); ?></p>
                        <p class="card-subtext"><?php echo date('F Y'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Performing Employees Section -->
        <div class="section">
            <h3>Top Performing Employees (<?php echo date('F Y'); ?>)</h3>
            <p style="color: #666; font-size: 14px; margin-bottom: 20px;">View top performing employees based on ticket sales</p>
            <div class="table-wrapper">
                <table class="employees-table">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Month Sales</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($data['topEmployees'])): ?>
                            <?php $count = 0; ?>
                            <?php foreach ($data['topEmployees'] as $employee): ?>
                                <?php if ($count >= 5) break; ?>
                                <tr>
                                    <td>E<?php echo str_pad($employee['EmployeeID'], 10, '0', STR_PAD_LEFT); ?></td>
                                    <td><?php echo htmlspecialchars($employee['Name']); ?></td>
                                    <td>₱<?php echo number_format($employee['Total_Sales'] ?? 0, 2); ?></td>
                                </tr>
                                <?php $count++; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" style="text-align: center; padding: 20px; color: #999;">No employee data available</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    
    <script>
        function updateDateTime() {
            const now = new Date();
            
            // Format date
            const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', options);
            const dateEl = document.getElementById('bannerDate');
            if (dateEl) dateEl.textContent = dateStr;
            
            // Format time
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const timeStr = `${hours}:${minutes}:${seconds}`;
            const timeEl = document.getElementById('bannerTime');
            if (timeEl) timeEl.textContent = timeStr;
        }
        
        // Update on page load
        updateDateTime();
        
        // Update every second
        setInterval(updateDateTime, 1000);
        
        // Sidebar toggle 
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Sort tickets table
        function sortTicketsTable(sortValue) {
            const table = document.querySelector('.tickets-table tbody');
            const rows = Array.from(table.querySelectorAll('tr')).filter(row => row.cells.length > 1);
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortValue) {
                    case 'destination-asc':
                        aVal = a.cells[1].textContent.toLowerCase();
                        bVal = b.cells[1].textContent.toLowerCase();
                        return aVal.localeCompare(bVal);
                    case 'destination-desc':
                        aVal = a.cells[1].textContent.toLowerCase();
                        bVal = b.cells[1].textContent.toLowerCase();
                        return bVal.localeCompare(aVal);
                    case 'oneway-asc':
                        aVal = parseFloat(a.cells[4].textContent.replace(/[₱,]/g, ''));
                        bVal = parseFloat(b.cells[4].textContent.replace(/[₱,]/g, ''));
                        return aVal - bVal;
                    case 'oneway-desc':
                        aVal = parseFloat(a.cells[4].textContent.replace(/[₱,]/g, ''));
                        bVal = parseFloat(b.cells[4].textContent.replace(/[₱,]/g, ''));
                        return bVal - aVal;
                    case 'roundtrip-asc':
                        aVal = parseFloat(a.cells[5].textContent.replace(/[₱,]/g, ''));
                        bVal = parseFloat(b.cells[5].textContent.replace(/[₱,]/g, ''));
                        return aVal - bVal;
                    case 'roundtrip-desc':
                        aVal = parseFloat(a.cells[5].textContent.replace(/[₱,]/g, ''));
                        bVal = parseFloat(b.cells[5].textContent.replace(/[₱,]/g, ''));
                        return bVal - aVal;
                }
            });
            
            rows.forEach(row => table.appendChild(row));
        }
    </script>

</body>
</html>