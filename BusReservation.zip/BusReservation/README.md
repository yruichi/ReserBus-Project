# ReserBus - Bus Reservation System

## MVC Architecture

This application now follows the Model-View-Controller (MVC) pattern for better code organization and maintainability.

### Folder Structure

```
BusReservation/
├── config/
│   ├── config.php          # Application configuration & helpers
│   └── database.php        # Database connection class
├── models/
│   ├── User.php           # User authentication & registration
│   ├── Employee.php       # Employee management
│   ├── Customer.php       # Customer management
│   └── Fare.php           # Fare management
├── controllers/
│   ├── AuthController.php     # Login, signup, logout
│   ├── AdminController.php    # Dashboard
│   ├── EmployeeController.php # Employee CRUD operations
│   ├── CustomerController.php # Customer CRUD operations
│   └── FareController.php     # Fare CRUD operations
├── views/
│   ├── admin/             # Admin view files
│   └── partials/          # Reusable view components
├── assets/
│   ├── css/              # Stylesheets
│   └── js/               # JavaScript files
├── includes/             # Legacy includes
└── index.php            # Main router

```

### Database Setup

1. Create a MySQL database named `bus_reservation`
2. Run the SQL schema (create tables for users, employees, customers, fares)
3. Update database credentials in `config/database.php` if needed

### MVC Components

**Models** (`models/`)
- Handle all database operations
- Business logic and data validation
- Independent of presentation layer

**Views** (`.php` files in root & `views/`)
- Display data to users
- HTML, CSS, JavaScript
- Should contain minimal PHP (only for displaying data)

**Controllers** (`controllers/`)
- Handle user requests
- Call appropriate model methods
- Load appropriate views
- Process form submissions

### Routing

The `index.php` file acts as a front controller and router. All requests can go through it for clean URLs.

### URLs

**Legacy URLs (still work):**
- `/php/BusReservation/login.php`
- `/php/BusReservation/adminDashboard.php`
- `/php/BusReservation/employeesManagement.php`

**New MVC URLs (recommended):**
- `/php/BusReservation/login`
- `/php/BusReservation/admin/dashboard`
- `/php/BusReservation/admin/employees`
- `/php/BusReservation/admin/customers`
- `/php/BusReservation/admin/fares`

### Helper Functions (config/config.php)

- `requireAuth()` - Check if user is logged in
- `requireAdmin()` - Check if user is admin
- `redirect($path)` - Redirect to a URL
- `view($viewPath, $data)` - Load a view with data

### Next Steps

1. **Create database tables** matching the Model structure
2. **Update existing view files** to use MVC pattern (separate PHP logic from HTML)
3. **Use Controllers** for all form submissions
4. **Enable mod_rewrite** in Apache for clean URLs (optional)

### Benefits

✓ Organized code structure
✓ Separation of concerns
✓ Easier to maintain and debug
✓ Reusable components
✓ Professional architecture
✓ Scalable for future features
