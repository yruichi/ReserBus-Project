<?php
$to = 'itsmicaellaeliab@gmail.com';
$subject = 'Test Email from ReserBus';
$message = 'This is a test email to check if PHP mail/SMTP is working.';
$headers = 'From: itsmicaellaeliab@gmail.com' . "\r\n" .
    'Reply-To: itsmicaellaeliab@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

if (mail($to, $subject, $message, $headers)) {
    echo 'Test email sent successfully.';
} else {
    echo 'Failed to send test email.';
}
