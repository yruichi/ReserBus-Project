<?php
/**
 * Front Controller - All requests go through here
 * Proper MVC Router
 */
require_once __DIR__ . '/config/config.php';

// Check if using query parameter routing (for compatibility)
if (isset($_GET['page'])) {
    $page = $_GET['page'];
    $parts = explode('/', $page);
    $controller = $parts[0] ?? '';
    $action = $parts[1] ?? 'index';
} else {
    // Get request path
    $request = $_SERVER['REQUEST_URI'];
    $basePath = '/php/BusReservation/';
    $request = str_replace($basePath, '', $request);
    $request = strtok($request, '?'); // Remove query string
    $request = trim($request, '/');
    
    // Remove index.php if present
    $request = str_replace('index.php', '', $request);
    $request = trim($request, '/');

    // Parse route
    $parts = explode('/', $request);
    $controller = $parts[0] ?? '';
    $action = $parts[1] ?? 'index';
}

// Route to controllers
switch ($controller) {
    case '':
    case 'login':
    case 'index':
        $authController = new AuthController();
        $authController->showLogin();
        break;
        
    case 'auth':
        $authController = new AuthController();
        if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $authController->login();
        } elseif ($action === 'logout') {
            $authController->logout();
        }
        break;
        
    case 'admin':
        requireAdmin();
        $adminController = new AdminController();
        
        switch ($action) {
            case 'dashboard':
            case 'index':
                $adminController->dashboard();
                break;
            case 'employees':
                $employeeController = new EmployeeController();
                $subAction = $parts[2] ?? null;
                $id = $parts[3] ?? null;

                // Dedicated update route for admin employee update (with password)
                if ($subAction === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $adminController->updateEmployee();
                // Add route for update-tickets
                } elseif ($subAction === 'update-tickets' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $employeeId = $_POST['id'] ?? null;
                    if ($employeeId) {
                        $employeeController->updateTickets($employeeId);
                    } else {
                        $_SESSION['error'] = 'No employee selected for ticket update.';
                        header('Location: ' . BASE_URL . 'admin/employees');
                        exit;
                    }
                } elseif ($subAction === 'delete' && $id) {
                    $employeeController->delete($id);
                } elseif ($subAction === 'bulk-delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $employeeController->bulkDelete();
                } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (isset($_POST['action'])) {
                        if ($_POST['action'] === 'add') {
                            $employeeController->create();
                        } elseif ($_POST['action'] === 'edit' && isset($_POST['id'])) {
                            $employeeController->update($_POST['id']);
                        }
                    }
                } else {
                    $employeeController->index();
                }
                break;
            case 'customers':
                $customerController = new CustomerController();
                // Check for sub-actions like update, delete
                $subAction = $parts[2] ?? null;
                $id = $parts[3] ?? null;
                
                if ($subAction === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $customerController->updateCustomer();
                } elseif ($subAction === 'delete' && $id) {
                    $customerController->delete($id);
                } elseif ($subAction === 'bulk-delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $customerController->bulkDelete();
                } else {
                    $customerController->index();
                }
                break;
            case 'fares':
                $fareController = new FareController();
                // Check for sub-actions like create, update, delete
                $subAction = $parts[2] ?? null;
                $id = $parts[3] ?? null;
                
                if ($subAction === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $fareController->create();
                } elseif ($subAction === 'update' && $id && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $fareController->update($id);
                } elseif ($subAction === 'delete' && $id) {
                    $fareController->delete($id);
                } elseif ($subAction === 'bulk-delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                    $fareController->bulkDelete();
                } else {
                    $fareController->index();
                }
                break;
            default:
                http_response_code(404);
                echo "404 - Page Not Found";
        }
        break;
        
    case 'employee':
        requireAuth();
        // Ensure only employees can access employee routes
        if ($_SESSION['user_type'] !== 'employee') {
            redirect('admin/dashboard');
        }
        
        $employeeController = new EmployeeController();
        switch ($action) {
            case 'dashboard':
            case 'index':
                $employeeController->dashboard();
                break;
            case 'fares':
                require_once __DIR__ . '/views/employee/fares.php';
                break;
            case 'customers':
                $employeeController->customers();
                break;
            case 'requests':
                require_once __DIR__ . '/views/employee/requests.php';
                break;
            case 'profile':
                $employeeController->profile();
                break;
            case 'updateProfile':
                $employeeController->updateProfile();
                break;
            case 'tickets':
                $employeeController->tickets();
                break;
            default:
                http_response_code(404);
                echo "404 - Employee Page Not Found";
        }
        break;
        
    default:
        // Show login page for unrecognized routes
        $authController = new AuthController();
        $authController->showLogin();
        break;
}
?>
