<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Application Configuration
define('BASE_URL', 'http://localhost/php/BusReservation/');
define('ASSETS_URL', BASE_URL . 'assets/');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Autoload classes
spl_autoload_register(function ($class) {
    $paths = [
        __DIR__ . '/../models/' . $class . '.php',
        __DIR__ . '/../controllers/' . $class . '.php',
    ];
    
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// Helper function to check if user is logged in
function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}

// Helper function to check if user is admin
function requireAdmin() {
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}

// Helper function to check if user is employee
function requireEmployee() {
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'employee') {
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}

// Helper function to redirect
function redirect($path) {
    header('Location: ' . BASE_URL . $path);
    exit();
}

// Helper function to render view
function view($viewPath, $data = []) {
    extract($data);
    require_once __DIR__ . '/../views/' . $viewPath . '.php';
}
