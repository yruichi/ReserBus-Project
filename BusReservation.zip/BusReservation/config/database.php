<?php
/**
 * Database Configuration Class - Singleton Pattern
 * MS SQL Server connection using PDO
 * Single connection shared across all models
 */
class Database {
    // SQL Server credentials
    private static $serverName = "localhost\\SQLEXPRESS";
    private static $dbName = "ReserBus";
    
    // Singleton instance
    private static $instance = null;
    private static $connection = null;
    private static $lastError = null;

    // Private constructor to prevent direct instantiation
    private function __construct() {}

    /**
     * Get singleton instance
     * @return Database
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get database connection
     * @return PDO|null Database connection object
     */
    public static function getConnection() {
        if (self::$connection !== null) {
            return self::$connection;
        }
        
        try {
            $dsn = "sqlsrv:Server=" . self::$serverName . ";Database=" . self::$dbName . ";Encrypt=true;TrustServerCertificate=true";
            try {
                self::$connection = new PDO($dsn);
            } catch (PDOException $primaryEx) {
                // Fallback server names
                $fallbacks = [
                    "localhost\\SQLEXPRESS",
                    "localhost",
                    "127.0.0.1,1433",
                    ".\\SQLEXPRESS"
                ];
                foreach ($fallbacks as $srv) {
                    $altDsn = "sqlsrv:Server=" . $srv . ";Database=" . self::$dbName . ";Encrypt=true;TrustServerCertificate=true";
                    try {
                        self::$connection = new PDO($altDsn);
                        break;
                    } catch (PDOException $altEx) {
                        
                    }
                }
                if (!self::$connection) {
                    throw $primaryEx;
                }
            }
            
            // Set PDO attributes
            self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            self::$lastError = $exception->getMessage();
            error_log("[DB] Connection error: " . self::$lastError);
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION['error'] = 'Database connection failed.';
            }
        }
        
        return self::$connection;
    }

    public static function getLastError(): ?string {
        return self::$lastError;
    }

    // Prevent cloning
    private function __clone() {}
}
