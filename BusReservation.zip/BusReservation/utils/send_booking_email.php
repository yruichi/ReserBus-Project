<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once __DIR__ . '/../../vendor/autoload.php';

function sendCancellationDisapprovedEmail($to, $customerName, $ticketId, $quantity, $destination, $requestType, $reasonForRequest, $requestStatus, $remarks) {
    $subject = "Cancellation / Refund Request Rejected";
    $submittedDate = date('F j, Y, g:i a');
    $message = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 24px;'>
        <h2 style='color: #26538F;'>Dear " . htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8') . ",</h2>
        <p>We regret to inform you that your request has been <span style='color: #ef4444; font-weight: bold;'>rejected</span> after careful review. Please see the details below:</p>
        <ul style='list-style: none; padding: 0;'>
            <li><strong>Ticket ID:</strong> " . htmlspecialchars($ticketId, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Quantity:</strong> " . htmlspecialchars($quantity, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Destination:</strong> $destination</li>
            <li><strong>Reason for Request:</strong> $reasonForRequest</li>
            <li><strong>Request Status:</strong> $requestStatus</li>
            <li><strong>Request Submitted:</strong> $submittedDate</li>
        </ul>
        <p>Your original ticket booking remains valid and confirmed. If you have further questions or wish to appeal, please contact our customer support team.</p>
        <p>We appreciate your understanding.</p>
        <br>
        <p>Sincerely,<br>ReserBus Customer Support Team</p>
    </div>
    ";

    // PHPMailer setup for Gmail SMTP
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'itsmicaellaeliab@gmail.com';
        $mail->Password = 'eazm mjqe ubna cbbx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('itsmicaellaeliab@gmail.com', 'Bus Reservation');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        error_log('sendBookingEmail exception: ' . $e->getMessage());
        return false;
    }
}

function sendCancellationApprovedEmail($to, $customerName, $ticketId, $quantity, $destination, $requestType, $reasonForRequest, $requestStatus, $submittedDate) {
    $subject = "Cancellation / Refund Request Approved";
    $message = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 24px;'>
        <h2 style='color: #26538F;'>Dear " . htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8') . ",</h2>
        <p>We are pleased to inform you that your request has been <span style='color: #10b981; font-weight: bold;'>approved</span> after review. Please see the details below:</p>
        <ul style='list-style: none; padding: 0;'>
            <li><strong>Ticket ID:</strong> " . htmlspecialchars($ticketId, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Quantity:</strong> " . htmlspecialchars($quantity, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Destination:</strong> $destination</li>
            <li><strong>Reason for Request:</strong> $reasonForRequest</li>
            <li><strong>Request Status:</strong> $requestStatus</li>
            <li><strong>Request Submitted:</strong> $submittedDate</li>
        </ul>
        <p>Your request has been processed and the necessary actions have been taken. If you are due a refund, it will be processed according to our policy. If your ticket was cancelled, it is no longer valid for travel.</p>
        <p>If you have any questions or need further assistance, please contact our customer support team.</p>
        <br>
        <p>Sincerely,<br>ReserBus Customer Support Team</p>
    </div>
    ";

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'itsmicaellaeliab@gmail.com';
        $mail->Password = 'eazm mjqe ubna cbbx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('itsmicaellaeliab@gmail.com', 'Bus Reservation');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        error_log('sendCancellationApprovedEmail exception: ' . $e->getMessage());
        return false;
    }
}

function sendCancellationRequestEmail($to, $customerName, $ticketId, $quantity, $destination, $requestType, $requestStatus, $requestDate) {
    $subject = "Cancellation / Refund Request Status (Received)";
    $message = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 24px;'>
        <h2 style='color: #26538F;'>Dear " . htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8') . ",</h2>
        <p>We would like to inform you that your request has been successfully received and is currently being processed. Please see the details below:</p>
        <ul style='list-style: none; padding: 0;'>
            <li><strong>Ticket ID:</strong> " . htmlspecialchars($ticketId, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Quantity:</strong> " . htmlspecialchars($quantity, ENT_QUOTES, 'UTF-8') . "</li>
            <li><strong>Destination:</strong> $destination</li>
            <li><strong>Request Type:</strong> $requestType</li>
            <li><strong>Request Status:</strong> $requestStatus</li>
            <li><strong>Request Date:</strong> $requestDate</li>
        </ul>
        <p>Our team is currently reviewing your request. You will receive another email once a decision has been made. Please allow sufficient processing time.</p>
        <p>If you have any further concerns, feel free to contact our customer support team.</p>
        <p>Thank you for your patience and understanding.</p>
        <br>
        <p>Sincerely,<br>ReserBus Customer Support Team</p>
    </div>
    ";

    // PHPMailer setup for Gmail SMTP
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'itsmicaellaeliab@gmail.com';
        $mail->Password = 'eazm mjqe ubna cbbx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('itsmicaellaeliab@gmail.com', 'Bus Reservation');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        echo '<div style="color:red; font-weight:bold;">Email could not be sent. Mailer Error: ' . htmlspecialchars($mail->ErrorInfo) . '<br>Exception: ' . htmlspecialchars($e->getMessage()) . '</div>';
        return false;
    }
}
function sendBookingEmail($to, $customerName, $ticketId, $quantity, $destination, $ticketType, $bookingDate, $departureDate, $departureTime) {
    $subject = "ReserBus Ticket Confirmation";
    $message = '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 24px;">'
        . '<h2 style="color: #26538F;">Dear ' . htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8') . ',</h2>'
        . '<p>We are pleased to inform you that your bus ticket booking has been successfully confirmed. Below are the details of your reservation:</p>'
        . '<ul style="list-style: none; padding: 0;">'
        . '<li><strong>Ticket ID:</strong> ' . htmlspecialchars($ticketId, ENT_QUOTES, 'UTF-8') . '</li>'
        . '<li><strong>Quantity:</strong> ' . htmlspecialchars($quantity, ENT_QUOTES, 'UTF-8') . '</li>'
        . '<li><strong>Destination:</strong> ' . htmlspecialchars($destination, ENT_QUOTES, 'UTF-8') . '</li>'
        . '<li><strong>Ticket Type:</strong> ' . htmlspecialchars($ticketType, ENT_QUOTES, 'UTF-8') . '</li>'
        . '<li><strong>Booking Date:</strong> ' . htmlspecialchars($bookingDate, ENT_QUOTES, 'UTF-8') . '</li>'
        . '<li><strong>Departure Date & Time:</strong><br>' . htmlspecialchars($departureDate, ENT_QUOTES, 'UTF-8') . ' | ' . htmlspecialchars($departureTime, ENT_QUOTES, 'UTF-8') . '</li>'
        . '</ul>'
        . '<p>Please keep this email as your official proof of booking. You may be required to present your Ticket ID and a valid ID upon boarding.</p>'
        . '<p>If you have any questions or need assistance, feel free to contact our customer support.</p>'
        . '<p>Thank you for choosing ReserBus. We wish you a safe and pleasant journey.</p>'
        . '<br>'
        . '<p>Sincerely,<br>ReserBus Customer Support Team</p>'
        . '</div>';

    // PHPMailer setup for Gmail SMTP
    $mail = new PHPMailer(true);
    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'itsmicaellaeliab@gmail.com';
        $mail->Password = 'eazm mjqe ubna cbbx'; // App password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('itsmicaellaeliab@gmail.com', 'Bus Reservation');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        echo '<div style="color:red; font-weight:bold;">Email could not be sent. Mailer Error: ' . htmlspecialchars($mail->ErrorInfo) . '<br>Exception: ' . htmlspecialchars($e->getMessage()) . '</div>';
        return false;
    }
}

