    <?php
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../models/Employee.php';

    class EmployeeController {
        // Employee: Show all customers handled by this employee (MVC refactor)
        public function customers() {
            if (!isset($_SESSION['user_id'])) {
                requireAuth();
            }
            $employeeId = $_SESSION['user_id'];

            require_once __DIR__ . '/../models/Customer.php';
            require_once __DIR__ . '/../models/Fare.php';
            $customerModel = new Customer();
            $fareModel = new Fare();

            // Get all customers for this employee
            $customers = $customerModel->getByEmployee($employeeId);
            // Get fares for dropdown
            $faresForDropdown = $fareModel->getActiveFares();

            // Pass to view
            require_once __DIR__ . '/../views/employee/customers.php';
        }
    private $model;
    private $ticketModel;
    private $dashboardModel;

    public function __construct() {
        $this->model = new Employee();
        $this->ticketModel = new Ticket();
        $this->dashboardModel = new Dashboard();
    }
    // Employee dashboard (was EmployeeDashboardController)
    public function dashboard() {
        $employeeId = $_SESSION['user_id'];
        $employee = $this->model->getById($employeeId);
        if (!$employee) {
            $_SESSION['error'] = 'Employee not found';
            redirect('login');
        }

        // Get employee-specific metrics from Dashboard model
        $employeeData = $this->dashboardModel->getEmployeeMetrics($employeeId);

        // Get today's sales for display (employee)
        $ticketsData = $this->ticketModel->getTodaySalesByEmployee($employeeId);

        // Get sales data (recent completed tickets)
        $salesData = $this->ticketModel->getByEmployee($employeeId, 5);

        // Get recent tickets for customer (if available)
        $customerTicketsData = [];
        if (!empty($employee['CustomerID'])) {
            $customerTicketsData = $this->ticketModel->getByCustomer($employee['CustomerID']);
        }

        require_once __DIR__ . '/../views/employee/dashboard.php';
    }

    // Employee profile view
    public function profile() {
        $employeeId = $_SESSION['user_id'];
        $employee = $this->model->getById($employeeId);
        if (!$employee) {
            $_SESSION['error'] = 'Employee not found';
            redirect('employee/dashboard');
        }
        $data = ['employee' => $employee];
        require_once __DIR__ . '/../views/employee/profile.php';
    }

    // Employee profile update
    public function updateProfile() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('employee/profile');
        }
        $employeeId = $_SESSION['user_id'];
        $data = [
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'contact' => $_POST['contact'] ?? ''
        ];
        if (empty($data['name']) || empty($data['email'])) {
            $_SESSION['error'] = 'Name and email are required';
            redirect('employee/profile');
            return;
        }
        $query = "UPDATE Employee SET Name = :name, Email = :email, Contact = :contact WHERE EmployeeID = :id";
        try {
            $conn = Database::getConnection();
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':contact', $data['contact']);
            $stmt->bindParam(':id', $employeeId);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Profile updated successfully!';
            } else {
                $_SESSION['error'] = 'Failed to update profile';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        }
        redirect('employee/profile');
    }

    // Employee tickets view 
    public function tickets() {
        $employeeId = $_SESSION['user_id'];
        $tickets = $this->ticketModel->getByEmployee($employeeId);
        $data = ['tickets' => $tickets];
        require_once __DIR__ . '/../views/employee/tickets.php';
    }

    // Show all employees
    public function index() {
        $employees = $this->model->getAll();
        require_once __DIR__ . '/../views/admin/employees.php';
    }

    // Create employee
    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'contact' => $_POST['contact'],
                'username' => $_POST['username'],
                'password' => $_POST['password'],
                'total_sales' => $_POST['total_sales'] ?? 0,
                'monthly_sales' => $_POST['monthly_sales'] ?? 0,
                'overall_one_way' => $_POST['overall_one_way'] ?? 0,
                'overall_roundtrip' => $_POST['overall_roundtrip'] ?? 0,
                'date_added' => date('Y-m-d')
            ];

            if ($this->model->create($data)) {
                $_SESSION['success'] = 'Employee added successfully!';
            } else {
                $_SESSION['error'] = 'Failed to add employee';
            }
            
            redirect('admin/employees');
        }
    }

    // Update employee
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'contact' => $_POST['contact'],
                'username' => $_POST['username'],
                'total_sales' => $_POST['total_sales'],
                'monthly_sales' => $_POST['monthly_sales']
            ];

            if ($this->model->update($id, $data)) {
                $_SESSION['success'] = 'Employee updated successfully!';
            } else {
                $_SESSION['error'] = 'Failed to update employee';
            }
            
            redirect('admin/employees');
        }
    }

    // Update employee tickets
    public function updateTickets($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $tickets = $_POST['tickets'] ?? [];

            if ($this->model->updateTickets($id, $tickets)) {
                $_SESSION['success'] = 'Tickets updated successfully!';
            } else {
                $_SESSION['error'] = 'Failed to update tickets';
            }
            
            redirect('admin/employees');
        }
    }

    // Delete employee
    public function delete($id) {
        if ($this->model->delete($id)) {
            $_SESSION['success'] = 'Employee deleted successfully!';
        } else {
            $_SESSION['error'] = 'Failed to delete employee';
        }
        
        redirect('admin/employees');
    }

    // Bulk delete employees
    public function bulkDelete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $ids = $_POST['selected_ids'] ?? [];
            
            if ($this->model->bulkDelete($ids)) {
                $count = count($ids);
                $_SESSION['success'] = "Deleted $count employee(s) successfully!";
            } else {
                $_SESSION['error'] = 'Failed to delete employees';
            }
            
            redirect('admin/employees');
        }
    }
}
