<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/Fare.php';

class FareController {
    private $model;

    public function __construct() {
        requireAdmin();
        $this->model = new Fare();
    }

    // Show all fares
    public function index() {
        $fares = $this->model->getAll();
        require_once __DIR__ . '/../views/admin/fares.php';
    }

    // Create fare
    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'ticket_id' => $this->model->generateTicketId(),
                'destination' => $_POST['destination'],
                'one_way' => $_POST['one_way'],
                'roundtrip' => $_POST['roundtrip']
            ];

            if ($this->model->create($data)) {
                $_SESSION['success'] = 'Fare added successfully!';
            } else {
                $_SESSION['error'] = 'Failed to add fare';
            }
            
            redirect('admin/fares');
        }
    }

    // Update fare
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'destination' => $_POST['destination'],
                'one_way' => $_POST['one_way'],
                'roundtrip' => $_POST['roundtrip']
            ];

            if ($this->model->update($id, $data)) {
                $_SESSION['success'] = 'Fare updated successfully!';
            } else {
                $_SESSION['error'] = 'Failed to update fare';
            }
            
            redirect('admin/fares');
        }
    }

    // Delete fare
    public function delete($id) {
        if ($this->model->delete($id)) {
            $_SESSION['success'] = 'Fare deleted successfully!';
        } else {
            $_SESSION['error'] = 'Failed to delete fare';
        }
        
        redirect('admin/fares');
    }

    // Bulk delete fares
    public function bulkDelete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $ids = $_POST['selected_ids'] ?? [];
            
            if ($this->model->bulkDelete($ids)) {
                $count = count($ids);
                $_SESSION['success'] = "Deleted $count fare(s) successfully!";
            } else {
                $_SESSION['error'] = 'Failed to delete fares';
            }
            
            redirect('admin/fares');
        }
    }
}
