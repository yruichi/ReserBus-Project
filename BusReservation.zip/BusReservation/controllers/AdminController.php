<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/Employee.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Fare.php';
require_once __DIR__ . '/../models/Dashboard.php';

class AdminController {
    private $employeeModel;
    private $customerModel;
    private $fareModel;
    private $dashboardModel;

    public function __construct() {
        requireAdmin();
        $this->employeeModel = new Employee();
        $this->customerModel = new Customer();
        $this->fareModel = new Fare();
        $this->dashboardModel = new Dashboard();
    }

    // Show dashboard
    public function dashboard() {
        // Get dashboard metrics from model
        $metrics = $this->dashboardModel->getAllMetrics();
        
        $data = [
            'topEmployees' => $this->employeeModel->getTopPerformers(5),
            'allFares' => $this->fareModel->getAll(),
            'pendingRequests' => $this->customerModel->getPendingRequests(),
            'metrics' => $metrics
        ];
        
        require_once __DIR__ . '/../views/admin/dashboard.php';
    }
    // Update employee (including password if provided)
    public function updateEmployee() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
            $id = $_POST['id'] ?? null;
            $data = [
                'name' => $_POST['name'] ?? '',
                'email' => $_POST['email'] ?? '',
                'contact' => $_POST['contact'] ?? '',
                'username' => $_POST['username'] ?? '',
                'total_sales' => $_POST['total_sales'] ?? 0,
                'monthly_sales' => $_POST['monthly_sales'] ?? 0,
                'password' => $_POST['password'] ?? ''
            ];
            // Only update password if provided (not empty)
            if (empty($data['password'])) {
                unset($data['password']);
            }
            $this->employeeModel->update($id, $data);
            $_SESSION['success'] = 'Employee updated successfully.';
            header('Location: ' . BASE_URL . 'admin/employees');
            exit;
        }
    }
}
