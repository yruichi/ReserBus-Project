<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    // Show login page
    public function showLogin() {
        if (isset($_SESSION['user_id'])) {
            redirect('admin/dashboard');
        }
        require_once __DIR__ . '/../views/auth/login.php';
    }

    // Handle login
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                $_SESSION['error'] = 'Please fill in all fields';
                redirect('login');
                return;
            }

            // If DB connection failed, show a clearer error
            if (!$this->userModel->isConnected()) {
                Database::getConnection();
                $last = Database::getLastError();
                $_SESSION['error'] = 'Cannot connect to database. Please check SQL Server instance, credentials, and that Mixed Mode authentication is enabled.' . ($last ? ' Details: ' . $last : '');
                redirect('login');
                return;
            }

            $user = $this->userModel->login($username, $password);
            
            if ($user) {
                // Only allow admin and employee roles
                if ($user['user_type'] !== 'admin' && $user['user_type'] !== 'employee') {
                    $_SESSION['error'] = 'Access denied. Only admin and employee accounts are allowed.';
                    redirect('login');
                    return;
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_type'] = $user['user_type'];
                
                // Redirect based on user type
                if ($user['user_type'] === 'admin') {
                    redirect('admin/dashboard');
                } else {
                    redirect('employee/dashboard');
                }
            } else {
                $_SESSION['error'] = 'Invalid username or password';
                redirect('login');
            }
        }
    }

    // Handle logout
    public function logout() {
        session_destroy();
        redirect('login');
    }
}
