<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/Customer.php';

class CustomerController {
    private $model;

    public function __construct() {
        requireAdmin();
        $this->model = new Customer();
    }

    // Show all customers
    public function index() {
        // Handle POST requests for processing requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            if ($_POST['action'] === 'process_request') {
                $this->processRequest();
                return;
            }
        }
        
        $customers = $this->model->getAll();
        require_once __DIR__ . '/../views/admin/customers.php';
    }

    // Process customer request (approve, reject)
    public function processRequest() {
        $requestId = $_POST['request_id'] ?? null;
        $ticketId = $_POST['ticket_id'] ?? null;
        $status = $_POST['status'] ?? null;
        $adminNotes = $_POST['admin_notes'] ?? '';

        if (!$requestId || !$status) {
            $_SESSION['error'] = 'Invalid request data';
            redirect('admin/customers');
            return;
        }

        try {
            $conn = Database::getConnection();

            // Get request, ticket, and customer details for email
            $detailsQuery = "SELECT cr.*, t.Destination, t.DepartureDate, t.TicketType, t.BookedDate, c.Name AS CustomerName, c.Email AS CustomerEmail FROM CustomerRequest cr INNER JOIN Ticket t ON cr.TicketID = t.TicketID INNER JOIN Customer c ON cr.CustomerID = c.CustomerID WHERE cr.RequestID = ?";
            $detailsStmt = $conn->prepare($detailsQuery);
            $detailsStmt->execute([$requestId]);
            $details = $detailsStmt->fetch();

            // Update the CustomerRequest status
            $query = "UPDATE CustomerRequest SET Status = ? WHERE RequestID = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$status, $requestId]);

            // Also update the ticket status if applicable
            if ($ticketId && in_array($status, ['Cancelled', 'Refunded'])) {
                $ticketQuery = "UPDATE Ticket SET Status = ? WHERE TicketID = ?";
                $ticketStmt = $conn->prepare($ticketQuery);
                $ticketStmt->execute([$status, $ticketId]);
            }

            // Send email notification to passenger
            require_once __DIR__ . '/../utils/send_booking_email.php';
            $to = $details['CustomerEmail'] ?? null;
            $quantity = $details['Quantity'] ?? 1;
            $destination = $details['Destination'] ?? '';
            $requestType = $details['RequestType'] ?? ($details['RequestName'] ?? '');
            $requestStatus = $status;
            $requestDate = $details['RequestDate'] ?? date('Y-m-d');
            $reasonForRequest = $details['Reason'] ?? '';
            $remarks = $adminNotes;

            $emailSent = false;
            if ($to) {
                if ($status === 'Approved') {
                    $submittedDate = $details['RequestDate'] ? date('F j, Y, g:i a', strtotime($details['RequestDate'])) : date('F j, Y, g:i a');
                    $emailSent = sendCancellationApprovedEmail(
                        $to,
                        $details['CustomerName'],
                        $ticketId,
                        $quantity,
                        $destination,
                        $requestType,
                        $reasonForRequest,
                        $requestStatus,
                        $submittedDate
                    );
                } elseif ($status === 'Rejected' || $status === 'Disapproved') {
                    $emailSent = sendCancellationDisapprovedEmail(
                        $to,
                        $details['CustomerName'],
                        $ticketId,
                        $quantity,
                        $destination,
                        $requestType,
                        $reasonForRequest,
                        $requestStatus,
                        $remarks
                    );
                } else if ($status === 'Under Review') {
                    $emailSent = sendCancellationRequestEmail($to, $details['CustomerName'], $ticketId, $quantity, $destination, $requestType, $requestStatus, $requestDate);
                }
            }

            $statusMessages = [
                'Approved' => 'Request approved successfully.',
                'Rejected' => 'Request rejected.',
                'Cancelled' => 'Ticket cancelled successfully.',
                'Refunded' => 'Ticket refunded successfully.',
                'Disapproved' => 'Request disapproved.',
                'Under Review' => 'Request received and under review.'
            ];

            $emailMsg = '';
            if ($to && ($status === 'Approved' || $status === 'Rejected' || $status === 'Disapproved')) {
                if ($emailSent) {
                    $emailMsg = ' Email sent to client.';
                } else {
                    $emailMsg = ' Email failed to send.';
                }
            }
            $_SESSION['success'] = ($statusMessages[$status] ?? 'Request processed successfully!') . $emailMsg;

        } catch (Exception $e) {
            $_SESSION['error'] = 'Error processing request: ' . $e->getMessage();
        }

        redirect('admin/customers');
    }

    // Update customer info
    public function updateCustomer() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $id = $_POST['customer_id'] ?? null;
            $name = $_POST['name'] ?? '';
            $contact = $_POST['contact'] ?? '';
            $email = $_POST['email'] ?? '';

            if ($id && $this->model->updateInfo($id, $name, $contact, $email)) {
                $_SESSION['success'] = 'Customer updated successfully!';
            } else {
                $_SESSION['error'] = 'Failed to update customer';
            }
            
            redirect('admin/customers');
        }
    }

    // Delete customer
    public function delete($id) {
        if ($this->model->delete($id)) {
            $_SESSION['success'] = 'Customer deleted successfully!';
        } else {
            $_SESSION['error'] = 'Failed to delete customer';
        }
        
        redirect('admin/customers');
    }

    // Bulk delete customers
    public function bulkDelete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $ids = $_POST['selected_ids'] ?? [];
            
            if ($this->model->bulkDelete($ids)) {
                $count = count($ids);
                $_SESSION['success'] = "Deleted $count customer(s) successfully!";
            } else {
                $_SESSION['error'] = 'Failed to delete customers';
            }
            
            redirect('admin/customers');
        }
    }
}
