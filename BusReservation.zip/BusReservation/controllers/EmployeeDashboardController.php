<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/Employee.php';
require_once __DIR__ . '/../models/Ticket.php';
require_once __DIR__ . '/../models/Dashboard.php';

class EmployeeDashboardController {
    private $employeeModel;
    private $ticketModel;
    private $dashboardModel;

    public function __construct() {
        // Only employees can access their dashboard
        if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'employee') {
            requireAuth();
        }
        $this->employeeModel = new Employee();
        $this->ticketModel = new Ticket();
        $this->dashboardModel = new Dashboard();
    }

    // Show employee dashboard
    public function dashboard() {
        $employeeId = $_SESSION['user_id'];
        $employee = $this->employeeModel->getById($employeeId);
        if (!$employee) {
            $_SESSION['error'] = 'Employee not found';
            redirect('login');
        }

        // Get employee-specific metrics from Dashboard model
        $employeeData = $this->dashboardModel->getEmployeeMetrics($employeeId);

        // Get today's sales for display (employee)
        $ticketsData = $this->ticketModel->getTodaySalesByEmployee($employeeId);

        // Get sales data (recent completed tickets)
        $salesData = $this->ticketModel->getByEmployee($employeeId, 5);

        // Get recent tickets for customer
        $customerTicketsData = [];
        if (!empty($employee['CustomerID'])) {
            $customerTicketsData = $this->ticketModel->getByCustomer($employee['CustomerID']);
        }

        require_once __DIR__ . '/../views/employee/dashboard.php';
    }

    // View employee's profile
    public function profile() {
        $employeeId = $_SESSION['user_id'];
        $employee = $this->employeeModel->getById($employeeId);
        
        if (!$employee) {
            $_SESSION['error'] = 'Employee not found';
            redirect('employee/dashboard');
        }

        $data = ['employee' => $employee];
        require_once __DIR__ . '/../views/employee/profile.php';
    }

    // Update employee's profile
    public function updateProfile() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('employee/profile');
        }

        $employeeId = $_SESSION['user_id'];
        
        $data = [
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'contact' => $_POST['contact'] ?? ''
        ];

        if (empty($data['name']) || empty($data['email'])) {
            $_SESSION['error'] = 'Name and email are required';
            redirect('employee/profile');
            return;
        }

        // Only update allowed fields for employees
        $query = "UPDATE Employee SET Name = :name, Email = :email, Contact = :contact WHERE EmployeeID = :id";
        
        try {
            $conn = Database::getConnection();
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':contact', $data['contact']);
            $stmt->bindParam(':id', $employeeId);
            
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Profile updated successfully';
            } else {
                $_SESSION['error'] = 'Failed to update profile';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        }

        redirect('employee/profile');
    }

    // View all tickets sold by this employee
    public function tickets() {
        $employeeId = $_SESSION['user_id'];
        $tickets = $this->ticketModel->getByEmployee($employeeId);
        
        $data = ['tickets' => $tickets];
        require_once __DIR__ . '/../views/employee/tickets.php';
    }
}
