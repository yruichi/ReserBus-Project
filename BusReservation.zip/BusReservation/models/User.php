<?php
require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;
    private $table = "users";
    private $connected = false;

    public $id;
    public $username;
    public $password;
    public $email;
    public $user_type;
    public $created_at;

    public function __construct() {
        $this->conn = Database::getConnection();
        $this->connected = $this->conn instanceof PDO;
    }

    // Login user against Admin and Employee tables (plaintext fallback)
    public function login($username, $password) {
        if (!$this->connected) {
            return false;
        }

        // Try Admin first
        $queryAdmin = "SELECT AdminID AS id, Username AS username, Password AS password, 'admin' AS user_type FROM Admin WHERE Username = ?";
        $stmt = $this->conn->prepare($queryAdmin);
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        if ($row) {
            if (password_verify($password, $row['password']) || $row['password'] === $password) {
                return $row;
            }
        }

        // Then Employee
        $queryEmp = "SELECT EmployeeID AS id, Username AS username, Password AS password, 'employee' AS user_type FROM Employee WHERE Username = ?";
        $stmt = $this->conn->prepare($queryEmp);
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        if ($row) {
            if (password_verify($password, $row['password']) || $row['password'] === $password) {
                return $row;
            }
        }

        return false;
    }

    // Register user (Admin/Employee only - must be created by admin)
    public function register($username, $password, $email, $user_type = 'employee') {
        if (!$this->connected) {
            return false;
        }
        // Only allow admin and employee user types
        if ($user_type !== 'admin' && $user_type !== 'employee') {
            return false;
        }
        
        $query = "INSERT INTO " . $this->table . " 
                  (username, password, email, user_type) 
                  VALUES (:username, :password, :email, :user_type)";
        
        $stmt = $this->conn->prepare($query);
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':user_type', $user_type);

        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    // Get user by ID
    public function getById($id) {
        if (!$this->connected) {
            return false;
        }
        $query = "SELECT TOP 1 * FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Check if username exists
    public function usernameExists($username) {
        if (!$this->connected) {
            return false;
        }
        $query = "SELECT TOP 1 id FROM " . $this->table . " WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetch() !== false;
    }

    public function isConnected(): bool {
        return $this->connected;
    }
}
