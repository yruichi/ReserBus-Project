
<?php
require_once __DIR__ . '/../config/config.php';

class Customer {
        // Get all pending customer requests (for Admin dashboard)
        public function getPendingRequests() {
            $query = "
                SELECT 
                    cr.RequestID,
                    cr.TicketID,
                    cr.Reason,
                    cr.Status,
                    rt.RequestName,
                    t.CustomerID,
                    c.Name as CustomerName,
                    t.Destination,
                    t.DepartureDate,
                    t.BookedDate
                FROM CustomerRequest cr
                INNER JOIN Ticket t ON cr.TicketID = t.TicketID
                INNER JOIN Customer c ON t.CustomerID = c.CustomerID
                LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
                WHERE cr.Status = 'Pending'
                ORDER BY cr.RequestID DESC
            ";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        }
    private $conn;
    private $table = "Customer";

    public function __construct() {
        $this->conn = Database::getConnection();
    }

    // Get all customers with ticket and request info (for Admin)
    public function getAll() {
        $query = "
            SELECT 
                c.CustomerID,
                c.Name,
                c.Contact,
                c.Email,
                c.EmployeeID,
                e.Name as EmployeeName,
                t.TicketID,
                t.BookedDate,
                t.DepartureDate,
                t.ReturnDate,
                t.TicketType,
                t.Destination,
                t.Price,
                t.Quantity,
                t.TotalAmount,
                t.Status as TicketStatus,
                cr.RequestID,
                rt.RequestTypeID,
                rt.RequestName,
                cr.Reason,
                cr.Status as RequestStatus
            FROM Ticket t
            INNER JOIN Customer c ON t.CustomerID = c.CustomerID
            LEFT JOIN Employee e ON c.EmployeeID = e.EmployeeID
            LEFT JOIN CustomerRequest cr ON cr.TicketID = t.TicketID
                AND cr.RequestID = (
                    SELECT MAX(cr2.RequestID) FROM CustomerRequest cr2 WHERE cr2.TicketID = t.TicketID
                )
            LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
            ORDER BY t.BookedDate DESC, t.TicketID DESC
        ";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get customers by employee (for Employee portal)
    public function getByEmployee($employeeId) {
        $query = "
            SELECT 
                c.CustomerID,
                c.Name,
                c.Contact,
                c.Email,
                t.TicketID,
                t.BookedDate,
                t.DepartureDate,
                t.Destination,
                t.Status as TicketStatus,
                cr.RequestID,
                rt.RequestTypeID,
                rt.RequestName,
                cr.Reason,
                cr.Status as RequestStatus
            FROM Customer c
            LEFT JOIN Ticket t ON c.CustomerID = t.CustomerID
                AND t.TicketID = (SELECT TOP 1 TicketID FROM Ticket WHERE CustomerID = c.CustomerID ORDER BY BookedDate DESC, TicketID DESC)
            LEFT JOIN CustomerRequest cr ON t.TicketID = cr.TicketID
                AND cr.RequestID = (SELECT TOP 1 RequestID FROM CustomerRequest WHERE TicketID = t.TicketID ORDER BY RequestID DESC)
            LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
            WHERE c.EmployeeID = ?
            ORDER BY c.CustomerID DESC, t.BookedDate DESC
        ";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        return $stmt->fetchAll();
    }

    // Get customer by ID
    public function getById($id) {
        $query = "SELECT TOP 1 * FROM " . $this->table . " WHERE CustomerID = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    // Create customer
    public function create($data) {
        $query = "INSERT INTO " . $this->table . " 
                  (Name, Contact, Email, EmployeeID) 
                  VALUES (?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $result = $stmt->execute([
            $data['name'],
            $data['contact'] ?? null,
            $data['email'] ?? null,
            $data['employee_id'] ?? null
        ]);
        
        if ($result) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    // Update customer
    public function update($id, $data) {
        $query = "UPDATE " . $this->table . " 
                  SET Name = ?, Contact = ?, Email = ? 
                  WHERE CustomerID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            $data['name'],
            $data['contact'] ?? null,
            $data['email'] ?? null,
            $id
        ]);
    }

    // Update customer info (simple version)
    public function updateInfo($id, $name, $contact, $email) {
        $query = "UPDATE " . $this->table . " 
                  SET Name = ?, Contact = ?, Email = ? 
                  WHERE CustomerID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$name, $contact, $email, $id]);
    }

    // Delete customer
    public function delete($id) {
        // First delete related records
        $this->conn->exec("DELETE FROM CustomerRequest WHERE CustomerID = $id");
        $this->conn->exec("DELETE FROM Ticket WHERE CustomerID = $id");
        
        $query = "DELETE FROM " . $this->table . " WHERE CustomerID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Bulk delete customers
    public function bulkDelete($ids) {
        if (empty($ids)) return false;
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        
        // Delete related records first
        $stmt1 = $this->conn->prepare("DELETE FROM CustomerRequest WHERE CustomerID IN ($placeholders)");
        $stmt1->execute($ids);
        
        $stmt2 = $this->conn->prepare("DELETE FROM Ticket WHERE CustomerID IN ($placeholders)");
        $stmt2->execute($ids);
        
        $query = "DELETE FROM " . $this->table . " WHERE CustomerID IN ($placeholders)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($ids);
    }
}
