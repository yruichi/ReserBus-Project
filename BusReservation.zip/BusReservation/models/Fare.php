<?php
require_once __DIR__ . '/../config/database.php';

class Fare {
    private $conn;
    private $table = "Fare";

    public function __construct() {
        $this->conn = Database::getConnection();
    }

    // Get all active fares
    public function getActiveFares() {
        $query = "SELECT * FROM " . $this->table . " WHERE IsActive = 1 ORDER BY Destination ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get all fares
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY Destination ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get fare by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE FareID = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    // Create fare
    public function create($data) {
        $query = "INSERT INTO " . $this->table . " 
                  (Destination, OneWayPrice, RoundTripPrice) 
                  VALUES (?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            $data['destination'],
            $data['one_way'],
            $data['roundtrip']
        ]);
    }

    // Update fare
    public function update($id, $data) {
        $query = "UPDATE " . $this->table . " 
                  SET Destination = ?, 
                      OneWayPrice = ?, 
                      RoundTripPrice = ?
                  WHERE FareID = ?";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            $data['destination'],
            $data['one_way'],
            $data['roundtrip'],
            $id
        ]);
    }

    // Delete fare
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE FareID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Bulk delete fares
    public function bulkDelete($ids) {
        if (empty($ids)) return false;
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $query = "DELETE FROM " . $this->table . " WHERE FareID IN ($placeholders)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($ids);
    }

    // Get fare by destination
    public function getByDestination($destination) {
        $query = "SELECT TOP 1 * FROM " . $this->table . " WHERE Destination = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$destination]);
        return $stmt->fetch();
    }

    // Get all destinations for dropdown
    public function getDestinations() {
        $query = "SELECT DISTINCT Destination FROM " . $this->table . " ORDER BY Destination ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}
