<?php
require_once __DIR__ . '/../config/database.php';

class Employee {
    private $conn;
    private $table = "Employee";

    public function __construct() {
        $this->conn = Database::getConnection();
    }

    // Get all employees
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY Date_Added DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get employee by ID
    public function getById($id) {
        $query = "SELECT TOP 1 * FROM " . $this->table . " WHERE EmployeeID = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    // Create employee
    public function create($data) {
        // Check if username already exists
        $checkQuery = "SELECT COUNT(*) FROM " . $this->table . " WHERE Username = ?";
        $checkStmt = $this->conn->prepare($checkQuery);
        $checkStmt->execute([$data['username']]);
        $exists = $checkStmt->fetchColumn();
        if ($exists) {
            $_SESSION['error'] = 'Username already exists. Please choose another.';
            return false;
        }
        $query = "INSERT INTO " . $this->table . " 
                  (Name, Email, Contact, Username, Password, Total_Sales, Monthly_Sales, 
                   Overall_One_Way, Overall_RoundTrip, CreatedByAdminID) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $admin_id = $_SESSION['user_id'] ?? 1;
        // Store password as plain text (INSECURE)
        return $stmt->execute([
            $data['name'],
            $data['email'],
            $data['contact'],
            $data['username'],
            $data['password'],
            $data['total_sales'] ?? 0,
            $data['monthly_sales'] ?? 0,
            $data['overall_one_way'] ?? 0,
            $data['overall_roundtrip'] ?? 0,
            $admin_id
        ]);
    }

    // Recalculate and update total and monthly sales for an employee
    public function updateSales($employeeId) {
        // Calculate total sales
        $totalQuery = "SELECT SUM(TotalAmount) as total_sales FROM Ticket WHERE EmployeeID = ? AND Status = 'Active'";
        $stmtTotal = $this->conn->prepare($totalQuery);
        $stmtTotal->execute([$employeeId]);
        $totalSales = $stmtTotal->fetchColumn() ?: 0;

        // Calculate monthly sales (current month)
        $monthQuery = "SELECT SUM(TotalAmount) as month_sales FROM Ticket WHERE EmployeeID = ? AND Status = 'Active' AND YEAR(BookedDate) = YEAR(GETDATE()) AND MONTH(BookedDate) = MONTH(GETDATE())";
        $stmtMonth = $this->conn->prepare($monthQuery);
        $stmtMonth->execute([$employeeId]);
        $monthSales = $stmtMonth->fetchColumn() ?: 0;

        // Update employee record
        $update = $this->conn->prepare("UPDATE Employee SET Total_Sales = ?, Monthly_Sales = ? WHERE EmployeeID = ?");
        $update->execute([$totalSales, $monthSales, $employeeId]);
    }
        
    // Update employee
    public function update($id, $data) {
        $fields = [
            'Name = ?',
            'Email = ?',
            'Contact = ?',
            'Username = ?',
            'Total_Sales = ?',
            'Monthly_Sales = ?'
        ];
        $params = [
            $data['name'],
            $data['email'],
            $data['contact'],
            $data['username'],
            $data['total_sales'],
            $data['monthly_sales']
        ];
        if (!empty($data['password'])) {
            $fields[] = 'Password = ?';
            $params[] = $data['password'];
        }
        $params[] = $id;
        $query = "UPDATE " . $this->table . " SET " . implode(', ', $fields) . " WHERE EmployeeID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($params);
    }

    // Update employee tickets
    public function updateTickets($id, $tickets) {
        $overall_one_way = 0;
        $overall_roundtrip = 0;

        foreach ($tickets as $destination => $counts) {
            $oneWay = intval($counts['one_way'] ?? 0);
            $roundTrip = intval($counts['roundtrip'] ?? 0);
            $overall_one_way += $oneWay;
            $overall_roundtrip += $roundTrip;

            // Get FareID for this destination
            $fareQuery = "SELECT FareID FROM Fare WHERE Destination = ?";
            $fareStmt = $this->conn->prepare($fareQuery);
            $fareStmt->execute([$destination]);
            $fare = $fareStmt->fetch();

            if ($fare) {
                // Check if EmployeeTicket exists
                $checkQuery = "SELECT EmployeeTicketID FROM EmployeeTicket WHERE EmployeeID = ? AND FareID = ?";
                $checkStmt = $this->conn->prepare($checkQuery);
                $checkStmt->execute([$id, $fare['FareID']]);
                $exists = $checkStmt->fetchColumn();

                if ($exists) {
                    // Update
                    $updateQuery = "UPDATE EmployeeTicket SET OneWayAvailable = ?, RoundTripAvailable = ? WHERE EmployeeID = ? AND FareID = ?";
                    $updateStmt = $this->conn->prepare($updateQuery);
                    $updateStmt->execute([$oneWay, $roundTrip, $id, $fare['FareID']]);
                } else {
                    // Insert
                    $insertQuery = "INSERT INTO EmployeeTicket (EmployeeID, FareID, OneWayAvailable, RoundTripAvailable) VALUES (?, ?, ?, ?)";
                    $insertStmt = $this->conn->prepare($insertQuery);
                    $insertStmt->execute([$id, $fare['FareID'], $oneWay, $roundTrip]);
                }
            }
        }

        // Update overall counts in Employee table
        $query = "UPDATE " . $this->table . " 
                  SET Overall_One_Way = ?, 
                      Overall_RoundTrip = ? 
                  WHERE EmployeeID = ?";

        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$overall_one_way, $overall_roundtrip, $id]);
    }
    
    // Get ticket availability for an employee
    public function getTicketAvailability($employeeId) {
        $query = "
            SELECT f.Destination, et.OneWayAvailable, et.RoundTripAvailable
            FROM EmployeeTicket et
            JOIN Fare f ON et.FareID = f.FareID
            WHERE et.EmployeeID = ?
            ORDER BY f.Destination
        ";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $results = $stmt->fetchAll();
        
        $availability = [];
        foreach ($results as $row) {
            $availability[$row['Destination']] = [
                'one_way' => $row['OneWayAvailable'],
                'roundtrip' => $row['RoundTripAvailable']
            ];
        }
        return $availability;
    }

    // Delete employee
    public function delete($id) {
        // Delete related records first
        // 1. Delete EmployeeTicket
        $stmt1 = $this->conn->prepare("DELETE FROM EmployeeTicket WHERE EmployeeID = ?");
        $stmt1->execute([$id]);

        // 2. Find all TicketIDs for this employee
        $stmt2 = $this->conn->prepare("SELECT TicketID FROM Ticket WHERE EmployeeID = ?");
        $stmt2->execute([$id]);
        $ticketIds = $stmt2->fetchAll(PDO::FETCH_COLUMN);

        // 3. Delete CustomerRequest for these tickets
        if (!empty($ticketIds)) {
            $placeholders = implode(',', array_fill(0, count($ticketIds), '?'));
            $delCR = $this->conn->prepare("DELETE FROM CustomerRequest WHERE TicketID IN ($placeholders)");
            $delCR->execute($ticketIds);
        }

        // 4. Delete Ticket for this employee
        $delT = $this->conn->prepare("DELETE FROM Ticket WHERE EmployeeID = ?");
        $delT->execute([$id]);

        // 5. Delete Customers assigned to this employee
        $delCust = $this->conn->prepare("DELETE FROM Customer WHERE EmployeeID = ?");
        $delCust->execute([$id]);

        // 6. Delete the employee
        $query = "DELETE FROM " . $this->table . " WHERE EmployeeID = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Bulk delete employees
    public function bulkDelete($ids) {
        if (empty($ids)) return false;
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        // 1. Delete EmployeeTicket
        $stmt1 = $this->conn->prepare("DELETE FROM EmployeeTicket WHERE EmployeeID IN ($placeholders)");
        $stmt1->execute($ids);

        // 2. Find all CustomerIDs for these employees
        $stmtCust = $this->conn->prepare("SELECT CustomerID FROM Customer WHERE EmployeeID IN ($placeholders)");
        $stmtCust->execute($ids);
        $customerIds = $stmtCust->fetchAll(PDO::FETCH_COLUMN);

        // 3. Find all TicketIDs for these customers
        $ticketIds = [];
        if (!empty($customerIds)) {
            $cPlaceholders = implode(',', array_fill(0, count($customerIds), '?'));
            $stmtTickets = $this->conn->prepare("SELECT TicketID FROM Ticket WHERE CustomerID IN ($cPlaceholders)");
            $stmtTickets->execute($customerIds);
            $ticketIds = $stmtTickets->fetchAll(PDO::FETCH_COLUMN);
        }

        // 4. Delete CustomerRequest for these tickets
        if (!empty($ticketIds)) {
            $tPlaceholders = implode(',', array_fill(0, count($ticketIds), '?'));
            $delCR = $this->conn->prepare("DELETE FROM CustomerRequest WHERE TicketID IN ($tPlaceholders)");
            $delCR->execute($ticketIds);
        }

        // 5. Delete Ticket for these customers
        if (!empty($customerIds)) {
            $cPlaceholders = implode(',', array_fill(0, count($customerIds), '?'));
            $delT = $this->conn->prepare("DELETE FROM Ticket WHERE CustomerID IN ($cPlaceholders)");
            $delT->execute($customerIds);
        }

        // 6. Delete Customers assigned to these employees
        if (!empty($customerIds)) {
            $cPlaceholders = implode(',', array_fill(0, count($customerIds), '?'));
            $delCust = $this->conn->prepare("DELETE FROM Customer WHERE CustomerID IN ($cPlaceholders)");
            $delCust->execute($customerIds);
        }

        // 7. Delete the employees
        $query = "DELETE FROM " . $this->table . " WHERE EmployeeID IN ($placeholders)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($ids);
    }

    // Get top performing employees
    public function getTopPerformers($limit = 5) {
        $query = "SELECT TOP " . intval($limit) . " * FROM " . $this->table . " 
                  ORDER BY Monthly_Sales DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
