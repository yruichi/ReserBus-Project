<?php
require_once __DIR__ . '/../config/database.php';

class Ticket {
    private $conn;
    private $table = "Ticket";

    public function __construct() {
        $this->conn = Database::getConnection();
    }

    // Get all tickets
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY BookedDate DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get ticket by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE TicketID = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Get tickets by employee
    public function getByEmployee($employeeId, $limit = null) {
        $query = "SELECT * FROM " . $this->table . " WHERE EmployeeID = :employee_id ORDER BY BookedDate DESC";
        if ($limit) {
            $query .= " OFFSET 0 ROWS FETCH NEXT " . intval($limit) . " ROWS ONLY";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':employee_id', $employeeId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get tickets by customer
    public function getByCustomer($customerId) {
        $query = "SELECT * FROM " . $this->table . " WHERE CustomerID = :customer_id ORDER BY BookedDate DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':customer_id', $customerId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Create ticket
    public function create($data) {
        $query = "INSERT INTO " . $this->table . " 
                  (CustomerID, EmployeeID, DepartureDate, Quantity, Status) 
                  VALUES (:customer_id, :employee_id, :departure_date, :quantity, :status)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':customer_id', $data['customer_id']);
        $stmt->bindParam(':employee_id', $data['employee_id']);
        $stmt->bindParam(':departure_date', $data['departure_date']);
        $stmt->bindParam(':quantity', $data['quantity'] ?? 1);
        $stmt->bindParam(':status', $data['status'] ?? 'Booked');

        return $stmt->execute();
    }

    // Update ticket status
    public function updateStatus($id, $status) {
        $query = "UPDATE " . $this->table . " SET Status = :status WHERE TicketID = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':status', $status);
        return $stmt->execute();
    }

    // Delete ticket
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE TicketID = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Get tickets by status
    public function getByStatus($status) {
        $query = "SELECT * FROM " . $this->table . " WHERE Status = :status ORDER BY BookedDate DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Count tickets by employee
    public function countByEmployee($employeeId) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE EmployeeID = :employee_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':employee_id', $employeeId);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get today's sales for employee
    public function getTodaySalesByEmployee($employeeId) {
        $query = "
            SELECT t.*, cr.RequestID, rt.RequestName AS RequestType, cr.Reason, cr.Status AS RequestStatus
            FROM Ticket t
            LEFT JOIN CustomerRequest cr ON t.TicketID = cr.TicketID
            LEFT JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
            WHERE t.EmployeeID = :employee_id AND CAST(t.BookedDate AS DATE) = CAST(GETDATE() AS DATE)
            ORDER BY t.BookedDate DESC
        ";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':employee_id', $employeeId);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
