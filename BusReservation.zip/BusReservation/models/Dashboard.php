<?php
require_once __DIR__ . '/../config/database.php';

class Dashboard {
    private $conn;

    public function __construct() {
        $this->conn = Database::getConnection();
    }

    // ADMIN DASHBOARD METHODS
    
    // Get total sales from all employees (all time)
    public function getTotalSales() {
        $query = "SELECT ISNULL(SUM(TotalAmount), 0) as total FROM Ticket WHERE Status IN ('Booked', 'Completed')";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get monthly sales from all employees (current month)
    public function getMonthlySales() {
        $query = "SELECT ISNULL(SUM(TotalAmount), 0) as total FROM Ticket 
                  WHERE Status IN ('Booked', 'Completed')
                  AND MONTH(BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get count of pending customer requests
    public function getPendingRequestsCount() {
        $query = "SELECT COUNT(*) as count FROM CustomerRequest WHERE Status = 'Pending'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get count of approved customer requests
    public function getApprovedRequestsCount() {
        $query = "SELECT COUNT(*) as count FROM CustomerRequest WHERE Status = 'Approved'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get most popular route (based on ticket bookings)
    public function getMostPopularRoute() {
        $query = "SELECT TOP 1 Destination, COUNT(*) as BookingCount 
                  FROM Ticket 
                  WHERE Status IN ('Booked', 'Completed')
                  GROUP BY Destination 
                  ORDER BY BookingCount DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['Destination'] ?? 'N/A';
    }

    // Get count of active employees
    public function getActiveEmployeesCount() {
        $query = "SELECT COUNT(*) as count FROM Employee";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get monthly tickets sold (current month)
    public function getMonthlyTicketsSold() {
        $query = "SELECT ISNULL(SUM(Quantity), 0) as total FROM Ticket 
                  WHERE Status IN ('Booked', 'Completed')
                  AND MONTH(BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get monthly customers (current month)
    public function getMonthlyCustomersCount() {
        $query = "SELECT COUNT(DISTINCT c.CustomerID) as count FROM Customer c
                  INNER JOIN Ticket t ON c.CustomerID = t.CustomerID
                  WHERE MONTH(t.BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(t.BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get total customers
    public function getTotalCustomersCount() {
        $query = "SELECT COUNT(*) as count FROM Customer";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get all admin dashboard metrics
    public function getAllMetrics() {
        return [
            'total_sales' => $this->getTotalSales(),
            'monthly_sales' => $this->getMonthlySales(),
            'pending_requests' => $this->getPendingRequestsCount(),
            'approved_requests' => $this->getApprovedRequestsCount(),
            'popular_route' => $this->getMostPopularRoute(),
            'active_employees' => $this->getActiveEmployeesCount(),
            'monthly_tickets' => $this->getMonthlyTicketsSold(),
            'monthly_customers' => $this->getMonthlyCustomersCount(),
            'total_customers' => $this->getTotalCustomersCount()
        ];
    }

    // =====================================================
    // EMPLOYEE DASHBOARD METHODS
    // =====================================================

    // Get employee total sales (all time)
    public function getEmployeeTotalSales($employeeId) {
        $query = "SELECT ISNULL(SUM(TotalAmount), 0) as total FROM Ticket 
                  WHERE EmployeeID = ? AND Status IN ('Booked', 'Completed')";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get employee monthly sales (current month)
    public function getEmployeeMonthlySales($employeeId) {
        $query = "SELECT ISNULL(SUM(TotalAmount), 0) as total FROM Ticket 
                  WHERE EmployeeID = ? AND Status IN ('Booked', 'Completed')
                  AND MONTH(BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get employee monthly customers
    public function getEmployeeMonthlyCustomers($employeeId) {
        $query = "SELECT COUNT(DISTINCT c.CustomerID) as count FROM Customer c
                  INNER JOIN Ticket t ON c.CustomerID = t.CustomerID
                  WHERE t.EmployeeID = ?
                  AND MONTH(t.BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(t.BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get employee monthly tickets sold
    public function getEmployeeMonthlyTickets($employeeId) {
        $query = "SELECT ISNULL(SUM(Quantity), 0) as total FROM Ticket 
                  WHERE EmployeeID = ? AND Status IN ('Booked', 'Completed')
                  AND MONTH(BookedDate) = MONTH(GETDATE()) 
                  AND YEAR(BookedDate) = YEAR(GETDATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get employee pending requests count
    public function getEmployeePendingRequests($employeeId) {
        $query = "SELECT COUNT(*) as count FROM CustomerRequest cr
                  INNER JOIN Ticket t ON cr.TicketID = t.TicketID
                  WHERE t.EmployeeID = ? AND cr.Status = 'Pending'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get employee most popular route
    public function getEmployeePopularRoute($employeeId) {
        $query = "SELECT TOP 1 Destination, COUNT(*) as BookingCount 
                  FROM Ticket 
                  WHERE EmployeeID = ? AND Status IN ('Booked', 'Completed')
                  GROUP BY Destination 
                  ORDER BY BookingCount DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['Destination'] ?? 'N/A';
    }

    // Get employee total customers
    public function getEmployeeTotalCustomers($employeeId) {
        $query = "SELECT COUNT(DISTINCT CustomerID) as count FROM Ticket WHERE EmployeeID = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    // Get employee one-way tickets count
    public function getEmployeeOneWayTickets($employeeId) {
        $query = "SELECT ISNULL(SUM(Quantity), 0) as total FROM Ticket 
                  WHERE EmployeeID = ? AND TicketType = 'One-Way' AND Status IN ('Booked', 'Completed')";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get employee round-trip tickets count
    public function getEmployeeRoundTripTickets($employeeId) {
        $query = "SELECT ISNULL(SUM(Quantity), 0) as total FROM Ticket 
                  WHERE EmployeeID = ? AND TicketType = 'Round-Trip' AND Status IN ('Booked', 'Completed')";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    // Get all employee dashboard metrics
    public function getEmployeeMetrics($employeeId) {
        return [
            'total_sales' => $this->getEmployeeTotalSales($employeeId),
            'monthly_sales' => $this->getEmployeeMonthlySales($employeeId),
            'monthly_customers' => $this->getEmployeeMonthlyCustomers($employeeId),
            'monthly_tickets' => $this->getEmployeeMonthlyTickets($employeeId),
            'pending_requests' => $this->getEmployeePendingRequests($employeeId),
            'popular_route' => $this->getEmployeePopularRoute($employeeId),
            'total_customers' => $this->getEmployeeTotalCustomers($employeeId),
            'one_way_tickets' => $this->getEmployeeOneWayTickets($employeeId),
            'roundtrip_tickets' => $this->getEmployeeRoundTripTickets($employeeId)
        ];
    }

    // =====================================================
    // SHARED METHODS
    // =====================================================

    // Get recent sales for table display
    public function getRecentSales($employeeId = null, $limit = 10) {
        $query = "SELECT TOP " . intval($limit) . " 
                    t.TicketID, t.Destination, t.TicketType, t.TotalAmount, t.BookedDate, t.Status,
                    c.Name as CustomerName, e.Name as EmployeeName
                  FROM Ticket t
                  INNER JOIN Customer c ON t.CustomerID = c.CustomerID
                  INNER JOIN Employee e ON t.EmployeeID = e.EmployeeID
                  WHERE t.Status IN ('Booked', 'Completed')";
        
        if ($employeeId) {
            $query .= " AND t.EmployeeID = ?";
        }
        
        $query .= " ORDER BY t.BookedDate DESC";
        
        $stmt = $this->conn->prepare($query);
        if ($employeeId) {
            $stmt->execute([$employeeId]);
        } else {
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    // Get pending requests list
    public function getPendingRequestsList($employeeId = null) {
        $query = "SELECT 
                    cr.RequestID, cr.Reason, cr.Status, cr.RequestDate,
                    rt.RequestName, rt.RequestTypeID,
                    c.CustomerID, c.Name as CustomerName, c.Contact, c.Email,
                    t.TicketID, t.Destination, t.TicketType, t.TotalAmount, t.DepartureDate,
                    e.EmployeeID, e.Name as EmployeeName
                  FROM CustomerRequest cr
                  INNER JOIN Customer c ON cr.CustomerID = c.CustomerID
                  INNER JOIN Ticket t ON cr.TicketID = t.TicketID
                  INNER JOIN RequestType rt ON cr.RequestTypeID = rt.RequestTypeID
                  INNER JOIN Employee e ON t.EmployeeID = e.EmployeeID
                  WHERE cr.Status = 'Pending'";
        
        if ($employeeId) {
            $query .= " AND t.EmployeeID = ?";
        }
        
        $query .= " ORDER BY cr.RequestDate DESC";
        
        $stmt = $this->conn->prepare($query);
        if ($employeeId) {
            $stmt->execute([$employeeId]);
        } else {
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    // Get all fares for booking
    public function getAllFares() {
        $query = "SELECT * FROM Fare ORDER BY Destination ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
